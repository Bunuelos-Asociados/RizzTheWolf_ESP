﻿# TODO: Translation updated at 2026-10-12 12:45

translate Spanish strings:

    # game/screens.rpy:419
    old "End Replay"
    new "Terminar repetición"

    # game/screens.rpy:680
    old "About"
    new "Acerca de"

    # game/screens.rpy:687
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:693
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:694
    old "\nMUSIC CREDITS:{a=https://rustedstudio.itch.io}RUSTED MUSIC STUDIO Music & assets{/a}"
    new "\nCRÉDITOS MUSICALES:{a=https://rustedstudio.itch.io}RUSTED MUSIC STUDIO — Música y recursos{/a}"

    # game/screens.rpy:699
    old "Rizz the Wolf made by fantasia_kitt"
    new "Rizz the Wolf, creado por fantasia_kitt"

    # game/screens.rpy:704
    old "SUPPORT FANTASIA_KITT"
    new "APOYA A FANTASIA_KITT"

    # game/screens.rpy:708
    old "{a=https://x.com/TKaTB_VN}Twitter/X{/a}|{a=https://www.tumblr.com/blog/fantasia-kitt}Tumblr{/a}|{a=https://www.patreon.com/fantasia_tealcatart}Patreon{/a}|{a=https://fantasiakitt.carrd.co}Carrd{/a}"
    new "{a=https://x.com/TKaTB_VN}Twitter/X{/a}|{a=https://www.tumblr.com/blog/fantasia-kitt}Tumblr{/a}|{a=https://www.patreon.com/fantasia_tealcatart}Patreon{/a}|{a=https://fantasiakitt.carrd.co}Carrd{/a}"

    # game/screens.rpy:738
    old "Save"
    new "Guardar"

    # game/screens.rpy:745
    old "Load"
    new "Cargar"

    # game/screens.rpy:750
    old "Page {} "
    new "Página {} "

    # game/screens.rpy:750
    old "Automatic saves"
    new "Guardados automáticos"

    # game/screens.rpy:750
    old "Quick saves"
    new "Guardados rápidos"

    # game/screens.rpy:794
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:794
    old "empty slot"
    new "Ranura vacía"

    # game/screens.rpy:814
    old "Previous"
    new "Anterior"

    # game/screens.rpy:817
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:820
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:826
    old "Next"
    new "Siguiente"

    # game/screens.rpy:881
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:892
    old "Display"
    new "Pantalla"

    # game/screens.rpy:895
    old "Window"
    new "Ventana"

    # game/screens.rpy:896
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:900
    old "Skip"
    new "Saltar"

    # game/screens.rpy:904
    old "Unseen Text"
    new "Texto no leído"

    # game/screens.rpy:905
    old "After Choices"
    new "Después de las elecciones"

    # game/screens.rpy:906
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:919
    old "Text Speed"
    new "Velocidad del texto"

    # game/screens.rpy:923
    old "Auto-Forward Time"
    new "Tiempo de avance automático"

    # game/screens.rpy:930
    old "Music Volume"
    new "Volumen de la música"

    # game/screens.rpy:937
    old "Sound Volume"
    new "Volumen de sonido"

    # game/screens.rpy:943
    old "Test"
    new "Probar"

    # game/screens.rpy:947
    old "Voice Volume"
    new "Volumen de voz"

    # game/screens.rpy:958
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:1084
    old "History"
    new "Historial"

    # game/screens.rpy:1115
    old "The dialogue history is empty."
    new "El historial de diálogo está vacío."

    # game/screens.rpy:1182
    old "Help"
    new "Ayuda"

    # game/screens.rpy:1191
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:1192
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:1195
    old "Gamepad"
    new "Mando"

    # game/screens.rpy:1208
    old "Enter"
    new "Enter"

    # game/screens.rpy:1209
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1212
    old "Space"
    new "Space"

    # game/screens.rpy:1213
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:1216
    old "Arrow Keys"
    new "Teclas de dirección"

    # game/screens.rpy:1217
    old "Navigate the interface."
    new "Permiten navegar por la interfaz."

    # game/screens.rpy:1220
    old "Escape"
    new "Escape"

    # game/screens.rpy:1221
    old "Accesses the game menu."
    new "Abre el menú del juego."

    # game/screens.rpy:1224
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1225
    old "Skips dialogue while held down."
    new "Omite el diálogo mientras se mantiene pulsada."

    # game/screens.rpy:1228
    old "Tab"
    new "Tab"

    # game/screens.rpy:1229
    old "Toggles dialogue skipping."
    new "Activa o desactiva el salto de diálogos."

    # game/screens.rpy:1232
    old "Page Up"
    new "Page Up"

    # game/screens.rpy:1233
    old "Rolls back to earlier dialogue."
    new "Retrocede a diálogos anteriores."

    # game/screens.rpy:1236
    old "Page Down"
    new "Page Down"

    # game/screens.rpy:1237
    old "Rolls forward to later dialogue."
    new "Avanza a diálogos posteriores."

    # game/screens.rpy:1241
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1245
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1249
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa o desactiva la {a=https://www.renpy.org/l/voicing}lectura en voz alta{/a}."

    # game/screens.rpy:1253
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1259
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1263
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1267
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1271
    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rueda del ratón hacia arriba\nClic en el lado de retroceso"

    # game/screens.rpy:1275
    old "Mouse Wheel Down"
    new "Rueda del ratón hacia abajo"

    # game/screens.rpy:1282
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nBotón A/inferior"

    # game/screens.rpy:1286
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón superior izquierdo"

    # game/screens.rpy:1290
    old "Right Shoulder"
    new "Botón superior derecho"

    # game/screens.rpy:1295
    old "D-Pad, Sticks"
    new "Cruceta y joysticks"

    # game/screens.rpy:1299
    old "Start, Guide"
    new "Start, Guide"

    # game/screens.rpy:1303
    old "Y/Top Button"
    new "Botón Y/superior"

    # game/screens.rpy:1306
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1424
    old "Skipping"
    new "Omitiendo"
    
    old "Start"
    new "Inicio"

    old "Quit"
    new "Salir"

    old "{color=#f00}{size=50}{b}WARNING + DISCLAIMER{/b}{/size}{/color}\n \n{i}This game is a work of fiction. The game's story, characters, and events are entirely made up and not based on real people or events.{/i}"
    new "{color=#f00}{size=50}{b}ADVERTENCIA Y DESCARGO DE RESPONSABILIDAD{/b}{/size}{/color}\n \n{i}Este juego es una obra de ficción. La historia, los personajes y los acontecimientos son completamente ficticios y no están basados en personas ni hechos reales.{/i}"

    old "The story may include triggering themes such as murder, assault, bullying and death. If you are sensitive to these topics, please close the game."
    new "La historia puede incluir temas sensibles, como asesinatos, agresiones, acoso y muerte. Si estos temas te afectan, cierra el juego."

    old "This game is pure gag and is to not be taken seriously.\n\n Happy April Fools you punks."
    new "Este juego es pura comedia absurda y no debe tomarse en serio.\n\n¡Feliz Día de los Inocentes, desgraciados!"