﻿# TODO: Translation updated at 2026-10-12 12:45

# game/script.rpy:34
translate Spanish name_input_ae837294:

    # fantasia "Heh"
    fantasia "Je"

# game/script.rpy:35
translate Spanish name_input_dbcb277d:

    # fantasia "Nice try."
    fantasia "Buen intento."

# game/script.rpy:36
translate Spanish name_input_94a60226:

    # fantasia "Be a little less obvious and pick a different name."
    fantasia "Disimula un poco y elige otro nombre."

# game/script.rpy:45
translate Spanish name_input_0afc5700:

    # "Ah...{w=1} It's that time of the year again."
    "Ah...{w=1} Ya es esa época del año otra vez."

# game/script.rpy:46
translate Spanish name_input_58a5fe00:

    # "{i}Mother{w=1} fuckin'{w=1} Valentine's Day."
    "{i}Maldito{w=1} puto{w=1} San Valentín."

# game/script.rpy:47
translate Spanish name_input_ff85b7dc:

    # "The day you dreaded the most."
    "El día que más temías."

# game/script.rpy:48
translate Spanish name_input_3d8ff9dc:

    # "Your classroom is filled with multiple decorations to commemorate the holiday, with paper hearts plastered on the blackboard and some baby angels symbolizing Cupid stuck on the door frame."
    "Tu salón está lleno de decoraciones para conmemorar la fecha, con corazones de papel pegados en el pizarrón y unos angelitos que simbolizan a Cupido pegados en el marco de la puerta."

# game/script.rpy:49
translate Spanish name_input_791f413c:

    # "You hate Valentine's Day."
    "Odias el día de San Valentín."

# game/script.rpy:50
translate Spanish name_input_8a78b825:

    # "But you also love it."
    "Pero también lo amas."

# game/script.rpy:51
translate Spanish name_input_1c87bb91:

    # "You don't know why you feel happy despite hating the holiday."
    "No sabes por qué te sientes feliz a pesar de odiar la fecha."

# game/script.rpy:52
translate Spanish name_input_f8302fe8:

    # "Maybe it's because of the adrenaline? Is it because of the amount of poor saps who get rejected, and you get to laugh at them? Or is it from the discounted chocolate bars you can buy?"
    "¿Será por la adrenalina? ¿Será por la cantidad de pobres diablos que son rechazados y de quienes te puedes reír? ¿O será por las barras de chocolate en oferta que puedes comprar?"

# game/script.rpy:53
translate Spanish name_input_82592ed3:

    # "Or maybe you're indecisive and don't know how to feel about the occasion."
    "O quizá te cuesta decidirte y no sabes cómo sentirte respecto a la ocasión."

# game/script.rpy:54
translate Spanish name_input_4b871265:

    # teacher "Oogami, you raised your hand, yes?"
    teacher "Oogami, levantaste la mano, ¿cierto?"

# game/script.rpy:58
translate Spanish name_input_c472964a:

    # g "{i}Obviously you dumb fool."
    g "{i}Obvio, tonto idiota."

# game/script.rpy:59
translate Spanish name_input_fb1e26be:

    # g base e1 m7 b1 "Sir, I noticed a small mistake in your philosophy, I would like to correct your statement if you so let me."
    g base e1 m7 b1 "Señor, noté un pequeño error en su filosofía; me gustaría corregir su afirmación, si me lo permite."

# game/script.rpy:62
translate Spanish name_input_0b6ba725:

    # teacher "Oh ho? So you're doubting me? Fine, prove yourself at the front and convince me."
    teacher "¿Ah, sí? ¿Así que dudas de mí? Bien, demuéstralo ahí al frente y convénceme."

# game/script.rpy:64
translate Spanish name_input_10fac3fe:

    # g base e1 m5 b2 "{i}You won't be able to hear me if I stand here anyway, asswipe."
    g base e1 m5 b2 "{i}De todos modos no vas a poder oírme si me quedo aquí, imbécil."

# game/script.rpy:66
translate Spanish name_input_ac0349c1:

    # g base default_blink m1 b1 "Of course."
    g base default_blink m1 b1 "Por supuesto."

# game/script.rpy:70
translate Spanish name_input_a1a0990f:

    # "You feel around for the envelope within your backpack."
    "Buscas a tientas el sobre dentro de tu mochila."

# game/script.rpy:71
translate Spanish name_input_b2b6ef96:

    # you "Good... it's still there."
    you "Bien... sigue ahí."

# game/script.rpy:72
translate Spanish name_input_f5ac9f43:

    # "Feeling the smooth surface of the piece of paper, you let out a sigh as you return your attention back towards the front."
    "Al sentir la superficie lisa del papel, sueltas un suspiro y devuelves tu atención al frente."

# game/script.rpy:76
translate Spanish name_input_7dd06590:

    # "Subaru Oogami."
    "Subaru Oogami."

# game/script.rpy:77
translate Spanish name_input_df8403fa:

    # "Or as some of his friends who would like to call him: Geo."
    "O, como algunos de sus amigos prefieren llamarlo: Geo."

# game/script.rpy:78
translate Spanish name_input_82087a0b:

    # "And he's a fucking enigma."
    "Y es un puto enigma."

# game/script.rpy:79
translate Spanish name_input_3a313e47:

    # "You don't know when this tiny crush of yours towards him started and how bad it has gotten throughout the years, but one thing's for sure..."
    "No sabes cuándo empezó este pequeño flechazo tuyo por él ni cuánto ha empeorado con los años, pero de algo sí hay certeza..."

# game/script.rpy:80
translate Spanish name_input_aa117f68:

    # "You are getting his fine ass one way or another."
    "Ese cuerpazo va a ser tuyo de una forma u otra."

# game/script.rpy:82
translate Spanish name_input_31d66d85:

    # friend "Hey look at your little soon-to-be boyfriend yapping his mouth off at the front."
    friend "Oye, mira a tu futuro noviecito parloteando sin parar allá al frente."

# game/script.rpy:83
translate Spanish name_input_fb2f09b0:

    # "You turn to glare at your friend."
    "Te giras para fulminar con la mirada a tu amiguis."

# game/script.rpy:84
translate Spanish name_input_36498234:

    # "Let's call them..."
    "Llamémosle..."

# game/script.rpy:92
translate Spanish friend_input_9334bbc1:

    # "You swore this isn't your friend's name{w=1}, who are you to even forget your own best friend's name?"
    "Juraste que ese no es el nombre de tu amistad{w=1}, ¿quién eres tú para olvidar el nombre de tu mejor amiguis?"

# game/script.rpy:93
translate Spanish friend_input_b4e438e8:

    # "Shame on you!"
    "¡Qué vergüenza!"

# game/script.rpy:94
translate Spanish friend_input_549a0489:

    # "Think [mc]! Think!"
    "¡Piensa, [mc]! ¡Piensa!"

# game/script.rpy:97
translate Spanish friend_input_d00bb21c:

    # fantasia "Oh don't even think about it, {b}buddy{/b}."
    fantasia "Oh, ni lo pienses, {b}colega{/b}."

# game/script.rpy:98
translate Spanish friend_input_5a3603cd:

    # fantasia "Don't you have friends?"
    fantasia "¿Acaso no tienes amigos?"

# game/script.rpy:99
translate Spanish friend_input_ff707fef:

    # fantasia "Pick someone else!"
    fantasia "¡Elige a alguien más!"

# game/script.rpy:103
translate Spanish friend_input_66cd8e44:

    # fren "Seriously, could you be any more obvious? On the day of love too, ain't you a romantic?"
    fren "En serio, ¿se te podría notar más? Y en el día del amor, además. Qué romance el tuyo, ¿eh?"

# game/script.rpy:104
translate Spanish friend_input_3e69d606:

    # mc "Oh my god shut up! My pookie's talking."
    mc "¡Por Dios, cállate! Mi bebé está hablando."

# game/script.rpy:105
translate Spanish friend_input_c92807c2:

    # "A finger over your lips as you shushed your friend. They roll their eyes as they shrug their shoulders."
    "Te pones un dedo sobre los labios para callar a tu amiguis. Pone los ojos en blanco y se encoge de hombros."

# game/script.rpy:106
translate Spanish friend_input_02c5d825:

    # fren "Well I don't really care much about the guy."
    fren "Bueno, a mí el tipo no me importa mucho."

# game/script.rpy:107
translate Spanish friend_input_82e52bfe:

    # fren "But since you're trying another shot this year...{w=1} What are your plans this time, genius?"
    fren "Pero ya que vas a intentarlo otra vez este año...{w=1} ¿cuál es tu plan esta vez, genio?"

# game/script.rpy:108
translate Spanish friend_input_e3d4c3ba:

    # "Giving [fren] a playful smirk, you run your fingers across the smooth surface of the envelope and presented it towards them."
    "Con una sonrisita juguetona hacia [fren], pasas los dedos por la superficie lisa del sobre y se lo presentas."

# game/script.rpy:109
translate Spanish friend_input_c46ab52c:

    # "They gave you an unamused look."
    "Te lanza una mirada de poca gracia."

# game/script.rpy:110
translate Spanish friend_input_11455b53:

    # mc "What?"
    mc "¿Qué?"

# game/script.rpy:111
translate Spanish friend_input_8fe0a946:

    # fren "Seriously? {w=1}A typical love letter?"
    fren "¿En serio? {w=1}¿Una carta de amor típica?"

# game/script.rpy:112
translate Spanish friend_input_f954b675:

    # mc "This one is better than last year! Promise!"
    mc "¡Esta es mejor que la del año pasado! ¡Lo prometo!"

# game/script.rpy:113
translate Spanish friend_input_558fa3db:

    # fren "I'm not saying that the letter is a bad idea."
    fren "No digo que la carta sea una mala idea."

# game/script.rpy:114
translate Spanish friend_input_6b17be2e:

    # fren "{cps=5}........"
    fren "{cps=5}........"

# game/script.rpy:115
translate Spanish friend_input_41e6dfe0:

    # fren "Actually, no, it {i}is{/i} a bad idea."
    fren "Bueno, no, {i}sí{/i} es una mala idea."

# game/script.rpy:116
translate Spanish friend_input_4ceb69bb:

    # fren "Geo doesn't read the letters and you know EXACTLY what he does with it."
    fren "Geo no lee las cartas y sabes EXACTAMENTE qué hace con ellas."

# game/script.rpy:117
translate Spanish friend_input_1a452d65:

    # "You know EXACTLY what he does to the letters. You often wonder how he's allowed to even burn things."
    "Sabes EXACTAMENTE qué hace con las cartas. Muchas veces te preguntas cómo es que le permiten siquiera quemar cosas."

# game/script.rpy:118
translate Spanish friend_input_dcde19eb:

    # "Well...{w=1} As long as it's in the gardens then the school staff probably doesn't give three flying fucks that there's smoke coming from the back of the school."
    "Bueno...{w=1} mientras sea en los jardines, seguramente al personal de la escuela le importa un carajo que salga humo de la parte de atrás del colegio."

# game/script.rpy:119
translate Spanish friend_input_05662c7f:

    # "{cps=5}.....{w=1}{/cps} Or maybe they're too scared to deal with a 21 year old who can slit their throat in one swing."
    "{cps=5}.....{w=1}{/cps} O quizá les da demasiado miedo lidiar con un chico de 21 años que puede degollarlos de un solo tajo."

# game/script.rpy:120
translate Spanish friend_input_7d7ab420:

    # fren "Either way, you better think of something better than an old letter, this ain't the 1700s."
    fren "Como sea, más te vale pensar en algo mejor que una carta antigua; esto no es el siglo XVIII."

# game/script.rpy:121
translate Spanish friend_input_da72a194:

    # mc "Hey now! Love letters are still sweet you know? Traditional gift giving is still relevant in this day and age."
    mc "¡Oye! Las cartas de amor siguen siendo dulces, ¿sabes? Regalar cosas de forma tradicional sigue vigente hoy en día."

# game/script.rpy:122
translate Spanish friend_input_8a430730:

    # fren "And in this day and age, chocolates and flowers are expensive as hell."
    fren "Y hoy en día, los chocolates y las flores son carísimos."

# game/script.rpy:123
translate Spanish friend_input_81c1f4f5:

    # fren "And did you... use scented paper on the letter?"
    fren "¿Y usaste... papel perfumado en la carta?"

# game/script.rpy:124
translate Spanish friend_input_9103e4a6:

    # mc "I just sprayed perfume on it!"
    mc "¡Solo le rocié perfume!"

# game/script.rpy:125
translate Spanish friend_input_d7879338:

    # fren "Perfume that you stole from me, mind you."
    fren "Perfume que me robaste a mí, ojo."

# game/script.rpy:126
translate Spanish friend_input_ebd39fe1:

    # mc "I simply 'borrowed' from you."
    mc "Simplemente te lo 'tomé prestado'."

# game/script.rpy:127
translate Spanish friend_input_acec2fc9:

    # fren "Either way, this is going to be your 3rd year of giving him a letter."
    fren "Como sea, este será tu tercer año dándole una carta."

# game/script.rpy:128
translate Spanish friend_input_0eb4cb29:

    # fren "And it always go to absolute shit."
    fren "Y siempre se va a la mierda."

# game/script.rpy:129
translate Spanish friend_input_2d99a2de:

    # fren "Always."
    fren "Siempre."

# game/script.rpy:130
translate Spanish friend_input_9f67ec1b:

    # fren "How about trying something else?"
    fren "¿Qué tal si pruebas otra cosa?"

# game/script.rpy:131
translate Spanish friend_input_7eae945c:

    # fren "Or...{w=1} you know."
    fren "O...{w=1} ya sabes."

# game/script.rpy:132
translate Spanish friend_input_79b34b9d:

    # fren "Give up."
    fren "Te rindes."

# game/script.rpy:135
translate Spanish friend_input_5cb3ac63:

    # mc "Tsk, fine, I'll ditch the letter idea."
    mc "Tsk, bien, descartaré la idea de la carta."

# game/script.rpy:136
translate Spanish friend_input_df507fdd:

    # fren "Wow."
    fren "Guau."

# game/script.rpy:137
translate Spanish friend_input_bd743ec7:

    # fren "For once, you actually listened."
    fren "Por una vez, de verdad hiciste caso."

# game/script.rpy:138
translate Spanish friend_input_c84f0a33:

    # mc "What is that suppose to mean?"
    mc "¿Y eso qué quiere decir?"

# game/script.rpy:139
translate Spanish friend_input_157788ca:

    # fren "Nothing."
    fren "Nada."

# game/script.rpy:140
translate Spanish friend_input_a78a53a8:

    # fren "Either way, if you're gonna ditch that letter... what's your other plan then?"
    fren "Como sea, si vas a descartar esa carta... ¿cuál es tu otro plan, entonces?"

# game/script.rpy:141
translate Spanish friend_input_5215eb9c:

    # "That's the one thing you actually didn't think about, actually!"
    "¡Eso es justo lo único en lo que no pensaste!"

# game/script.rpy:142
translate Spanish friend_input_2bfa3974:

    # "You wanted to say that, but you didn't want to look like an idiot already as you are right now."
    "Querías decirlo, pero no querías parecer más idiota de lo que ya pareces ahora mismo."

# game/script.rpy:143
translate Spanish friend_input_fe7a58e5:

    # mc "I can think of something after this!"
    mc "¡Puedo pensar en algo después de esto!"

# game/script.rpy:144
translate Spanish friend_input_ef42dc51:

    # mc "Just you wait!"
    mc "¡Ya verás!"

# game/script.rpy:145
translate Spanish friend_input_8900ccd7:

    # fren "Well you are, but it seems like your lover boy isn't."
    fren "Pues tú sí esperarás, pero parece que tu galán no."

# game/script.rpy:146
translate Spanish friend_input_8f49ad77:

    # "[fren] points towards the room's door. You turn your head to see Geo making his way outside."
    "[fren] señala hacia la puerta del salón. Giras la cabeza y ves a Geo saliendo."

# game/script.rpy:147
translate Spanish friend_input_387c1d4d:

    # "You didn't even realize half of the student body left the classroom, the hallway filled with chatter while the clock's hands are pointed towards 12, indicating lunch time."
    "Ni siquiera te diste cuenta de que la mitad del alumnado ya salió del salón, el pasillo se llenó de murmullos y las manecillas del reloj apuntan a las 12, indicando la hora del almuerzo."

# game/script.rpy:148
translate Spanish friend_input_9d2c4c4d:

    # mc "Fuck!{w=0.5} He's gonna get bombarded with fangirls and other people!"
    mc "¡Mierda!{w=0.5} ¡Lo van a acosar las fangirls y todo el mundo!"

# game/script.rpy:149
translate Spanish friend_input_f85eae90:

    # mc "I can't afford to let competition get in my way!"
    mc "¡No puedo permitir que la competencia se interponga en mi camino!"

# game/script.rpy:150
translate Spanish friend_input_3219cc1d:

    # "Not wasting anymore time, you dashed out of the classroom."
    "Sin perder más tiempo, saliste corriendo del salón."

# game/script.rpy:156
translate Spanish friend_input_f3af43d1:

    # mc "You know what?"
    mc "¿Sabes qué?"

# game/script.rpy:157
translate Spanish friend_input_83b129e5:

    # mc "You're right!"
    mc "¡Tienes razón!"

# game/script.rpy:159
translate Spanish friend_input_401b7bc9:

    # fren "Huh?"
    fren "¿Eh?"

# game/script.rpy:160
translate Spanish friend_input_15f3d2d5:

    # "You look down at the love letter in your hands before ripping it in half, proceeding to tear it to pieces. Your friend stared at you like you were some mad man."
    "Bajas la mirada hacia la carta de amor que tienes en las manos y la rompes por la mitad, para luego hacerla pedazos. Tu amiguis te miró como si hubieras perdido la cabeza."

# game/script.rpy:161
translate Spanish friend_input_9110cbb8:

    # fren "W...{w=1}wha..."
    fren "Q...{w=1}qué..."

# game/script.rpy:162
translate Spanish friend_input_dbd77156:

    # fren "Just like that?" with vpunch
    fren "¿Así, sin más?" with vpunch

# game/script.rpy:163
translate Spanish friend_input_a29f0500:

    # fren "You're actually going to give up just like that? {w=1}I mean, I wasn't pressuring you to {i}actually{/i} give up--" with vpunch
    fren "¿De verdad vas a rendirte así, sin más? {w=1}O sea, yo no te estaba presionando para que {i}de verdad{/i} te rindieras--" with vpunch

# game/script.rpy:164
translate Spanish friend_input_86b73bf8:

    # mc "Yes, I am giving up."
    mc "Sí, me rindo."

# game/script.rpy:165
translate Spanish friend_input_76c321f7:

    # "You slowly turn your head towards [fren]."
    "Giras lentamente la cabeza hacia [fren]."

# game/script.rpy:166
translate Spanish friend_input_2d1ee84b:

    # mc "I've been looking at the wrong person this whole time."
    mc "He estado mirando a la persona equivocada todo este tiempo."

# game/script.rpy:167
translate Spanish friend_input_9bea30da:

    # fren "HUH?" with vpunch
    fren "¿EH?" with vpunch

# game/script.rpy:168
translate Spanish friend_input_664a27c2:

    # fren "WOAH!" with vpunch
    fren "¡GUAU!" with vpunch

# game/script.rpy:169
translate Spanish friend_input_01899cf2:

    # fren "HOLD IT RIGHT THERE." with vpunch
    fren "ESPERA AHÍ MISMO." with vpunch

# game/script.rpy:170
translate Spanish friend_input_b602c717:

    # mc "DON'T RUN AWAY FROM MY LOVE!"
    mc "¡NO HUYAS DE MI AMOR!"

# game/script.rpy:173
translate Spanish friend_input_4b340443:

    # g "..."
    g "..."

# game/script.rpy:174
translate Spanish friend_input_471e3fd4:

    # g pose2 p2e3 p2m4 p2b3 "Am I...{w=1} free?"
    g pose2 p2e3 p2m4 p2b3 "¿Soy...{w=1} libre?"

# game/script.rpy:175
translate Spanish friend_input_923f3ae3:

    # g "{i}sigh"
    g "{i}suspiro"

# game/script.rpy:176
translate Spanish friend_input_c599d018:

    # g pose2 p2e1 p2m1 p2b1 "One down... a tons more to go off my back."
    g pose2 p2e1 p2m1 p2b1 "Uno menos... y aún faltan montones por quitarme de encima."

# game/script.rpy:180
translate Spanish friend_input_c2a9d370:

    # centered "{size=65}END: Bromance with your Bro.{/size}"
    centered "{size=65}FINAL: Bromance con tu Bro.{/size}"

# game/script.rpy:187
translate Spanish letter_end_6736f8c0:

    # mc "Nah, I think I'll go for my original plan."
    mc "Nah, creo que seguiré con mi plan original."

# game/script.rpy:188
translate Spanish letter_end_6f580cec:

    # "[fren] shrugs at your persistence."
    "[fren] se encoge de hombros ante tu terquedad."

# game/script.rpy:189
translate Spanish letter_end_89fdf9d3:

    # fren "Suit yourself."
    fren "Tú sabrás."

# game/script.rpy:190
translate Spanish letter_end_3079dfd1:

    # fren "Though{w=1}, don't say I didn't warn you and see you come crying to me."
    fren "Aunque{w=1}, no digas que no te lo advertí si luego vienes llorando a mí."

# game/script.rpy:194
translate Spanish letter_end_bd4d9c88:

    # "The school bell eventually rang, signaling the end of class, some packing up their things while some stayed."
    "La campana de la escuela terminó sonando, señalando el fin de la clase; algunos guardan sus cosas mientras otros se quedan."

# game/script.rpy:195
translate Spanish letter_end_42377ff7:

    # "One of them was none other than the lone wolf Geo."
    "Uno de ellos era nada menos que el lobo solitario, Geo."

# game/script.rpy:196
translate Spanish letter_end_064396aa:

    # mc "{i}'Now's my chance!'"
    mc "{i}'¡Es mi oportunidad!'"

# game/script.rpy:197
translate Spanish letter_end_5ae4e106:

    # "Carefully holding onto the envelope, you make your way towards Geo's seat."
    "Sujetando con cuidado el sobre, te diriges hacia el asiento de Geo."

# game/script.rpy:200
translate Spanish letter_end_d45b6919:

    # mc "{i}'Ha....{/i}"
    mc "{i}'Ha....{/i}"

# game/script.rpy:201
translate Spanish letter_end_4188b584:

    # mc "{i}'Be still my beating heart.'{/i}"
    mc "{i}'Cálmate, corazón mío.'{/i}"

# game/script.rpy:202
translate Spanish letter_end_c3a361d4:

    # mc "{i}'Why does he look so dreamy from here...'{/i}"
    mc "{i}'¿Por qué se ve tan de ensueño desde aquí...'{/i}"

# game/script.rpy:204
translate Spanish letter_end_80596312:

    # g "Are you just going to stand there and ogle or are you going to talk to me?"
    g "¿Vas a quedarte ahí devorándome con los ojos o vas a hablarme?"

# game/script.rpy:206
translate Spanish letter_end_ba5a18d1:

    # mc "{i}'HRK!'{i}"
    mc "{i}'¡HRK!'{i}"

# game/script.rpy:208
translate Spanish letter_end_8ee0c0a3:

    # g "If you want to stare, do it in another time, I have a paper to finish."
    g "Si quieres mirar, hazlo en otro momento; tengo un trabajo que terminar."

# game/script.rpy:210
translate Spanish letter_end_58737789:

    # mc "U{w=0.5}-um!{w=0.5} I actually.... {w=1}want to give you something!"
    mc "¡E{w=0.5}-eh!{w=0.5} En realidad.... {w=1}¡quiero darte algo!"

# game/script.rpy:212
translate Spanish letter_end_f8c3133b:

    # g "If it's another Valentine's Day letter, hand it over."
    g "Si es otra carta de San Valentín, entrégala."

# game/script.rpy:214
translate Spanish letter_end_1c5c50c6:

    # mc "{i}'Huh?'{/i}"
    mc "{i}'¿Eh?'{/i}"

# game/script.rpy:216
translate Spanish letter_end_deab273f:

    # g "Well?{w=1} Do you have it?"
    g "¿Y bien?{w=1} ¿La tienes?"

# game/script.rpy:218
translate Spanish letter_end_ddd96b13:

    # g "If not then leave, you're wasting my time."
    g "Si no, vete; me estás haciendo perder el tiempo."

# game/script.rpy:219
translate Spanish letter_end_23e84f5a:

    # mc "Ahh...."
    mc "Ahh...."

# game/script.rpy:220
translate Spanish letter_end_6b7b99db:

    # mc "{i}'There it is...{w=1} His harsh demeanor...'{/i}"
    mc "{i}'Ahí está...{w=1} Su carácter áspero...'{/i}"

# game/script.rpy:222
translate Spanish letter_end_5f73e4e7:

    # g "Can you stop ogling?"
    g "¿Puedes dejar de comerme con los ojos?"

# game/script.rpy:226
translate Spanish letter_end_a9be2196:

    # "Snapping out from your thoughts, you handed out the envelope towards him."
    "Saliendo de tus pensamientos, le extendiste el sobre."

# game/script.rpy:227
translate Spanish letter_end_a75ceca1:

    # mc "This is for you!"
    mc "¡Esto es para ti!"

# game/script.rpy:228
translate Spanish letter_end_d5848cc4:

    # g "Ha-{nw=0.5}"
    g "¡Ha-{nw=0.5}"

# game/script.rpy:229
translate Spanish letter_end_26a82663:

    # mc "I've worked hard on this just for you!"
    mc "¡Me esforcé mucho en esto solo para ti!"

# game/script.rpy:230
translate Spanish letter_end_02a63ca8:

    # g "Wha-"
    g "¿Qué-"

# game/script.rpy:231
translate Spanish letter_end_1fc8198e:

    # "Before you could let him finish, you made your way outside of the classroom, slamming the door as you did."
    "Antes de que pudiera terminar, saliste del salón dando un portazo."

# game/script.rpy:233
translate Spanish letter_end_ffa62260:

    # mc "Ahhh..."
    mc "Ahhh..."

# game/script.rpy:234
translate Spanish letter_end_10c77080:

    # mc "I{cps=5}...{/cps}I actually did it..."
    mc "L{cps=5}...{/cps}lo hice de verdad..."

# game/script.rpy:235
translate Spanish letter_end_a610a045:

    # mc "I gave it to him!"
    mc "¡Se lo di!"

# game/script.rpy:236
translate Spanish letter_end_495c3a62:

    # mc "This is the greatest achievement of my life!"
    mc "¡Este es el mayor logro de mi vida!"

# game/script.rpy:237
translate Spanish letter_end_f1633fb8:

    # mc "Wait"
    mc "Espera"

# game/script.rpy:238
translate Spanish letter_end_b9108e50:

    # mc "I forgot to get my things in the classroom...."
    mc "Olvidé recoger mis cosas en el salón...."

# game/script.rpy:239
translate Spanish letter_end_33e7aba2:

    # mc "I should text [fren] to get my things...."
    mc "Debería escribirle a [fren] para que me las traiga...."

# game/script.rpy:243
translate Spanish letter_end_3d9574e3:

    # fren "See you tomorrow, [mc]."
    fren "Nos vemos mañana, [mc]."

# game/script.rpy:244
translate Spanish letter_end_479b52e8:

    # "Waving [fren] goodbye, you make your way to the school's exit gate, a little skip in your steps from the events that occured today."
    "Despidiéndote de [fren] con la mano, te diriges a la puerta de salida de la escuela, con un saltito en tus pasos por lo ocurrido hoy."

# game/script.rpy:245
translate Spanish letter_end_a6257501:

    # "You couldn't help but daydream what would be the lone wolf's reaction once he reads your letter."
    "No puedes evitar imaginar cuál sería la reacción del lobo solitario cuando lea tu carta."

# game/script.rpy:246
translate Spanish letter_end_53ee8287:

    # "You put your whole heart and soul into writing that letter."
    "Pusiste todo tu corazón y tu alma en escribir esa carta."

# game/script.rpy:247
translate Spanish letter_end_900b8a25:

    # "Scented paper with your own blood as ink to let him know that it's literally from your heart."
    "Papel perfumado con tu propia sangre como tinta, para que sepa que literalmente viene de tu corazón."

# game/script.rpy:248
translate Spanish letter_end_ed4d4b1a:

    # "You remember the way you stabbed the tip of the pen's nib and sucking the life out of your blood vessel."
    "Recuerdas cómo te clavaste la punta de la plumilla y le chupaste la vida a tu propia vena."

# game/script.rpy:249
translate Spanish letter_end_f801b90d:

    # "Obviously{w=0.5}, all of that is not true.{w=0.5} If you actually did all that, you'd be seeing the hospital sooner than you'd imagine."
    "Obviamente{w=0.5}, nada de eso es cierto.{w=0.5} Si de verdad hubieras hecho todo eso, verías el hospital más pronto de lo que imaginas."

# game/script.rpy:250
translate Spanish letter_end_97c48111:

    # "But are you crazy enough to do that?"
    "Pero ¿tienes la locura suficiente para hacer eso?"

# game/script.rpy:253
translate Spanish letter_end_4526a14a:

    # "{color=#ff0090}Get some help.{/color}"
    "{color=#ff0090}Busca ayuda.{/color}"

# game/script.rpy:256
translate Spanish letter_end_6f19e982:

    # "{color=#ff0090}Thank god you're still sane.{/color}"
    "{color=#ff0090}Menos mal que conservas la cordura.{/color}"

# game/script.rpy:259
translate Spanish letter_end_c3be28f7:

    # "Making your way towards the bus stop, you look up at the sky, the sun's setting colors painting the clouds orange and yellow."
    "De camino a la parada del bus, miras al cielo; los colores del sol poniente pintan las nubes de naranja y amarillo."

# game/script.rpy:260
translate Spanish letter_end_e9f2b006:

    # "It looks really amazing."
    "Se ve realmente impresionante."

# game/script.rpy:261
translate Spanish letter_end_5f78b22f:

    # "Kind of reminds you of the color of flames."
    "Te recuerda un poco al color de las llamas."

# game/script.rpy:262
translate Spanish letter_end_d24b4156:

    # "Seriously, which motherfucker decided it was ok to burn leaves in a nearby alleyway?"
    "En serio, ¿qué hijo de puta decidió que estaba bien quemar hojas en un callejón cercano?"

# game/script.rpy:263
translate Spanish letter_end_450412f5:

    # "You hold your nose, making your way towards the alleyway."
    "Te tapas la nariz y te encaminas hacia el callejón."

# game/script.rpy:265
translate Spanish letter_end_010b11e4:

    # "The setting sun didn't shed too much light on the dark and narrow alleyway."
    "El sol poniente no aportaba mucha luz al oscuro y estrecho callejón."

# game/script.rpy:266
translate Spanish letter_end_e6113f05:

    # "The smoke coming from it wasn't helping either."
    "El humo que salía de allí tampoco ayudaba."

# game/script.rpy:267
translate Spanish letter_end_f2a66b8b:

    # mc "Seriously, I thought this shit isn't allowed---"
    mc "En serio, pensé que esta mierda no estaba permitida---"

# game/script.rpy:268
translate Spanish letter_end_4c26368d:

    # "As you were about to peak in you were abruptly cut off by a tall figure's torso nearly colliding with your face."
    "Cuando ibas a asomarte, te interrumpió de golpe el torso de una figura alta que casi choca con tu cara."

# game/script.rpy:271
translate Spanish letter_end_e5eaa31e:

    # g "Ah."
    g "Ah."

# game/script.rpy:272
translate Spanish letter_end_439a5640:

    # g m1 "You're still here."
    g m1 "Sigues aquí."

# game/script.rpy:273
translate Spanish letter_end_dfbd333b:

    # "It was Geo!"
    "¡Era Geo!"

# game/script.rpy:274
translate Spanish letter_end_605c229b:

    # "Fucking shit bro he smells like smoke."
    "Maldita sea, bro, huele a humo."

# game/script.rpy:275
translate Spanish letter_end_e206e1d4:

    # "It's probably because he's hot as hell."
    "Seguro es porque está que arde."

# game/script.rpy:276
translate Spanish letter_end_059fa84a:

    # g e1 "I'm leaving."
    g e1 "Me voy."

# game/script.rpy:277
translate Spanish letter_end_7c1ef0ea:

    # mc "NO WAIT-"
    mc "¡NO, ESPERA-"

# game/script.rpy:279
translate Spanish letter_end_39459c54:

    # "He didn't spare you a single glance before a nearby limousine came out of literal nowhere."
    "No te dedicó ni una sola mirada antes de que una limusina cercana apareciera de la nada, literalmente."

# game/script.rpy:280
translate Spanish letter_end_d1f17adb:

    # "One of the car's window rolls down, showing a man with an eyepatch over his left eye, his expression looking tired as ever."
    "Una de las ventanillas del auto baja y deja ver a un hombre con un parche en el ojo izquierdo, con una expresión tan cansada como siempre."

# game/script.rpy:281
translate Spanish letter_end_f2077440:

    # "He just stares at Geo and the said male merely scratched the back of his head then proceeding to open the car door and hopping in."
    "Solo mira a Geo y el aludido apenas se rasca la nuca para luego abrir la puerta del auto y subirse."

# game/script.rpy:282
translate Spanish letter_end_a17c50a9:

    # mc "And there he goes..."
    mc "Y ahí se va..."

# game/script.rpy:283
translate Spanish letter_end_ecf872dc:

    # mc "Wait."
    mc "Espera."

# game/script.rpy:284
translate Spanish letter_end_3eab98f7:

    # mc "He came from the alleyway right?!"
    mc "¡Salió del callejón, ¿cierto?!"

# game/script.rpy:285
translate Spanish letter_end_4e178501:

    # mc "Does that mean--"
    mc "¿Eso significa que--"

# game/script.rpy:286
translate Spanish letter_end_5a496397:

    # "Finally remembering your original plan, you ran towards one of the bins, the remnants of smoke still lingering in the air."
    "Al recordar por fin tu plan original, corriste hacia uno de los contenedores, con los restos del humo aún flotando en el aire."

# game/script.rpy:287
translate Spanish letter_end_aa83ab06:

    # "You look down, not even dare attempting to rummage through it."
    "Bajas la mirada, sin atreverte siquiera a intentar revolver."

# game/script.rpy:288
translate Spanish letter_end_a74e8b38:

    # "I mean obviously, you'll burn yourself."
    "O sea, obvio, te quemarías."

# game/script.rpy:289
translate Spanish letter_end_e4e378dc:

    # "And at the corner of your eye, you spot the ever so familiar shred of pink."
    "Y por el rabillo del ojo, ves ese trozo de rosa tan familiar."

# game/script.rpy:290
translate Spanish letter_end_6d870d92:

    # "That's your letter."
    "Es tu carta."

# game/script.rpy:291
translate Spanish letter_end_f4ede371:

    # "You feel your heart shatter."
    "Sientes que tu corazón se rompe."

# game/script.rpy:292
translate Spanish letter_end_436b3a8c:

    # "You know you should be used to it by now considering the past few years' attempts."
    "Sabes que a estas alturas ya deberías haberte acostumbrado, considerando los intentos de los últimos años."

# game/script.rpy:293
translate Spanish letter_end_783e6a40:

    # "But damn."
    "Pero, carajo."

# game/script.rpy:294
translate Spanish letter_end_bd11dbc6:

    # "{color=#ff0090}He's a tough cookie.{/color}"
    "{color=#ff0090}Es un hueso duro de roer.{/color}"

# game/script.rpy:295
translate Spanish letter_end_6de1a4cc:

    # "{color=#ff0090}Welp!{w=0.5} Better luck next time [mc].{/color}"
    "{color=#ff0090}¡Bueno!{w=0.5} Mejor suerte la próxima vez, [mc].{/color}"

# game/script.rpy:299
translate Spanish letter_end_366852b4:

    # centered "{size=50} END: BURNED LETTER{/size}"
    centered "{size=50} FINAL: CARTA QUEMADA{/size}"

# game/script.rpy:304
translate Spanish letter_end_5b81589c:

    # "You were too distracted by this man's beautiful complexion that you fail to notice his glare."
    "Tienes la mente tan puesta en la hermosa tez de este hombre que no notas su mirada fulminante."

# game/script.rpy:305
translate Spanish letter_end_bcad223e:

    # "But heck, who cares? He's hot when he's mad."
    "Pero, ¿a quién le importa? Enojado está buenísimo."

# game/script.rpy:306
translate Spanish letter_end_c5da6915:

    # "He's standing up. Oh... {w=1}you nearly forgot how tall he is."
    "Se está poniendo de pie. Oh... {w=1}casi olvidabas lo alto que es."

# game/script.rpy:307
translate Spanish letter_end_28a6d3af:

    # "He's looking down at you, he leans closer."
    "Te mira desde arriba, se inclina más cerca."

# game/script.rpy:308
translate Spanish letter_end_504b6f09:

    # mc "{i}'Is he going to do what I think he's going to do?!'{/i}"
    mc "{i}'¡¿Va a hacer lo que creo que va a hacer?!'{/i}"

# game/script.rpy:309
translate Spanish letter_end_d278bfb4:

    # mc "{i}'This might be my only chance!{w=1} Quickly [mc], close your eyes{w=1}, lean forward..."
    mc "{i}'¡Esta podría ser mi única oportunidad!{w=1} ¡Rápido, [mc], cierra los ojos{w=1}, inclínate hacia adelante..."

# game/script.rpy:311
translate Spanish letter_end_641800c0:

    # "You feel Geo's large hands wrapping around your waist as he slowly lifts you up."
    "Sientes las grandes manos de Geo rodeando tu cintura mientras te levanta lentamente."

# game/script.rpy:315
translate Spanish letter_end_465c54c1:

    # mc "{cps=5}........{/cps}"
    mc "{cps=5}........{/cps}"

# game/script.rpy:316
translate Spanish letter_end_05500ff6:

    # mc "Huh?"
    mc "¿Eh?"

# game/script.rpy:319
translate Spanish letter_end_c73d302b:

    # g "Get{w=1} out."
    g "Lár{w=1}gate."

# game/script.rpy:322
translate Spanish letter_end_376b225c:

    # mc "{cps=5}.......{/cps}"
    mc "{cps=5}.......{/cps}"

# game/script.rpy:323
translate Spanish letter_end_581de2db:

    # mc "Did...{w=1} Did he just kicked me out?"
    mc "¿Acaso...{w=1} acaba de echarme?"

# game/script.rpy:324
translate Spanish letter_end_62682b58:

    # "You feel a slight vibration within your pockets. You take out your phone, a small message from no other than [fren]."
    "Sientes una ligera vibración en el bolsillo. Sacas tu teléfono: un pequeño mensaje de nada menos que [fren]."

# game/script.rpy:327
translate Spanish letter_end_85196620:

    # mc "Tsk, cocky bitch."
    mc "Tsk, pedazo de creído."

# game/script.rpy:329
translate Spanish letter_end_7007eedc:

    # mc "My letter! I should go back and give my letter--{nw=0.5}"
    mc "¡Mi carta! Debería volver y darle mi carta--{nw=0.5}"

# game/script.rpy:330
translate Spanish letter_end_974fd071:

    # fan "KYAAA! THERE HE IS!"
    fan "¡KYAAA! ¡AHÍ ESTÁ!"

# game/script.rpy:331
translate Spanish letter_end_550b4a4f:

    # fan "QUICK! BEFORE HE LEAVES!"
    fan "¡RÁPIDO! ¡ANTES DE QUE SE VAYA!"

# game/script.rpy:333
translate Spanish letter_end_e382f3d8:

    # g "Fuck!"
    g "¡Mierda!"

# game/script.rpy:334
translate Spanish letter_end_1f24f9be:

    # mc "W-wait! Geo!"
    mc "¡E-espera! ¡Geo!"

# game/script.rpy:336
translate Spanish letter_end_1a6ee205:

    # "From the other end of the classroom door was Geo. So, did he slam the door on your face for dramatic effect? Maybe."
    "Al otro lado de la puerta del salón estaba Geo. Entonces, ¿te cerró la puerta en la cara para darle dramatismo? Tal vez."

# game/script.rpy:337
translate Spanish letter_end_9b17c43c:

    # "But none of that matters at the situation at hand as Geo quickly went on a sprint, leaving the classroom door open, [fren] poking their head out to see what the commotion was about."
    "Pero nada de eso importa dada la situación, pues Geo salió disparado, dejando la puerta del salón abierta, mientras [fren] asoma la cabeza para ver a qué se debía el alboroto."

# game/script.rpy:338
translate Spanish letter_end_e1c18efa:

    # fren "Aw shit, it's the fangirls again."
    fren "Ay, mierda, son las fangirls otra vez."

# game/script.rpy:339
translate Spanish letter_end_1b8551e6:

    # fren "HEY! [mc]! Better start running!"
    fren "¡OYE! ¡[mc]! ¡Más te vale empezar a correr!"

# game/script.rpy:341
translate Spanish letter_end_eff7dd65:

    # "Is the ground shaking?"
    "¿Está temblando el suelo?"

# game/script.rpy:342
translate Spanish letter_end_ada5b854:

    # fanboy "SUBARU! {w=1}WAIT FOR ME!" with vpunch
    fanboy "¡SUBARU! {w=1}¡ESPÉRAME!" with vpunch

# game/script.rpy:343
translate Spanish letter_end_aee86e48:

    # fan "I PROMISE THIS YEAR IS BETTER!" with vpunch
    fan "¡PROMETO QUE ESTE AÑO SERÁ MEJOR!" with vpunch

# game/script.rpy:344
translate Spanish letter_end_16650cee:

    # fanboy "MOVE ASIDE PUNK, HE'S MINE!" with vpunch
    fanboy "¡APÁRTATE, PUNK, ES MÍO!" with vpunch

# game/script.rpy:345
translate Spanish letter_end_144adae2:

    # "A crowd of fans came running towards your direction and towards to where Geo took off."
    "Una multitud de fans venía corriendo hacia donde estás y hacia donde Geo salió disparado."

# game/script.rpy:346
translate Spanish letter_end_031c0597:

    # "{color=#ff0090}You better move aside unles you want to end up being roadkill.{/color}"
    "{color=#ff0090}Más te vale apartarte, a menos que quieras terminar como un animal atropellado.{/color}"

# game/script.rpy:347
translate Spanish letter_end_29d36d28:

    # mc "Wait--!"
    mc "¡Espera--!"

# game/script.rpy:348
translate Spanish letter_end_b847567e:

    # "Before you could even start questioning where this voice in your head was coming from, you were bombarded with a crowd of Geo's fangirls trampling you over."
    "Antes de que pudieras siquiera preguntarte de dónde venía esa voz en tu cabeza, una multitud de fangirls de Geo te pasó por encima."

# game/script.rpy:349
translate Spanish letter_end_af9af63b:

    # "And the next thing you knew, you blacked out."
    "Y lo siguiente que supiste fue que perdiste el conocimiento."

# game/script.rpy:352
translate Spanish letter_end_de0d4ea3:

    # "{cps=5}......"
    "{cps=5}......"

# game/script.rpy:353
translate Spanish letter_end_b7505fae:

    # fren "So...."
    fren "Entonces...."

# game/script.rpy:354
translate Spanish letter_end_cf2c9993:

    # fren "Judging from your condition right now, it did {i}not{/i} go as you'd hope it would be, huh?"
    fren "A juzgar por tu estado actual, {i}no{/i} salió como esperabas, ¿eh?"

# game/script.rpy:355
translate Spanish letter_end_f4d5bcd7:

    # fren "Well{w=0.5}, better luck next time [mc]."
    fren "Bueno{w=0.5}, mejor suerte la próxima vez, [mc]."

# game/script.rpy:356
translate Spanish letter_end_ca987036:

    # fren "Now for your hospital bill on the other hand..."
    fren "Y en cuanto a tu cuenta del hospital..."

# game/script.rpy:360
translate Spanish letter_end_88959205:

    # mc "Augh...."
    mc "Augh...."

# game/script.rpy:361
translate Spanish letter_end_9486173a:

    # mc "Thankfully I managed to survive that fangirl stampede."
    mc "Menos mal que logré sobrevivir a esa estampida de fangirls."

# game/script.rpy:362
translate Spanish letter_end_ae2c5c55:

    # mc "[fren] just over reacting about the hospital bill."
    mc "[fren] está exagerando con lo de la cuenta del hospital."

# game/script.rpy:363
translate Spanish letter_end_3138bfc2:

    # "The hospital bill in question is lunch on you for tomorrow after your beloved [fren] helped carrying you to the school clinic."
    "La cuenta del hospital en cuestión es el almuerzo de mañana, que corre por tu cuenta, después de que tu adorable [fren] te llevara cargando hasta la enfermería de la escuela."

# game/script.rpy:364
translate Spanish letter_end_ada25cf0:

    # "And thankfully, you still had time to make it for lunch."
    "Y por suerte, aún tenías tiempo de llegar al almuerzo."

# game/script.rpy:365
translate Spanish letter_end_64420dbc:

    # "You could've asked for [fren] to send you lunch, but that's added to their unknown charges."
    "Podrías haberle pedido a [fren] que te trajera el almuerzo, pero eso se sumaría a sus cargos ocultos."

# game/script.rpy:366
translate Spanish letter_end_fe129b6d:

    # "With that out of the way, you make your way towards the school's cafeteria."
    "Con eso resuelto, te diriges a la cafetería de la escuela."

# game/script.rpy:372
translate Spanish cont_0943d565:

    # "The moment you stepped in the cafeteria, you were greeted a mixture of stale food, student's sweaty odor, and cleaning products."
    "En cuanto pusiste un pie en la cafetería, te recibió una mezcla de comida rancia, olor a sudor de estudiantes y productos de limpieza."

# game/script.rpy:373
translate Spanish cont_c38873f9:

    # "Obviously it wasn't a great smell to be greeted with."
    "Obviamente no es un buen olor para recibir a alguien."

# game/script.rpy:374
translate Spanish cont_6d8e5ecd:

    # "But that's not the main point as to why you are here."
    "Pero ese no es el motivo principal por el que estás aquí."

# game/script.rpy:375
translate Spanish cont_0ed4dea9:

    # "You're here to impress the boy of your dreams."
    "Estás aquí para impresionar al chico de tus sueños."

# game/script.rpy:376
translate Spanish cont_22028ad6:

    # "Now to just find him!"
    "¡Ahora solo falta encontrarlo!"

# game/script.rpy:377
translate Spanish cont_c9172bfc:

    # "Usually, you would drag [fren] into your little hunt for the lone wolf."
    "Normalmente arrastrarías a [fren] a tu pequeña cacería del lobo solitario."

# game/script.rpy:378
translate Spanish cont_96d5bee6:

    # "However, they're being shackled by the hands of research, so you're left alone in the sea of tired and sweaty college students."
    "Sin embargo, la investigación no deja libre a [fren], así que te toca arreglártelas sin compañía en un mar de universitarios cansados y sudorosos."

# game/script.rpy:379
translate Spanish cont_88cc8d67:

    # fan "God, he's so dreamy!"
    fan "¡Dios, es un sueño!"

# game/script.rpy:382
translate Spanish cont_5fddb61a:

    # fan "And to add to the eye candy, the pretty boy Ichabod is with him too!"
    fan "¡Y como si fuera poco para la vista, el chico lindo de Ichabod también está con él!"

# game/script.rpy:383
translate Spanish cont_1b8823cf:

    # fan "Ichabod? Where's the usual jock that he is with?"
    fan "¿Ichabod? ¿Dónde está el deportista con el que suele andar?"

# game/script.rpy:384
translate Spanish cont_0771a95b:

    # fan "Eh, probably ended up getting scolded by his coach or something."
    fan "Eh, probablemente lo regañó su entrenador o algo así."

# game/script.rpy:387
translate Spanish cont_f82be576:

    # fan "I know right? Too bad he's around that loud jock."
    fan "¡Lo sé! Qué lástima que ande con ese deportista escandaloso."

# game/script.rpy:388
translate Spanish cont_78436205:

    # fan "How lucky is he hanging around {i}the{/i} Oogami Subaru!"
    fan "¡Qué suerte tiene de juntarse con {i}el{/i} Oogami Subaru!"

# game/script.rpy:390
translate Spanish cont_806cefd6:

    # "Well that didn't take too much effort. Local loud fangirls aren't even going to hide the fact they know where he is located and who he is with."
    "Bueno, eso no requirió mucho esfuerzo. Las fangirls escandalosas del lugar ni siquiera se molestan en ocultar que saben dónde está y con quién."

# game/script.rpy:391
translate Spanish cont_e00ba40b:

    # "Like you're any better."
    "Como si tú fueras mejor."

# game/script.rpy:392
translate Spanish cont_960a109c:

    # "But since you decided to ditch your old plan of handing him a traditional love letter, you will need to think of something else."
    "Pero como decidiste descartar tu viejo plan de entregarle una carta de amor tradicional, tendrás que pensar en otra cosa."

# game/script.rpy:396
translate Spanish cont_343fd402:

    # "You have nothing else to lose, and it's not like you have anything to offer."
    "No tienes nada más que perder, y tampoco es que tengas algo que ofrecer."

# game/script.rpy:397
translate Spanish cont_956644e0:

    # "Unless he's fine taking you as yourself."
    "A menos que le parezca bien tomarte tal como eres."

# game/script.rpy:398
translate Spanish cont_27287220:

    # "But no!{w=0.5} You must impress him!{w=0.5} You must leave an impactful impression so that he will bother to remember you."
    "¡Pero no!{w=0.5} ¡Debes impresionarlo!{w=0.5} Debes dejar una impresión impactante para que se moleste en recordarte."

# game/script.rpy:399
translate Spanish cont_2dcb325f:

    # "One step at a time, you can hear your heart beating faster and faster the closer you approach Geo's table."
    "Paso a paso, oyes cómo tu corazón late cada vez más rápido a medida que te acercas a la mesa de Geo."

# game/script.rpy:401
translate Spanish cont_05431a61:

    # "He's currently in a conversation with the school's prince, his expression bored as ever as he chews on his sandwich."
    "Ahora mismo conversa con el príncipe de la escuela, con su expresión aburrida de siempre mientras mastica su sándwich."

# game/script.rpy:403
translate Spanish cont_4865016d:

    # "He's currently in a conversation with a jock beside him, his expression bored as ever as he chews on his sandwich."
    "Ahora mismo conversa con un deportista a su lado, con su expresión aburrida de siempre mientras mastica su sándwich."

# game/script.rpy:405
translate Spanish cont_2c10406c:

    # "You're getting drunk from the scent of his sandwich mixed with the tiled floor's chemicals."
    "Te estás mareando con el aroma de su sándwich mezclado con los químicos del piso de baldosas."

# game/script.rpy:406
translate Spanish cont_8a175833:

    # "{bt=10}You want to throw up.{/bt}"
    "{bt=10}Tienes ganas de vomitar.{/bt}"

# game/script.rpy:409
translate Spanish cont_396bd16f:

    # g "Hm?"
    g "¿Hm?"

# game/script.rpy:410
translate Spanish cont_1249f026:

    # g base e3 m6 b2 barf "WHA--" with vpunch
    g base e3 m6 b2 barf "¡¿QUÉ--?!" with vpunch

# game/script.rpy:414
translate Spanish cont_2b851c1e:

    # crowe "My goodness! Are you alright? We should get you to the clinic."
    crowe "¡Dios mío! ¿Estás bien? Deberíamos llevarte a la enfermería."

# game/script.rpy:416
translate Spanish cont_25f0e5bd:

    # deryl "Woah there!{w=0.5} You look green!{w=0.5} Do you need to go to the clinic?"
    deryl "¡Epa, con calma!{w=0.5} ¡Estás verde!{w=0.5} ¿Necesitas ir a la enfermería?"

# game/script.rpy:417
translate Spanish cont_84d821a6:

    # "The clinic?!{w=0.5} No!{w=0.5} You don't need to go there!"
    "¡¿La enfermería?!{w=0.5} ¡No!{w=0.5} ¡No necesitas ir allá!"

# game/script.rpy:418
translate Spanish cont_6b64b324:

    # "You're close to your target;{w=0.5} his eyes are on you now!{w=1}{cps=15}{bt=10} You just need to spit out the words you want to say...{/bt}{/cps}"
    "¡Estás cerca de tu objetivo;{w=0.5} ahora sus ojos están sobre ti!{w=1}{cps=15}{bt=10} Solo tienes que soltar las palabras que quieres decir...{/bt}{/cps}"

# game/script.rpy:419
translate Spanish cont_f95454d0:

    # "The words you {sc=5}{b}NEED{/b}{/sc} to say!"
    "¡Las palabras que {sc=5}{b}NECESITAS{/b}{/sc} decir!"

# game/script.rpy:421
translate Spanish cont_3fd26243:

    # crowe "Ah!" with vpunch
    crowe "¡Ah!" with vpunch

# game/script.rpy:422
translate Spanish cont_9e45406e:

    # crowe "You stay here, I'm going to call for a teacher."
    crowe "Quédate aquí, voy a llamar a un profesor."

# game/script.rpy:423
translate Spanish cont_55d42dbe:

    # crowe "Don't push yourself any further, okay?"
    crowe "No te esfuerces más, ¿sí?"

# game/script.rpy:425
translate Spanish cont_0b6e76e2:

    # deryl "Woah!" with vpunch
    deryl "¡Guau!" with vpunch

# game/script.rpy:426
translate Spanish cont_ce9f0176:

    # deryl "Okay!"
    deryl "¡Okey!"

# game/script.rpy:427
translate Spanish cont_89bcb894:

    # deryl "Someone grab a mop!"
    deryl "¡Que alguien traiga un trapeador!"

# game/script.rpy:428
translate Spanish cont_dc108f81:

    # fan "GEO ARE YOU OKAY?!" with vpunch
    fan "¡¿GEO, ESTÁS BIEN?!" with vpunch

# game/script.rpy:429
translate Spanish cont_24d05189:

    # fan "HOW DARE YOU DIRTY SUBARU-KUN'S HOODIE LIKE THAT?!" with vpunch
    fan "¡¿CÓMO TE ATREVES A ENSUCIAR ASÍ LA SUDADERA DE SUBARU-KUN?!" with vpunch

# game/script.rpy:432
translate Spanish cont_8fc28c1e:

    # g "{cps=5}.......{/cps}"
    g "{cps=5}.......{/cps}"

# game/script.rpy:433
translate Spanish cont_d42d5d78:

    # "Did you seriously just threw up?"
    "¿De verdad acabas de vomitar?"

# game/script.rpy:434
translate Spanish cont_bb5aa652:

    # "So much for being confident!"
    "¡Adiós a la confianza!"

# game/script.rpy:435
translate Spanish cont_b49b4b49:

    # g base e1 m6 b1 "Eugh...."
    g base e1 m6 b1 "Puaj...."

# game/script.rpy:436
translate Spanish cont_229c360c:

    # g base e2 m7 b2 "You."
    g base e2 m7 b2 "Tú."

# game/script.rpy:438
translate Spanish cont_8969c8d4:

    # mc "EEP!"
    mc "¡EEP!"

# game/script.rpy:439
translate Spanish cont_749618a8:

    # g "I'm giving you one last chance to either run or apologize."
    g "Te doy una última oportunidad: o huyes o te disculpas."

# game/script.rpy:440
translate Spanish cont_d3d7f0f1:

    # g "Spit it out."
    g "Escúpelo."

# game/script.rpy:441
translate Spanish cont_9635bb85:

    # mc "I....I!"
    mc "Yo....¡yo!"

# game/script.rpy:446
translate Spanish cont_5928f79f:

    # g "{cps=5}......{/cps}"
    g "{cps=5}......{/cps}"

# game/script.rpy:447
translate Spanish cont_c6a9f90b:

    # g base e4 m3 b2 "Is that it?"
    g base e4 m3 b2 "¿Eso es todo?"

# game/script.rpy:448
translate Spanish cont_de16a936:

    # mc "{i}'HUh!?'{/i}"
    mc "{i}'¿¡EH!?'{/i}"

# game/script.rpy:450
translate Spanish cont_197f98dc:

    # "The obvious irritation on his face grew increasingly stern; your breakfast all over his hoodie was now an afterthought as he leaned closer to your face."
    "La evidente irritación en su rostro se volvió cada vez más severa; tu desayuno por toda su sudadera pasó a ser lo de menos mientras se inclinaba hacia tu cara."

# game/script.rpy:453
translate Spanish cont_675542f4:

    # g "You want my answer so bad, don't you?"
    g "Quieres tanto mi respuesta, ¿no?"

# game/script.rpy:454
translate Spanish cont_d2635b1b:

    # g "Let me make this clear to you, peasant."
    g "Déjame dejártelo claro, plebe."

# game/script.rpy:456
translate Spanish cont_156e32b8:

    # g "I don't feel the same."
    g "No siento lo mismo."

# game/script.rpy:457
translate Spanish cont_7a7947be:

    # g "The feelings I have right now are disgust, anger, and irritation."
    g "Lo que siento ahora mismo es asco, ira e irritación."

# game/script.rpy:458
translate Spanish cont_63a55e13:

    # g "And I'm giving you 10 more seconds to run."
    g "Y te doy 10 segundos más para correr."

# game/script.rpy:459
translate Spanish cont_9757b1b7:

    # "You kind of stopped listening to him on the 'I don't feel the same' part. Your heart aches when he says those words, numbing your hearing. You didn't even realize he was slowly counting down."
    "Dejaste de escucharlo más o menos en la parte de 'No siento lo mismo'. Te duele el corazón cuando dice esas palabras y se te adormece el oído. Ni siquiera te diste cuenta de que iba contando lentamente hacia atrás."

# game/script.rpy:462
translate Spanish cont_651ac70e:

    # teacher "What the hell is going on in here?"
    teacher "¿Qué demonios está pasando aquí?"

# game/script.rpy:463
translate Spanish cont_f1e02c60:

    # "The teacher's authoritative voice echoed throughout the cafeteria, silencing the students' chattering."
    "La voz autoritaria del profesor resonó por toda la cafetería y acalló el parloteo de los estudiantes."

# game/script.rpy:464
translate Spanish cont_5b8694d8:

    # "Geo stopped glaring at you."
    "Geo dejó de fulminarte con la mirada."

# game/script.rpy:465
translate Spanish cont_373c01da:

    # "His eyes now focused on his friend right next to the teacher, a mop in one hand."
    "Sus ojos se centraron ahora en su amigo, justo al lado del profesor, con un trapeador en una mano."

# game/script.rpy:466
translate Spanish cont_e424e5bd:

    # "He makes his way towards you with the teacher in tow."
    "Se abre paso hacia ti con el profesor siguiéndole."

# game/script.rpy:467
translate Spanish cont_976963ae:

    # teacher "[mc], correct? Let's get you to the clinic so that you can clean yourself up."
    teacher "[mc], ¿cierto? Vamos a la enfermería para que puedas limpiarte."

# game/script.rpy:468
translate Spanish cont_bfab5e01:

    # teacher "Thank you for calling me, Ichabod."
    teacher "Gracias por llamarme, Ichabod."

# game/script.rpy:469
translate Spanish cont_cab4fb41:

    # "Crowe said nothing, merely nodding and proceeding to mop your breakfast off the floor."
    "Crowe no dijo nada, solo asintió y procedió a limpiar tu desayuno del suelo con el trapeador."

# game/script.rpy:472
translate Spanish cont_36d0bbd3:

    # "Your trip to the clinic went well. You managed to get a new set of clothes. But the one thing that the clinic didn't help you with is your aching heart."
    "Tu visita a la enfermería salió bien. Conseguiste un cambio de ropa. Pero lo único con lo que la enfermería no pudo ayudarte es con tu corazón dolido."

# game/script.rpy:474
translate Spanish cont_d8fff0d7:

    # "You got a text from [fren] saying that your rejection is currently the school's spicy gossip."
    "Recibiste un mensaje de [fren] diciendo que tu rechazo es ahora el chisme más picante de la escuela."

# game/script.rpy:475
translate Spanish cont_7d1d079b:

    # "So not only do you have to cope with rejection, but you also have to face humiliation tomorrow. For sure, you're going to get looks from other students."
    "Así que no solo tienes que lidiar con el rechazo, sino también con la humillación de mañana. Seguro te lloverán las miradas de los demás estudiantes."

# game/script.rpy:476
translate Spanish cont_bfed087d:

    # fren "So{cps=5}....{/cps}{w=0.5} was it worth it?"
    fren "Entonces{cps=5}....{/cps}{w=0.5} ¿valió la pena?"

# game/script.rpy:477
translate Spanish cont_8e5a94fd:

    # mc "... You're here just to humiliate me, right?"
    mc "... Solo viniste a humillarme, ¿verdad?"

# game/script.rpy:478
translate Spanish cont_97ff515a:

    # fren "Pfft-"
    fren "Pfft-"

# game/script.rpy:479
translate Spanish cont_c1ea4a7b:

    # mc "SO RUDE!"
    mc "¡QUÉ DESCARO!"

# game/script.rpy:480
translate Spanish cont_74fae99c:

    # fren "Hey, I was right, though!"
    fren "¡Oye, pero tenía razón!"

# game/script.rpy:481
translate Spanish cont_e28aa00e:

    # fren "Out of all the guys you have to get the hots on, it has to be him."
    fren "De todos los chicos que podían gustarte, tenías que fijarte en él."

# game/script.rpy:482
translate Spanish cont_f15f1c1c:

    # fren "That's alright [mc]. Maybe you can try again next year?"
    fren "No pasa nada, [mc]. ¿Quizá puedes intentarlo otra vez el año que viene?"

# game/script.rpy:483
translate Spanish cont_aeb99b73:

    # fren "Knowing you are such a persistent person."
    fren "Conociéndote, que eres de lo más persistente."

# game/script.rpy:484
translate Spanish cont_1c811d91:

    # "You know what? Maybe [fren] has a point. You have next year to think about a better plan!"
    "¿Sabes qué? Quizá [fren] tiene razón. ¡Tienes el año que viene para pensar en un mejor plan!"

# game/script.rpy:485
translate Spanish cont_f01a696b:

    # "{i}'Maybe a whole new wedding plan?'{/i}"
    "{i}'¿Quizá un plan de boda completamente nuevo?'{/i}"

# game/script.rpy:486
translate Spanish cont_bb81b9e4:

    # fren "{color=#ff0090}That's taking it too far.{/color}"
    fren "{color=#ff0090}Eso es llevarlo demasiado lejos.{/color}"

# game/script.rpy:487
translate Spanish cont_6084e809:

    # mc "Stop reading my mind!"
    mc "¡Deja de leerme la mente!"

# game/script.rpy:488
translate Spanish cont_0b1af046:

    # "Well, whatever your plan is, I wish you the best of luck, [mc]."
    "Bueno, sea cual sea tu plan, te deseo la mejor de las suertes, [mc]."

# game/script.rpy:489
translate Spanish cont_605860c1:

    # "Just hope the wolf will go easy on you in your future endeavors."
    "Solo espero que el lobo sea indulgente contigo en tus futuros intentos."

# game/script.rpy:493
translate Spanish cont_129e8a3a:

    # centered "{size=50} END: REJECTED{/size}\n\n{size=25} (but you'll live){/size}"
    centered "{size=50} FINAL: RECHAZADO{/size}\n\n{size=25} (pero sobrevivirás){/size}"

# game/script.rpy:496
translate Spanish cont_d0fad833:

    # "You feel a nudge on your elbow."
    "Sientes un empujón en el codo."

# game/script.rpy:497
translate Spanish cont_9ee36054:

    # "Then a poke."
    "Luego un toque."

# game/script.rpy:498
translate Spanish cont_b7258fd6:

    # "Then a jab."
    "Luego un codazo."

# game/script.rpy:499
translate Spanish cont_5e11400a:

    # mc "Ow, bitch??"
    mc "¡Auch, ¿qué carajos?!"

# game/script.rpy:500
translate Spanish cont_ead2aeb3:

    # "Who the fuck is interrupting you while you're busy feeling like absolute shit right now?!"
    "¡¿Quién carajos te interrumpe justo ahora que estás sintiéndote como una completa mierda?!"

# game/script.rpy:501
translate Spanish cont_94427e61:

    # "You meet eyes with the jock who was accompanying Geo. His eyes filled with concern and fear."
    "Cruzas la mirada con el deportista que acompañaba a Geo. Tiene los ojos llenos de preocupación y miedo."

# game/script.rpy:502
translate Spanish cont_383bed7b:

    # "But mostly fear. He had a mop on his right hand, and his grip on it was a bit hard."
    "Pero sobre todo miedo. Tenía un trapeador en la mano derecha y lo agarraba con bastante fuerza."

# game/script.rpy:503
translate Spanish cont_534c2bb9:

    # "One thing's for sure, though."
    "Aunque una cosa es segura."

# game/script.rpy:504
translate Spanish cont_70649507:

    # "He's telling you to run."
    "Te está diciendo que corras."

# game/script.rpy:505
translate Spanish cont_5093966d:

    # "Before you knew it, you were hurled away by the jock, throwing you out and giving you a head start on your sprint. You did not care about the number of looks thrown at you; Geo probably had it worse."
    "Antes de que te dieras cuenta, el deportista te lanzó lejos, echándote y dándote ventaja en tu carrera. No te importó la cantidad de miradas que te lanzaron; seguramente Geo la tenía peor."

# game/script.rpy:506
translate Spanish cont_f7b20019:

    # "But one thing's for sure. Geo hates you now, and the whole school body knows about it."
    "Pero una cosa es segura. Geo ahora te odia, y toda la escuela lo sabe."

# game/script.rpy:510
translate Spanish cont_4e106cd8:

    # centered "{size=50} END: REJECTED{/size}"
    centered "{size=50} FINAL: RECHAZADO{/size}"

# game/script.rpy:513
translate Spanish cont_c901fe37:

    # "What the fuck? Did you actually threw up on his hoodie in front of everyone in the cafeteria?"
    "¿Qué carajos? ¿De verdad vomitaste sobre su sudadera frente a toda la cafetería?"

# game/script.rpy:514
translate Spanish cont_492df01e:

    # "Yes, yes, you did, idiot."
    "Sí, sí lo hiciste, idiota."

# game/script.rpy:516
translate Spanish cont_af7e781b:

    # "You don't need my stupid voice of the narrator to remind how much you fucked up."
    "No necesitas mi estúpida voz de narrador para recordarte lo mucho que la cagaste."

# game/script.rpy:517
translate Spanish cont_eea3030e:

    # "You bowed and went down on your knees, holding onto your stomach as you did so as you tried your best not to throw up again."
    "Te inclinaste y caíste de rodillas, sujetándote el estómago mientras hacías lo posible por no vomitar otra vez."

# game/script.rpy:519
translate Spanish cont_651ac70e_1:

    # teacher "What the hell is going on in here?"
    teacher "¿Qué demonios está pasando aquí?"

# game/script.rpy:520
translate Spanish cont_f1e02c60_1:

    # "The teacher's authoritative voice echoed throughout the cafeteria, silencing the students' chattering."
    "La voz autoritaria del profesor resonó por toda la cafetería y acalló el parloteo de los estudiantes."

# game/script.rpy:521
translate Spanish cont_5b8694d8_1:

    # "Geo stopped glaring at you."
    "Geo dejó de fulminarte con la mirada."

# game/script.rpy:522
translate Spanish cont_373c01da_1:

    # "His eyes now focused on his friend right next to the teacher, a mop in one hand."
    "Sus ojos se centraron ahora en su amigo, justo al lado del profesor, con un trapeador en una mano."

# game/script.rpy:523
translate Spanish cont_e424e5bd_1:

    # "He makes his way towards you with the teacher in tow."
    "Se abre paso hacia ti con el profesor siguiéndole."

# game/script.rpy:524
translate Spanish cont_976963ae_1:

    # teacher "[mc], correct? Let's get you to the clinic so that you can clean yourself up."
    teacher "[mc], ¿cierto? Vamos a la enfermería para que puedas limpiarte."

# game/script.rpy:525
translate Spanish cont_bfab5e01_1:

    # teacher "Thank you for calling me, Ichabod."
    teacher "Gracias por llamarme, Ichabod."

# game/script.rpy:526
translate Spanish cont_cab4fb41_1:

    # "Crowe said nothing, merely nodding and proceeding to mop your breakfast off the floor."
    "Crowe no dijo nada, solo asintió y procedió a limpiar tu desayuno del suelo con el trapeador."

# game/script.rpy:530
translate Spanish cont_887047ac:

    # "Just then, you feel a hand on your shoulder and peek at who it is. It was the jock, and on one hand is a mop."
    "En ese momento sientes una mano en el hombro y miras de quién es. Es el deportista, y en una mano lleva un trapeador."

# game/script.rpy:531
translate Spanish cont_58ee262e:

    # "He eyes you with a bit of concern on his face. He said nothing but helped you stand your ground."
    "Te mira con un dejo de preocupación en el rostro. No dice nada, pero te ayuda a mantenerte en pie."

# game/script.rpy:532
translate Spanish cont_baacd99f:

    # deryl "I think you need to head towards the clinic. Don't worry; I already called a teacher to help you out."
    deryl "Creo que necesitas ir a la enfermería. No te preocupes; ya llamé a un profesor para que te ayude."

# game/script.rpy:533
translate Spanish cont_b51ec63b:

    # "He said with a soft tone in his voice as if trying to help you relax during your predicament."
    "Lo dice con un tono suave, como si intentara ayudarte a relajarte en tu aprieto."

# game/script.rpy:534
translate Spanish cont_fdb2b709:

    # "You haven't even apologized yet, but this jock is already pushing you out!"
    "¡Ni siquiera te has disculpado todavía y este deportista ya te está echando!"

# game/script.rpy:535
translate Spanish cont_82160997:

    # "But then he leans in close to your ear, his previous calming and sweet demeanor gone and is now replaced with dread."
    "Pero entonces se inclina hacia tu oído, y su actitud tranquila y dulce de antes desaparece, reemplazada por pavor."

# game/script.rpy:536
translate Spanish cont_38433e93:

    # deryl "Make a run for it."
    deryl "Sal corriendo."

# game/script.rpy:537
translate Spanish cont_db44567c:

    # "He lifts you by your elbow then nudges you away towards the cafeteria's exit."
    "Te levanta por el codo y luego te empuja hacia la salida de la cafetería."

# game/script.rpy:538
translate Spanish cont_1eb829dd:

    # deryl "Geo, my man! Let's get you cleaned up, huh? Good thing you always pack up extra clothes!"
    deryl "¡Geo, mi hermano! ¡Vamos a limpiarte, ¿sí?! ¡Menos mal que siempre llevas ropa extra!"

# game/script.rpy:539
translate Spanish cont_8c92cd23:

    # "The blue-haired male diverts his attention from your departing frame to his tall best friend, the irritated flame in his eyes now extinguished as he sighs."
    "El chico de cabello azul aparta la atención de tu figura que se aleja y la dirige a su alto mejor amigo; la llama de irritación en sus ojos se extingue mientras suspira."

# game/script.rpy:543
translate Spanish cont_a32d4afa:

    # "Your stomach hurts so bad!!!{w=1} You need to get the fuck out of here!"
    "¡¡¡Te duele muchísimo el estómago!!!{w=1} ¡Tienes que largarte de aquí ya!"

# game/script.rpy:544
translate Spanish cont_51899af5:

    # mc "EXCUSE ME!"
    mc "¡CON PERMISO!"

# game/script.rpy:545
translate Spanish cont_dc82af55:

    # "Not even bothering to give Geo an ounce of your attention, you quickly shoved your way out of the crowd."
    "Sin molestarte siquiera en dedicarle a Geo una pizca de atención, te abriste paso a empujones entre la multitud."

# game/script.rpy:546
translate Spanish cont_2176b449:

    # "You can vaguely hear his friend calling out to you but fall on deaf ears as you push through the sea of students toward the exit."
    "Oyes vagamente a su amigo llamándote, pero cae en oídos sordos mientras te abres paso entre el mar de estudiantes hacia la salida."

# game/script.rpy:551
translate Spanish cont_3904bec8:

    # "You vaguely remember that the school's gardening club has a stall selling flowers for Valentine's Day."
    "Recuerdas vagamente que el club de jardinería de la escuela tiene un puesto que vende flores por San Valentín."

# game/script.rpy:552
translate Spanish cont_0985e3d0:

    # "You can buy a bouquet and give it to him after classes!"
    "¡Puedes comprar un ramo y dárselo después de clases!"

# game/script.rpy:553
translate Spanish cont_faa0b08f:

    # "Yeah, that might be a good idea!"
    "¡Sí, esa podría ser una buena idea!"

# game/script.rpy:554
translate Spanish cont_fa3cb4bc:

    # "For now, you'll just look at him from afar and watch him eat his lunch."
    "Por ahora, solo lo mirarás de lejos mientras almuerza."

# game/script.rpy:555
translate Spanish cont_5ae6759d:

    # "Too bad there's that jock blocking your vision, but that doesn't matter; as long as you're breathing in the same air as him, then everything's alright."
    "Lástima que ese deportista te tape la vista, pero no importa; mientras respires el mismo aire que él, todo está bien."

# game/script.rpy:556
translate Spanish cont_b5134f60:

    # "Save for the foul smell of bleach."
    "Salvo por el hedor a lejía."

# game/script.rpy:557
translate Spanish cont_f7e28169:

    # "Seriously, they should take it easy on the cleaning products."
    "En serio, deberían ir con más calma con los productos de limpieza."

# game/script.rpy:562
translate Spanish cont_d8fe7115:

    # "You vaguely remember the school having a small stall selling chocolates right by the school's entrance. Maybe you can buy some once school's over."
    "Recuerdas vagamente que la escuela tiene un pequeño puesto de chocolates justo en la entrada. Quizá puedas comprar algunos cuando terminen las clases."

# game/script.rpy:563
translate Spanish cont_fa3cb4bc_1:

    # "For now, you'll just look at him from afar and watch him eat his lunch."
    "Por ahora, solo lo mirarás de lejos mientras almuerza."

# game/script.rpy:564
translate Spanish cont_5ae6759d_1:

    # "Too bad there's that jock blocking your vision, but that doesn't matter; as long as you're breathing in the same air as him, then everything's alright."
    "Lástima que ese deportista te tape la vista, pero no importa; mientras respires el mismo aire que él, todo está bien."

# game/script.rpy:565
translate Spanish cont_b5134f60_1:

    # "Save for the foul smell of bleach."
    "Salvo por el hedor a lejía."

# game/script.rpy:566
translate Spanish cont_f7e28169_1:

    # "Seriously, they should take it easy on the cleaning products."
    "En serio, deberían ir con más calma con los productos de limpieza."

# game/script.rpy:569
translate Spanish cont_34344c0c:

    # "We're going with the bolder approach. It's not as bad as the first idea; it's still stupid, but not much of a bad idea."
    "Vamos con el enfoque más audaz. No es tan malo como la primera idea; sigue siendo estúpido, pero no es una idea tan mala."

# game/script.rpy:570
translate Spanish cont_ce142ba6:

    # "You lined up with the rest of the students, buying lunch while keeping your eye on Geo; his attention is still on his friend."
    "Hiciste fila con el resto de los estudiantes, comprando almuerzo sin quitarle los ojos de encima a Geo; su atención sigue puesta en su amigo."

# game/script.rpy:571
translate Spanish cont_789db2a6:

    # "You can't tell if he's listening to his companion, but he looks bored."
    "No sabes si está escuchando a su acompañante, pero se ve aburrido."

# game/script.rpy:572
translate Spanish cont_74d2ab0c:

    # "You eventually got your tray filled with your choice of food. You honestly didn't pay too much attention to what you got as long as it seemed you were trying to buy something."
    "Al final conseguiste llenar tu bandeja con la comida que elegiste. Sinceramente no prestaste mucha atención a lo que agarraste, mientras pareciera que intentabas comprar algo."

# game/script.rpy:573
translate Spanish cont_61aa2f22:

    # "You scan the area; half of the cafeteria is now filled with students eating."
    "Recorres el lugar con la vista; la mitad de la cafetería ya está llena de estudiantes comiendo."

# game/script.rpy:574
translate Spanish cont_b7123a8c:

    # "Spotting Geo, you made your way towards him."
    "Al ver a Geo, te encaminaste hacia él."

# game/script.rpy:576
translate Spanish cont_f0fb280f:

    # "He and his brown-haired companion are in a deep conversation, but mostly Ichabod was the one talking, Geo was simply listening."
    "Él y su acompañante de cabello castaño están en plena conversación, aunque sobre todo hablaba Ichabod, mientras Geo simplemente escuchaba."

# game/script.rpy:579
translate Spanish cont_bcea9ab3:

    # "Geo and his companion are in a deep conversation, but mostly it was the jock running his mouth on and on with the navy blue-haired male simply letting his words pass through one ear to the other."
    "Geo y su acompañante están en plena conversación, aunque casi todo el tiempo era el deportista quien hablaba sin parar, mientras el chico de cabello azul marino dejaba que sus palabras le entraran por un oído y le salieran por el otro."

# game/script.rpy:580
translate Spanish cont_bd47a5bb:

    # "You swallowed your nervousness, steadying your hold on your tray."
    "Te tragaste los nervios y afirmaste el agarre de tu bandeja."

# game/script.rpy:581
translate Spanish cont_bf52a6c8:

    # "His companion eventually took notice of your lone figure standing still because the next thing he did was give you a big wave; this caused Geo to raise a brow and turn his attention towards you."
    "Su acompañante terminó por notar tu figura solitaria e inmóvil, porque lo siguiente que hizo fue saludarte con la mano de forma exagerada; esto hizo que Geo alzara una ceja y dirigiera su atención hacia ti."

# game/script.rpy:582
translate Spanish cont_a8a49104:

    # "You feel your heart drop down to your stomach, forming into butterflies."
    "Sientes que el corazón te cae hasta el estómago y se transforma en mariposas."

# game/script.rpy:584
translate Spanish cont_3be36c31:

    # crowe "Do you need a seat?"
    crowe "¿Necesitas un asiento?"

# game/script.rpy:585
translate Spanish cont_399f90c5:

    # crowe "You're free to join us!"
    crowe "¡Puedes sentarte con nosotros!"

# game/script.rpy:587
translate Spanish cont_28ef1b80:

    # g base e1 m7 b1 "Seriously? We don't even know this person."
    g base e1 m7 b1 "¿En serio? Ni siquiera conocemos a esta persona."

# game/script.rpy:589
translate Spanish cont_b0b57101:

    # crowe "Come on now, Geo, it won't hurt inviting someone else new. Plus, the others are busy and can't join us."
    crowe "Vamos, Geo, no hace daño invitar a alguien nuevo. Además, los demás están ocupados y no pueden acompañarnos."

# game/script.rpy:591
translate Spanish cont_24f6ec7a:

    # "Geo groans at Ichabod's words, rolling his eyes but did not protest."
    "Geo gruñe ante las palabras de Ichabod, pone los ojos en blanco pero no protesta."

# game/script.rpy:593
translate Spanish cont_213532dc:

    # "Crowe gives you a smile and offers you a seat across them."
    "Crowe te regala una sonrisa y te ofrece un asiento frente a ellos."

# game/script.rpy:594
translate Spanish cont_d42b822c:

    # "You shift a bit on your seat, feeling your heart beating faster."
    "Te acomodas un poco en tu asiento, sintiendo cómo tu corazón late más rápido."

# game/script.rpy:595
translate Spanish cont_abc8bb9a:

    # "You can also clearly feel a few glares shooting behind your back."
    "También sientes claramente algunas miradas fulminantes clavadas en tu espalda."

# game/script.rpy:596
translate Spanish cont_ae4f1209:

    # "But if you were in their place, you'd understand completely. Across from you are two of the most gorgeous men in this school."
    "Pero si estuvieras en su lugar, lo entenderías perfectamente. Frente a ti están dos de los hombres más guapos de esta escuela."

# game/script.rpy:597
translate Spanish cont_8b4c8238:

    # "They both look like they can be from the Higher Class, the way both Geo and Ichabod carry themselves along with how they act and talk."
    "Ambos parecen de la Clase Alta, por cómo se comportan Geo e Ichabod, y por su forma de actuar y de hablar."

# game/script.rpy:598
translate Spanish cont_94ade86e:

    # "You sometimes wonder how they ended up in the lower class."
    "A veces te preguntas cómo terminaron en la clase baja."

# game/script.rpy:599
translate Spanish cont_fc9393f4:

    # crowe "Are you alright? You haven't touched your food."
    crowe "¿Estás bien? No has tocado tu comida."

# game/script.rpy:600
translate Spanish cont_ca17de99:

    # crowe "Is the cafeteria's food really not that great?"
    crowe "¿De verdad la comida de la cafetería no es tan buena?"

# game/script.rpy:602
translate Spanish cont_8754e78e:

    # g base e1 m1 b3 "Why don't you try out for yourself?"
    g base e1 m1 b3 "¿Por qué no lo pruebas tú mismo?"

# game/script.rpy:604
translate Spanish cont_d9a1f96f:

    # "Geo speaks up, half surprising you, knowing he isn't usually the one to initiate talk with anyone."
    "Geo toma la palabra, sorprendiéndote a medias, sabiendo que normalmente no es él quien inicia conversación con nadie."

# game/script.rpy:605
translate Spanish cont_0a4d32ba:

    # "Ichabod proceeds to scoop up a piece of rice on his plate, trying out the cafeteria's food. He lets out a hum, his eyebrows furrowed, processing the flavor that passed through his mouth."
    "Ichabod toma un poco de arroz de su plato para probar la comida de la cafetería. Suelta un murmullo, con el ceño fruncido, procesando el sabor que le pasó por la boca."

# game/script.rpy:606
translate Spanish cont_b6e2aca3:

    # crowe "Could use more seasoning..."
    crowe "Le vendría bien más sazón..."

# game/script.rpy:607
translate Spanish cont_f18282a1:

    # crowe "I don't usually buy lunch here, so this is quite an experience for me."
    crowe "No suelo comprar el almuerzo aquí, así que esto es toda una experiencia para mí."

# game/script.rpy:612
translate Spanish cont_05b748f7:

    # g "Hey, you got some on your face."
    g "Oye, tienes un poco en la cara."

# game/script.rpy:613
translate Spanish cont_737dcebb:

    # crowe "Huh?"
    crowe "¿Eh?"

# game/script.rpy:614
translate Spanish cont_f46787e4:

    # "Geo takes a handkerchief out from one of his pockets, and without even thinking, he wipes off a stray piece of carrot away from Ichabod's face."
    "Geo saca un pañuelo de uno de sus bolsillos y, sin pensarlo, le quita de la cara a Ichabod un trozo suelto de zanahoria."

# game/script.rpy:615
translate Spanish cont_f03fcdeb:

    # crowe "Oh! Thank you, Geo."
    crowe "¡Oh! Gracias, Geo."

# game/script.rpy:616
translate Spanish cont_d5950344:

    # crowe "Though, you didn't need to do all that, right?"
    crowe "Aunque no hacía falta que hicieras todo eso, ¿no?"

# game/script.rpy:617
translate Spanish cont_5f6005a9:

    # "Realizing what he just did, Geo's ears turned red, and he quickly looked away from his friend while gripping his handkerchief."
    "Al darse cuenta de lo que acaba de hacer, a Geo se le ponen rojas las orejas y aparta rápidamente la mirada de su amigo mientras aprieta su pañuelo."

# game/script.rpy:618
translate Spanish cont_ba5e5d15:

    # g "Sorry... Force of habit."
    g "Perdón... Fuerza de la costumbre."

# game/script.rpy:619
translate Spanish cont_c3cfbe72:

    # "Force of habit?"
    "¿Fuerza de la costumbre?"

# game/script.rpy:620
translate Spanish cont_0d4a8947:

    # crowe "That's alright, I know you care."
    crowe "Está bien, sé que te importo."

# game/script.rpy:623
translate Spanish cont_f7a165ff:

    # "{cps=5}.....{/cps}"
    "{cps=5}.....{/cps}"

# game/script.rpy:624
translate Spanish cont_b2c65302:

    # "HE CARES?!"
    "¡¿LE IMPORTA?!"

# game/script.rpy:625
translate Spanish cont_7e70f5aa:

    # "HOLD ON JUST A SECOND."
    "ESPERA UN SEGUNDO."

# game/script.rpy:626
translate Spanish cont_f8cbf8ab:

    # "Ichabod's soft look towards Geo... The way Geo's demeanor completely changed to something so soft..."
    "La mirada suave de Ichabod hacia Geo... La forma en que la actitud de Geo cambió por completo a algo tan suave..."

# game/script.rpy:627
translate Spanish cont_175e97f7:

    # "Their closeness nearly reminds you of the BL drama series you watched the night before...."
    "Su cercanía casi te recuerda a la serie de dramas BL que viste anoche...."

# game/script.rpy:628
translate Spanish cont_7072f3b4:

    # "No..."
    "No..."

# game/script.rpy:629
translate Spanish cont_7973b14a:

    # "This couldn't be!"
    "¡Esto no puede ser!"

# game/script.rpy:630
translate Spanish cont_5f9b772e:

    # "...."
    "...."

# game/script.rpy:631
translate Spanish cont_614ff79b:

    # "Could it?!"
    "¡¿Será que sí?!"

# game/script.rpy:632
translate Spanish cont_8fa20781:

    # crowe "Oh! I'm sorry, I nearly forgot you're here before us. I apologize!"
    crowe "¡Oh! Perdón, casi olvido que estás aquí frente a nosotros. ¡Mis disculpas!"

# game/script.rpy:633
translate Spanish cont_fca52b7c:

    # crowe "But if you aren't enjoying the school's cafeteria food, I'll try to do something about it!"
    crowe "¡Pero si no estás disfrutando la comida de la cafetería de la escuela, intentaré hacer algo al respecto!"

# game/script.rpy:635
translate Spanish cont_7e19cb04:

    # "You didn't even care to listen to what this man was saying. You're too distracted looking at Geo in absolute shock to process what's happening around you."
    "Ni siquiera te molestaste en escuchar lo que decía este hombre. Tienes la mirada tan fija en Geo, en absoluto shock, que no logras procesar lo que sucede a tu alrededor."

# game/script.rpy:636
translate Spanish cont_e1d35d6b:

    # "Geo's posture lax, his expression soft and not in its usual glare."
    "La postura de Geo está relajada, su expresión suave y sin su habitual mirada fulminante."

# game/script.rpy:637
translate Spanish cont_acbf012a:

    # "You slowly turn your head to look at Ichabod. He continues with his lunch, not seeming to mind you anymore."
    "Giras lentamente la cabeza para mirar a Ichabod. Él sigue con su almuerzo, sin parecer prestarte ya atención."

# game/script.rpy:638
translate Spanish cont_f1e14578:

    # "How could you compete with someone like Ichabod?!"
    "¡¿Cómo podrías competir con alguien como Ichabod?!"

# game/script.rpy:639
translate Spanish cont_a76e2e42:

    # "This cannot be!"
    "¡Esto no puede ser!"

# game/script.rpy:640
translate Spanish cont_ffe13325:

    # "You need to know..."
    "Necesitas saber..."

# game/script.rpy:641
translate Spanish cont_ee1b0a8f:

    # "YOU NEED TO KNOW IF ICHABOD'S A POTENTIAL RIVAL!"
    "¡NECESITAS SABER SI ICHABOD ES UN POSIBLE RIVAL!"

# game/script.rpy:644
translate Spanish cont_f595e8b0:

    # "Lunchtime eventually ended, and you didn't get to enjoy your food for the rest of lunchtime, for your mind was elsewhere, still processing the unusual dynamic between the two males."
    "La hora del almuerzo terminó por fin, y no pudiste disfrutar tu comida en lo que quedaba de ella, pues tu mente estaba en otra parte, todavía procesando la inusual dinámica entre los dos chicos."

# game/script.rpy:645
translate Spanish cont_dc375386:

    # "And every time you think back on their intimate interactions, you can feel anger."
    "Y cada vez que recuerdas sus interacciones íntimas, sientes rabia."

# game/script.rpy:646
translate Spanish cont_897c2d8b:

    # "Dread with a mix of jealousy."
    "Pavor mezclado con celos."

# game/script.rpy:647
translate Spanish cont_65884f40:

    # "You need to get to the bottom of this!"
    "¡Tienes que llegar al fondo de esto!"

# game/script.rpy:648
translate Spanish cont_38d287bb:

    # "You need to know if Ichabod's a potential rival!"
    "¡Necesitas saber si Ichabod es un posible rival!"

# game/script.rpy:651
translate Spanish cont_f95a75c9:

    # deryl "Hey there! You need a seat?"
    deryl "¡Hola! ¿Necesitas un asiento?"

# game/script.rpy:652
translate Spanish cont_cbe47c77:

    # deryl "You can join us if you want!"
    deryl "¡Puedes unirte a nosotros si quieres!"

# game/script.rpy:654
translate Spanish cont_517af8da:

    # g base e2 m3 b3 "Are you serious? We don't even know this person."
    g base e2 m3 b3 "¿Estás hablando en serio? Ni siquiera conocemos a esta persona."

# game/script.rpy:656
translate Spanish cont_7bff0f2a:

    # deryl "Come on now, bro, they look so pitiful just standing there."
    deryl "Vamos, bro, se ve tan lamentable ahí de pie."

# game/script.rpy:657
translate Spanish cont_9a4e3401:

    # deryl "Like a lost puppy."
    deryl "Como un cachorro perdido."

# game/script.rpy:658
translate Spanish cont_27a04a8c:

    # deryl "Plus, I can't be the only one yapping my mouth here; I know you're not listening to me anyway."
    deryl "Además, no puedo ser el único que parlotea aquí; sé que de todos modos no me estás escuchando."

# game/script.rpy:660
translate Spanish cont_9b9515cf:

    # "That seemed to shut Geo's mouth, for he did not protest, simply giving the jock a groan and then a glare."
    "Eso pareció cerrarle la boca a Geo, pues no protestó; solo le soltó un gruñido al deportista y luego una mirada fulminante."

# game/script.rpy:661
translate Spanish cont_c87995a3:

    # "You took this chance to sit across from them."
    "Aprovechaste la ocasión para sentarte frente a ellos."

# game/script.rpy:662
translate Spanish cont_60201d9b:

    # deryl "So... ya got a name?"
    deryl "Entonces... ¿tienes nombre?"

# game/script.rpy:663
translate Spanish cont_8fbcde53:

    # mc "It's [mc]."
    mc "Soy [mc]."

# game/script.rpy:664
translate Spanish cont_9e4354a6:

    # deryl "[mc]! Nice to meet you! I'm Deryl! And this guy right here is Subaru!"
    deryl "¡[mc]! ¡Mucho gusto! ¡Yo soy Deryl! ¡Y este de aquí es Subaru!"

# game/script.rpy:665
translate Spanish cont_64781649:

    # "The jock greets you with a wide smile while patting Geo's shoulder, introducing you to him as if you weren't already aware of Geo's existence."
    "El deportista te saluda con una amplia sonrisa mientras le da una palmada en el hombro a Geo, presentándotelo como si no estuvieras ya al tanto de su existencia."

# game/script.rpy:666
translate Spanish cont_75cf7368:

    # deryl "How about you [mc]? Which class are you from?"
    deryl "¿Y tú, [mc]? ¿De qué clase eres?"

# game/script.rpy:667
translate Spanish cont_26f71e67:

    # mc "Oh! Um. Class D, ethics and psychology."
    mc "¡Oh! Eh. Clase D, ética y psicología."

# game/script.rpy:668
translate Spanish cont_25130793:

    # deryl "For real? Guess that you and good 'ol Geo here have similar classes!"
    deryl "¿En serio? ¡Entonces tú y el buen Geo comparten clases!"

# game/script.rpy:669
translate Spanish cont_3a9160b6:

    # deryl "Hey! You never told me you're classmates with [mc]!"
    deryl "¡Oye! ¡Nunca me dijiste que compartes clase con [mc]!"

# game/script.rpy:671
translate Spanish cont_1d557177:

    # g e2 m3 b2 "It is none of your business."
    g e2 m3 b2 "No es asunto tuyo."

# game/script.rpy:672
translate Spanish cont_7330936c:

    # g m6 "And stop nudging me! I'm eating!"
    g m6 "¡Y deja de darme codazos! ¡Estoy comiendo!"

# game/script.rpy:673
translate Spanish cont_96277361:

    # deryl "Haha! Woah, sorry about that!"
    deryl "¡Jaja! ¡Guau, perdón por eso!"

# game/script.rpy:674
translate Spanish cont_1ca82a8a:

    # deryl "Hey, you got a stray rice on your face."
    deryl "Oye, tienes un grano de arroz suelto en la cara."

# game/script.rpy:675
translate Spanish cont_bef5fec8:

    # g e3 m4 "Don't fucking touch me!"
    g e3 m4 "¡No me toques, carajo!"

# game/script.rpy:678
translate Spanish cont_3df1a334:

    # "What...."
    "Qué...."

# game/script.rpy:680
translate Spanish cont_37e50b1f:

    # "What is this scene before you?!"
    "¡¿Qué es esta escena ante tus ojos?!"

# game/script.rpy:681
translate Spanish cont_b5afc32c:

    # "They look so intimate!"
    "¡Se ven tan íntimos!"

# game/script.rpy:682
translate Spanish cont_8844892e:

    # "The way Deryl's large hands wrap around Geo's shoulder, the other hand wiping the stray rice located on the corner of his plump lips, his face red from embarrassment as he stubbornly struggles away from the jock's stronghold."
    "La forma en que las grandes manos de Deryl rodean el hombro de Geo, mientras con la otra mano le limpia el grano de arroz de la comisura de sus labios carnosos, con la cara roja de vergüenza mientras forcejea obstinadamente para zafarse del agarre del deportista."

# game/script.rpy:683
translate Spanish cont_ad2125ac:

    # "This almost feels like it came out of a BL drama series you binged the night before!"
    "¡Esto casi parece sacado de una serie dramática BL que te maratoneaste anoche!"

# game/script.rpy:684
translate Spanish cont_74e96ed5:

    # "No way..."
    "Imposible..."

# game/script.rpy:685
translate Spanish cont_6068bb0b:

    # "NO FUCKING WAY!"
    "¡NO PUEDE SER, MALDITA SEA!"

# game/script.rpy:686
translate Spanish cont_f4b6ffed:

    # "THIS CANNOT BE!"
    "¡ESTO NO PUEDE SER!"

# game/script.rpy:689
translate Spanish cont_4c95391d:

    # deryl "Hm? What's wrong [mc]? You look like you've seen a ghost."
    deryl "¿Hm? ¿Qué pasa, [mc]? Pareces haber visto un fantasma."

# game/script.rpy:690
translate Spanish cont_62b84171:

    # mc "N-nothing! I'm just surprised at how close you both are! HAHAHAHHA."
    mc "¡N-nada! ¡Solo me sorprende lo cercanos que son! JAJAJAJAJA."

# game/script.rpy:691
translate Spanish cont_2f6551df:

    # "You let out the driest laugh, drier than the Sahara desert. Deep in your heart, you can feel something burning within."
    "Sueltas la risa más seca, más seca que el desierto del Sahara. En lo profundo de tu corazón, sientes que algo arde."

# game/script.rpy:692
translate Spanish cont_2671b0d7:

    # deryl "Oh, we go wayyyy back, don't we?"
    deryl "Oh, nos conocemos desde haaace mucho, ¿verdad?"

# game/script.rpy:694
translate Spanish cont_c852dc04:

    # g e3 m4 b2 "Let me eat in peace!" with vpunch
    g e3 m4 b2 "¡Déjame comer en paz!" with vpunch

# game/script.rpy:695
translate Spanish cont_1359ddc6:

    # "And the jock, clueless and aloof, missed the way you were sending him glares."
    "Y el deportista, despistado y ajeno, no notó las miradas fulminantes que le lanzabas."

# game/script.rpy:697
translate Spanish cont_bf3ad139:

    # "{i}'How come he manages to be so close with Geo!? The one and only Subaru Oogami!?{/i}"
    "{i}'¡¿Cómo es que logra estar tan cerca de Geo?! ¡¿El único e inigualable Subaru Oogami?!{/i}"

# game/script.rpy:698
translate Spanish cont_6c98769c:

    # "{i}What are his secrets?!"
    "{i}¡¿Cuáles son sus secretos?!"

# game/script.rpy:699
translate Spanish cont_ef86ce33:

    # "{i}Or is Geo secretly into stupid jocks?!"
    "{i}¡¿O es que a Geo le gustan en secreto los deportistas estúpidos?!"

# game/script.rpy:702
translate Spanish cont_f595e8b0_1:

    # "Lunchtime eventually ended, and you didn't get to enjoy your food for the rest of lunchtime, for your mind was elsewhere, still processing the unusual dynamic between the two males."
    "La hora del almuerzo terminó por fin, y no pudiste disfrutar tu comida en lo que quedaba de ella, pues tu mente estaba en otra parte, todavía procesando la inusual dinámica entre los dos chicos."

# game/script.rpy:703
translate Spanish cont_dc375386_1:

    # "And every time you think back on their intimate interactions, you can feel anger."
    "Y cada vez que recuerdas sus interacciones íntimas, sientes rabia."

# game/script.rpy:704
translate Spanish cont_7292bd52:

    # "Jealousy."
    "Celos."

# game/script.rpy:705
translate Spanish cont_65884f40_1:

    # "You need to get to the bottom of this!"
    "¡Tienes que llegar al fondo de esto!"

# game/script.rpy:706
translate Spanish cont_46701e45:

    # "You need to know if Deryl's a potential rival!"
    "¡Necesitas saber si Deryl es un posible rival!"

# game/script.rpy:720
translate Spanish end_day_1317b67f:

    # "With the [gift] in your hands, you nervously left the school's building."
    "Con tu regalo en las manos, saliste nerviosamente del edificio de la escuela."

# game/script.rpy:722
translate Spanish end_day_41bc2baa:

    # "Clenching onto the neatly wrapped bouquet, you earnestly shift your eyes left and right, scanning through the crowd of students, hoping to see the familiar navy blue hair of the boy of your dreams."
    "Aferrando el ramo cuidadosamente envuelto, mueves los ojos con ansiedad de izquierda a derecha, escudriñando la multitud de estudiantes, con la esperanza de ver el familiar cabello azul marino del chico de tus sueños."

# game/script.rpy:724
translate Spanish end_day_035e90bc:

    # "Clenching onto the velvet box, you earnestly shift your eyes left and right, scanning through the crowd of students, hoping to see the familiar navy blue hair of the boy of your dreams."
    "Aferrando la caja de terciopelo, mueves los ojos con ansiedad de izquierda a derecha, escudriñando la multitud de estudiantes, con la esperanza de ver el familiar cabello azul marino del chico de tus sueños."

# game/script.rpy:726
translate Spanish end_day_11682913:

    # g e1 m7 b1 "Sorry, I don't need more of these things."
    g e1 m7 b1 "Perdón, no necesito más de estas cosas."

# game/script.rpy:727
translate Spanish end_day_40717991:

    # fan "But--"
    fan "Pero--"

# game/script.rpy:728
translate Spanish end_day_39ec80d2:

    # g m1 "Leave."
    g m1 "Lárgate."

# game/script.rpy:730
translate Spanish end_day_127d2192:

    # "Just like a moth to a flame, your eyes perked upon hearing Geo's familiar voice. His friend is with him during lunch, witnessing another poor sap rejected on this faithful day of love."
    "Como una polilla a la llama, tus ojos se alzan al oír la voz familiar de Geo. Su amigo está con él durante el almuerzo, presenciando cómo rechazan a otro pobre diablo en este fatídico día del amor."

# game/script.rpy:731
translate Spanish end_day_094820ef:

    # "Not you, though."
    "Pero tú no."

# game/script.rpy:732
translate Spanish end_day_2c55fb64:

    # "You came in prepared with your wonderful gift."
    "Tú sí viniste con tu maravilloso regalo preparado."

# game/script.rpy:733
translate Spanish end_day_2043dbe8:

    # mc "Geo!"
    mc "¡Geo!"

# game/script.rpy:734
translate Spanish end_day_67309ec9:

    # "You call out to him before he could even turn."
    "Lo llamas antes de que siquiera pudiera voltear."

# game/script.rpy:735
translate Spanish end_day_1e2324bf:

    # "Well, he was about to ignore you if it weren't for his friend abruptly stopping him by putting a hand on his shoulder. Seems like you caught his friend's attention rather than Geo himself."
    "Bueno, estaba a punto de ignorarte si su amigo no lo hubiera detenido de golpe poniéndole una mano en el hombro. Parece que llamaste más la atención de su amigo que la del propio Geo."

# game/script.rpy:737
translate Spanish end_day_2c6ad2c4:

    # crowe "Give this person a chance?"
    crowe "¿Le damos una oportunidad a esta persona?"

# game/script.rpy:739
translate Spanish end_day_98f76aaf:

    # g e2 m2 b1 "I have no time for this, Ichabod."
    g e2 m2 b1 "No tengo tiempo para esto, Ichabod."

# game/script.rpy:740
translate Spanish end_day_318d5197:

    # crowe "It's rude to ignore someone calling out to you. Maybe this won't be as bad as the last one?"
    crowe "Es de mala educación ignorar a alguien que te llama. ¿Quizá esta no sea tan mala como la anterior?"

# game/script.rpy:742
translate Spanish end_day_7a973d2a:

    # deryl "Woah man! Hold it there, you can't just ignore someone who called out to you!"
    deryl "¡Guau, hombre! ¡Alto ahí, no puedes ignorar a alguien que te llamó!"

# game/script.rpy:744
translate Spanish end_day_21dd7864:

    # g e1 m2 b1 "This is already enough time wasted. I want to go home."
    g e1 m2 b1 "Ya es suficiente tiempo perdido. Quiero irme a casa."

# game/script.rpy:745
translate Spanish end_day_6ffc39f0:

    # deryl "Hey! Maybe this person would be better than the last; who knows?"
    deryl "¡Oye! Quizá esta persona sea mejor que la anterior, ¿quién sabe?"

# game/script.rpy:747
translate Spanish end_day_3c7994ff:

    # "Geo gives his friend a glare, and the fellow merely gives him a smile and a thumbs up before leaving the scene."
    "Geo le lanza una mirada fulminante a su amigo, y este solo le sonríe y le hace un pulgar arriba antes de retirarse."

# game/script.rpy:748
translate Spanish end_day_f92cc048:

    # "Maybe his friend isn't as bad as people think they are."
    "Quizá su amigo no es tan malo como la gente cree."

# game/script.rpy:749
translate Spanish end_day_438de75a:

    # "You were too distracted by their exchange that you forgot you're talking to Geo Oogami himself!"
    "¡Su intercambio te distrajo tanto que olvidaste que le hablas al mismísimo Geo Oogami!"

# game/script.rpy:750
translate Spanish end_day_63913860:

    # g e2 "Yes?"
    g e2 "¿Sí?"

# game/script.rpy:751
translate Spanish end_day_63e62a22:

    # mc "Um....!"
    mc "Eh....!"

# game/script.rpy:752
translate Spanish end_day_2bfb24f1:

    # g m7 "Make it quick."
    g m7 "Sé breve."

# game/script.rpy:754
translate Spanish end_day_c3b263b7:

    # mc "I want to give you this!"
    mc "¡Quiero darte esto!"

# game/script.rpy:755
translate Spanish end_day_b72e04ac:

    # "You handed out your gift to him. He said nothing, taking your gift with one hand."
    "Le extendiste tu regalo. No dijo nada y lo tomó con una mano."

# game/script.rpy:756
translate Spanish end_day_220b6f02:

    # g "Thanks."
    g "Gracias."

# game/script.rpy:758
translate Spanish end_day_2eea37a5:

    # mc "I also want to say that... I like you!"
    mc "¡También quiero decirte que... me gustas!"

# game/script.rpy:759
translate Spanish end_day_99a6c325:

    # g b3 "?"
    g b3 "?"

# game/script.rpy:760
translate Spanish end_day_bb8068d9:

    # mc "I like you very much! I've admired you for so long; you're tall and handsome, and I look up to you!"
    mc "¡Me gustas mucho! ¡Te he admirado desde hace tanto; eres alto y guapo, y te admiro!"

# game/script.rpy:761
translate Spanish end_day_852f8f21:

    # mc "You're talented, and I don't care what anybody else thinks, you're not some heartless person, I just know somewhere deep in your heart that you are a sincere and nice person!"
    mc "¡Eres talentoso, y no me importa lo que piense nadie más, no eres una persona sin corazón, simplemente sé que en lo más profundo de tu corazón eres una persona sincera y amable!"

# game/script.rpy:763
translate Spanish end_day_4e547f5b:
    
    $ arti = "el" if gift == "bouquet" else "los"

    # "For a moment, he was quiet; the [gift] in his arms threatened to slip, but he kept his hold."
    "Por un momento, se quedó callado; [arti] [gift!t] en sus brazos amenazó con resbalarse, pero lo sostuvo."

# game/script.rpy:764
translate Spanish end_day_ed192e96:

    # "His eyes kept their hold on you, but not directed towards you, as if he's looking in a different direction."
    "Sus ojos siguieron fijos en ti, pero sin dirigirse a ti, como si mirara en otra dirección."

# game/script.rpy:765
translate Spanish end_day_56b29510:

    # "Geo takes a deep breath."
    "Geo toma una profunda bocanada de aire."

# game/script.rpy:766
translate Spanish end_day_4162353d:

    # "Then takes on a stern look."
    "Luego adopta una mirada severa."

# game/script.rpy:767
translate Spanish end_day_828151f0:

    # "The hold on his gift is now tight, nearly crushing."
    "Su agarre sobre el regalo ahora es firme, casi aplastante."

# game/script.rpy:770
translate Spanish end_day_6637e44c:

    # g p2e1 p2m1 p2b1 "I don't know what gave you the idea of perfection."
    g p2e1 p2m1 p2b1 "No sé qué te dio la idea de la perfección."

# game/script.rpy:771
translate Spanish end_day_7f4f72c1:

    # g p2b4 "But me being one is not."
    g p2b4 "Pero yo no lo soy."

# game/script.rpy:772
translate Spanish end_day_5c2aa1e5:

    # g p2m2 "You have no idea what's going on."
    g p2m2 "No tienes idea de lo que ocurre."

# game/script.rpy:773
translate Spanish end_day_979d01eb:

    # g p2m1 "You like the idea of me, don't you?"
    g p2m1 "Te gusta la idea de mí, ¿verdad?"

# game/script.rpy:775
translate Spanish end_day_4e91252a:
    
    $ arti = "tu" if gift == "bouquet" else "tus"

    # "He takes a step back. Then threw your [gift] on the ground, the gift now ruined and scattered in messy bits."
    "Da un paso atrás. Luego tira [arti] [gift!t] al suelo, ahora arruinado y esparcido en pedazos desordenados."

# game/script.rpy:776
translate Spanish end_day_0f5f852f:

    # g p2e1 "And I don't know who gave you the idea of me being a nice person either."
    g p2e1 "Y tampoco sé quién te dio la idea de que soy una persona amable."

# game/script.rpy:777
translate Spanish end_day_58416c28:

    # g "I'm not going to fulfill your desires like some petty fool."
    g "No voy a cumplir tus deseos como un necio mezquino."

# game/script.rpy:778
translate Spanish end_day_0a0382e6:

    # g "I hate Valentine's Day. And I hate you."
    g "Odio el día de San Valentín. Y te odio a ti."

# game/script.rpy:781
translate Spanish end_day_4c9e6f26:

    # "With one last glare, he turns on his heel and walks away, leaving you in absolute shock."
    "Con una última mirada fulminante, da media vuelta y se aleja, dejándote en absoluto shock."

# game/script.rpy:782
translate Spanish end_day_fd5c2cbc:

    # mc "{cps=5}.....{/cps}"
    mc "{cps=5}.....{/cps}"

# game/script.rpy:783
translate Spanish end_day_6c95150f:

    # mc "He{cps=5}....{/cps}"
    mc "Él{cps=5}....{/cps}"

# game/script.rpy:785
translate Spanish end_day_304d3f08:

    # mc "HE SPOKE TO ME!" with vpunch
    mc "¡ME HABLÓ!" with vpunch

# game/script.rpy:786
translate Spanish end_day_bc1fad28:

    # "{color=#ff0090}Yeah... did none of the things he said go through your head?{/color}"
    "{color=#ff0090}Sí... ¿ninguna de las cosas que dijo pasó por tu cabeza?{/color}"

# game/script.rpy:787
translate Spanish end_day_2f2e13f8:

    # mc "THAT DOESN'T MATTER!"
    mc "¡ESO NO IMPORTA!"

# game/script.rpy:788
translate Spanish end_day_c7a7518d:

    # mc "HE TALKED TO ME WITH MORE THAN 2 SENTENCES."
    mc "ME HABLÓ CON MÁS DE 2 ORACIONES."

# game/script.rpy:789
translate Spanish end_day_f97af72c:

    # mc "THIS IS A WHOLE NEW RECORD! I KNEW THE GIFT WAS GOING TO WORK!" with vpunch
    mc "¡ESTE ES UN RÉCORD TOTALMENTE NUEVO! ¡SABÍA QUE EL REGALO IBA A FUNCIONAR!" with vpunch

# game/script.rpy:790
translate Spanish end_day_088d20a0:

    # "You laugh out loud. The feeling of your heart pumping from your chest was wild, and the heat in your face never left."
    "Te ríes a carcajadas. La sensación de tu corazón latiendo en el pecho era salvaje, y el calor en tu cara nunca se fue."

# game/script.rpy:791
translate Spanish end_day_bd17b29f:

    # "This year is just proof of progress! Next year, you can smell success!"
    "¡Este año es prueba de progreso! ¡El año que viene ya puedes oler el éxito!"

# game/script.rpy:792
translate Spanish end_day_89b23acf:

    # mc "Just you wait Subaru Oogami..."
    mc "Solo espera, Subaru Oogami..."

# game/script.rpy:793
translate Spanish end_day_c98f8878:

    # mc "For I am not done with you just yet!"
    mc "¡Porque todavía no he terminado contigo!"

# game/script.rpy:794
translate Spanish end_day_444b6ab1:

    # "{color=#ff0090}Yeah... You definitely lost your mind. But since you're happy with the result, I wouldn't bother scolding you.{/color}"
    "{color=#ff0090}Sí... definitivamente perdiste la cabeza. Pero como estás feliz con el resultado, no me molestaré en regañarte.{/color}"

# game/script.rpy:798
translate Spanish end_day_5de9b69f:

    # centered "{size=65}END: REJECTED{/size}\n{size=25}\n(but you still won so does it really matter?){/size}"
    centered "{size=65}FINAL: RECHAZADO{/size}\n{size=25}\n(pero igual ganaste, ¿de verdad importa?){/size}"

# game/script.rpy:803
translate Spanish end_day_280fa127:

    # "You scratch the back of your head; all of your attempts in trying to grab the lone wolf's heart for Valentine's has all gone to absolute shit."
    "Te rascas la nuca; todos tus intentos por ganarte el corazón del lobo solitario en San Valentín se han ido a la mierda."

# game/script.rpy:805
translate Spanish end_day_ee72f569:

    # "You were considering giving up and would try again next year."
    "Estabas considerando rendirte e intentarlo de nuevo el año que viene."

# game/script.rpy:806
translate Spanish end_day_83096413:

    # g "See you tomorrow."
    g "Nos vemos mañana."

# game/script.rpy:807
translate Spanish end_day_29671cba:

    # "Your ears perked."
    "Se te alzan las orejas."

# game/script.rpy:808
translate Spanish end_day_a4fcce77:

    # "You never turned your head so fast you thought you were going to break your neck while doing so."
    "Nunca habías girado la cabeza tan rápido; pensaste que te romperías el cuello al hacerlo."

# game/script.rpy:809
translate Spanish end_day_63cc4979:

    # "His voice caught your attention just like sirens lure pirates in the sea."
    "Su voz captó tu atención como las sirenas atraen a los piratas en el mar."

# game/script.rpy:811
translate Spanish end_day_7c7f06f9:

    # "There, by the exit, was none other than Geo, and with him was the school's vice president, Ichabod."
    "Allí, junto a la salida, estaba nada menos que Geo, y con él, el vicepresidente de la escuela, Ichabod."

# game/script.rpy:813
translate Spanish end_day_6b6443a9:

    # "There by the exit gate was none other than Geo, and with him was the all too familiar jock right next to him."
    "Allí, junto a la puerta de salida, estaba nada menos que Geo, y con él, el deportista tan conocido, justo a su lado."

# game/script.rpy:814
translate Spanish end_day_94e70941:

    # "Oh, how fate works, for it has given you one more chance to talk to him! The day has yet to end! What will you do?"
    "¡Oh, cómo obra el destino, pues te ha dado una oportunidad más de hablar con él! ¡El día aún no termina! ¿Qué harás?"

# game/script.rpy:818
translate Spanish end_day_3338bf3c:

    # "You thought about the events that happened within the day. Your occasional failures and humiliation felt like a slap across your face."
    "Pensaste en lo ocurrido a lo largo del día. Tus fracasos y humillaciones ocasionales se sintieron como una bofetada en la cara."

# game/script.rpy:819
translate Spanish end_day_0cc1c024:

    # "You don't know which one hurt the most, the slap or your heart breaking, knowing you have NO chance with Subaru."
    "No sabes cuál dolió más, la bofetada o tu corazón rompiéndose al saber que NO tienes ninguna oportunidad con Subaru."

# game/script.rpy:820
translate Spanish end_day_c2437b88:

    # "It's time to call it quits [mc]!"
    "¡Es hora de dejarlo, [mc]!"

# game/script.rpy:821
translate Spanish end_day_85c114e2:

    # "Who knows? You might have better chances for next year."
    "¿Quién sabe? Quizá tengas mejores oportunidades el año que viene."

# game/script.rpy:825
translate Spanish end_day_27923cae:

    # centered "{size=65}END: ALONE{/size}\n{size=25}\n(Next year will be better! You hope.){/size}"
    centered "{size=65}FINAL: SOLEDAD{/size}\n{size=25}\n(¡El año que viene será mejor! Eso esperas.){/size}"

# game/script.rpy:829
translate Spanish end_day_95911496:

    # "You took your chance."
    "Aprovechaste tu oportunidad."

# game/script.rpy:844
translate Spanish end_day_67927a14:

    # "You have questions on what happened during lunch."
    "Tienes preguntas sobre lo que pasó durante el almuerzo."

# game/script.rpy:845
translate Spanish end_day_a5581027:

    # "You need questions, you want to know if you have a potential rival in the way of your goal towards his heart!"
    "Necesitas respuestas, ¡quieres saber si tienes un posible rival en el camino hacia su corazón!"

# game/script.rpy:857
translate Spanish end_day_ultimate_reject_9bd2291a:

    # "The day has yet to end, you thought, and despite all the previous failed attempts, you're not letting yourself be affected by unfortunate events. There is still time to fix all of it!"
    "El día aún no termina, pensaste, y a pesar de todos los intentos fallidos anteriores, no vas a dejar que los infortunios te afecten. ¡Todavía hay tiempo para arreglarlo todo!"

# game/script.rpy:859
translate Spanish end_day_ultimate_reject_111de785:

    # mc "Geo, wait!"
    mc "¡Geo, espera!"

# game/script.rpy:860
translate Spanish end_day_ultimate_reject_ea908c25:

    # "You call out to him, seeing how he was about to cross the street. Thankfully, your voice was loud enough for him to notice you."
    "Lo llamas, viendo que estaba a punto de cruzar la calle. Por suerte, tu voz fue lo bastante fuerte para que te notara."

# game/script.rpy:861
translate Spanish end_day_ultimate_reject_a3e6e91e:

    # "He stops to turn to where your voice was, a bored look on his face, and he probably was already used to people calling out to him all the time throughout the day today."
    "Se detiene y se vuelve hacia donde venía tu voz, con cara de aburrimiento; probablemente ya estaba acostumbrado a que lo llamaran todo el tiempo a lo largo del día."

# game/script.rpy:863
translate Spanish end_day_ultimate_reject_f68d97fc:

    # g pose2 p2e2 p2m1 p2b1 "....." with dissolve
    g pose2 p2e2 p2m1 p2b1 "....." with dissolve

# game/script.rpy:864
translate Spanish end_day_ultimate_reject_89a19e4c:

    # g "It's you again..."
    g "Eres tú otra vez..."

# game/script.rpy:865
translate Spanish end_day_ultimate_reject_4afbe32e:

    # g pose2 p2e2 p2m2 p2b4 "Again, leave me if you have nothing better to do."
    g pose2 p2e2 p2m2 p2b4 "Otra vez, déjame en paz si no tienes nada mejor que hacer."

# game/script.rpy:867
translate Spanish end_day_ultimate_reject_3bdddc30:

    # "Just as he was about to turn on his heel, you took a deep breath, clenching the front of your uniform where your heart was."
    "Justo cuando iba a girar sobre sus talones, respiraste hondo, aferrando el frente de tu uniforme, justo donde está tu corazón."

# game/script.rpy:868
translate Spanish end_day_ultimate_reject_db7e7956:

    # "You can feel the rapid thumps of your heart, nervousness coursing through your body, sending shivers down your spine."
    "Sientes los rápidos latidos de tu corazón, los nervios recorriendo tu cuerpo y enviando escalofríos por tu espalda."

# game/script.rpy:869
translate Spanish end_day_ultimate_reject_5d4046ac:

    # "You feel like throwing up again."
    "Tienes ganas de vomitar otra vez."

# game/script.rpy:870
translate Spanish end_day_ultimate_reject_59562d6b:

    # mc "I like you! Please be my Valentine!"
    mc "¡Me gustas! ¡Por favor, sé mi San Valentín!"

# game/script.rpy:872
translate Spanish end_day_ultimate_reject_f6ba8993:

    # g "....?"
    g "....?"

# game/script.rpy:873
translate Spanish end_day_ultimate_reject_8e62a3de:

    # mc "I have nothing else to give; there is no means to impress you other than my words."
    mc "No tengo nada más que dar; no hay forma de impresionarte aparte de mis palabras."

# game/script.rpy:874
translate Spanish end_day_ultimate_reject_a83de284:

    # mc "I have nothing but my feelings to give to you!"
    mc "¡No tengo más que mis sentimientos para darte!"

# game/script.rpy:875
translate Spanish end_day_ultimate_reject_ad3a0961:

    # mc "So, please! Hear me out!"
    mc "¡Así que, por favor! ¡Escúchame!"

# game/script.rpy:877
translate Spanish end_day_ultimate_reject_55fa913c:

    # "Geo remains still, his hands in his hoodie pockets, keeping his solemn expression. He looks you up and down, and you aren't sure if he's judging you or curious about you."
    "Geo permanece inmóvil, con las manos en los bolsillos de su sudadera, manteniendo su expresión solemne. Te mira de arriba abajo, y no sabes si te está juzgando o si siente curiosidad por ti."

# game/script.rpy:878
translate Spanish end_day_ultimate_reject_92d60634:

    # "But one thing's for sure, you've caught his interest, even if it's just for a moment."
    "Pero de algo no hay duda: has captado su interés, aunque sea por un momento."

# game/script.rpy:879
translate Spanish end_day_ultimate_reject_0ce62e91:

    # "You took it as an opportunity to continue."
    "Lo tomaste como una oportunidad para continuar."

# game/script.rpy:880
translate Spanish end_day_ultimate_reject_b3b779ea:

    # mc "I have admired you ever since freshman year. How you carried yourself to perfection, kept your grades up, and never seemed to falter no matter what obstacle was thrown at you."
    mc "Te he admirado desde primer año. Cómo te comportabas a la perfección, mantenías tus notas altas y nunca parecías flaquear sin importar el obstáculo que te pusieran enfrente."

# game/script.rpy:881
translate Spanish end_day_ultimate_reject_8c027e5e:

    # mc "You're so perfect in every way possible!"
    mc "¡Eres tan perfecto en todos los sentidos posibles!"

# game/script.rpy:882
translate Spanish end_day_ultimate_reject_95bcba17:

    # mc "I couldn't help but admire you!"
    mc "¡No pude evitar admirarte!"

# game/script.rpy:883
translate Spanish end_day_ultimate_reject_739b8638:

    # mc "I like you!"
    mc "¡Me gustas!"

# game/script.rpy:884
translate Spanish end_day_ultimate_reject_bf4c7eef:

    # mc "Please be my Valentine, even if it's just for today!"
    mc "¡Por favor, sé mi San Valentín, aunque sea solo por hoy!"

# game/script.rpy:886
translate Spanish end_day_ultimate_reject_1f224f13:

    # "You let out a huge breath, the rapid beating of your heartbeat grew faster and faster, and you swore you felt like you were about to pass out at any time possible."
    "Sueltas un enorme suspiro, los latidos de tu corazón se aceleran cada vez más, y juraste que estabas a punto de desmayarte en cualquier momento."

# game/script.rpy:887
translate Spanish end_day_ultimate_reject_3e50a35a:

    # "Usually, this is the part where you'd expect that the male lead would say: 'I like you too...'"
    "Normalmente, esta es la parte donde esperarías que el protagonista masculino dijera: 'Tú también me gustas...'"

# game/script.rpy:888
translate Spanish end_day_ultimate_reject_2e049f0a:

    # "But his silence did not help; his gaze was still fixated on you. Geo's previous bored expression was replaced with one of concern—troubled even."
    "Pero su silencio no ayudó; su mirada seguía fija en ti. La expresión aburrida de Geo fue reemplazada por una de preocupación; incluso de inquietud."

# game/script.rpy:889
translate Spanish end_day_ultimate_reject_a2370076:

    # "The cool autumn breeze passed by, causing his long hair to flow along with it, the setting sun giving him an ethereal look, the scene reminding you of those drama shows you've seen on television."
    "La fresca brisa otoñal pasó, haciendo que su largo cabello ondeara con ella, el sol poniente dándole un aspecto etéreo, la escena recordándote a esos dramas que has visto en televisión."

# game/script.rpy:890
translate Spanish end_day_ultimate_reject_b4782f33:

    # g "You think I'm perfect?"
    g "¿Crees que soy perfecto?"

# game/script.rpy:891
translate Spanish end_day_ultimate_reject_e9619dc6:

    # "He lets out a dry laugh."
    "Suelta una risa seca."

# game/script.rpy:895
translate Spanish end_day_ultimate_reject_77f69e57:

    # g "What do you know about perfection, [mc]?"
    g "¿Qué sabes tú de la perfección, [mc]?"

# game/script.rpy:896
translate Spanish end_day_ultimate_reject_d76c516c:

    # "The tone in his voice lowered, his brows furrowed from concern to irritation. For a moment, you thought he looked sad, to you or himself, you weren't sure."
    "El tono de su voz bajó, sus cejas se fruncieron de la preocupación a la irritación. Por un momento pensaste que se veía triste, por ti o por sí mismo, no lo sabías con certeza."

# game/script.rpy:897
translate Spanish end_day_ultimate_reject_7647769d:

    # g "You don't know anything about me, [mc]."
    g "No sabes nada de mí, [mc]."

# game/script.rpy:898
translate Spanish end_day_ultimate_reject_6a66a591:

    # g "Let me ask you something [mc]... If you think I'm perfect..."
    g "Déjame preguntarte algo, [mc]... Si crees que soy perfecto..."

# game/script.rpy:899
translate Spanish end_day_ultimate_reject_11b0dc2b:

    # g "Do you see me as a god?"
    g "¿Me ves como un dios?"

# game/script.rpy:902
translate Spanish end_day_ultimate_reject_4cffa8f7:

    # mc "Yes... I see you as a god."
    mc "Sí... te veo como un dios."

# game/script.rpy:903
translate Spanish end_day_ultimate_reject_f5657b7c:

    # mc "More than a diety."
    mc "Más que una deidad."

# game/script.rpy:904
translate Spanish end_day_ultimate_reject_2108cd4e:

    # mc "I would worship the very ground your steps take."
    mc "Adoraría el suelo mismo que pisan tus pasos."

# game/script.rpy:906
translate Spanish end_day_ultimate_reject_9718a423:

    # "You let your mouth run."
    "Dejas que tu boca hable."

# game/script.rpy:907
translate Spanish end_day_ultimate_reject_5fb60dcc:

    # "Yes, this is how you truly feel about him. He is perfection. He is supreme. You would let him do anything to you and accept it like a blessing."
    "Sí, así es como realmente te sientes con él. Es la perfección. Es supremo. Le permitirías hacerte cualquier cosa y lo aceptarías como una bendición."

# game/script.rpy:908
translate Spanish end_day_ultimate_reject_428b0e72:

    # "Geo recoiled in pure disgust."
    "Geo retrocedió con puro asco."

# game/script.rpy:910
translate Spanish end_day_ultimate_reject_5d43cbac:

    # g "You're not any better."
    g "Tú no eres mejor."

# game/script.rpy:912
translate Spanish end_day_ultimate_reject_0445bc9e:

    # mc "No, I don't see you as a god."
    mc "No, no te veo como un dios."

# game/script.rpy:914
translate Spanish end_day_ultimate_reject_3207b7aa:

    # g "And yet, from how you act, the way you worship me."
    g "Y aun así, por cómo actúas, por la forma en que me adoras."

# game/script.rpy:915
translate Spanish end_day_ultimate_reject_f1030962:

    # g "The unending devotion."
    g "La devoción interminable."

# game/script.rpy:916
translate Spanish end_day_ultimate_reject_1f1a8b05:

    # g "I find it disgusting."
    g "Me parece repugnante."

# game/script.rpy:917
translate Spanish end_day_ultimate_reject_662fb7b1:

    # g "Stop lying."
    g "Deja de mentir."

# game/script.rpy:919
translate Spanish end_day_ultimate_reject_30031ee1:

    # g "Let me make things clear."
    g "Déjame dejar las cosas claras."

# game/script.rpy:920
translate Spanish end_day_ultimate_reject_c21b0c99:

    # g "I don't like you, [mc]."
    g "No me gustas, [mc]."

# game/script.rpy:922
translate Spanish end_day_ultimate_reject_ab9baa3b:

    # "You feel your heart going up to your throat. His words immodestly silence you."
    "Sientes que el corazón te sube a la garganta. Sus palabras te silencian sin pudor."

# game/script.rpy:924
translate Spanish end_day_ultimate_reject_2088e989:

    # g "Be thankful that I bothered to learn your name just because we're classmates."
    g "Agradece que me molesté en aprenderme tu nombre solo porque somos compañeros de clase."

# game/script.rpy:926
translate Spanish end_day_ultimate_reject_36aed2d9:

    # g "But I hate people like you."
    g "Pero odio a la gente como tú."

# game/script.rpy:928
translate Spanish end_day_ultimate_reject_0a025f76:

    # g "What you feel towards me is not real admiration."
    g "Lo que sientes por mí no es admiración real."

# game/script.rpy:929
translate Spanish end_day_ultimate_reject_c4299da2:

    # g "It's idolization."
    g "Es idolatría."

# game/script.rpy:930
translate Spanish end_day_ultimate_reject_1e83d106:

    # g "You don't admire me for my true self."
    g "No me admiras por quien soy en realidad."

# game/script.rpy:932
translate Spanish end_day_ultimate_reject_2b8c5807:

    # "The more he talks, the more you can feel his aura growing darker and darker."
    "Mientras más habla, más sientes que su aura se vuelve cada vez más oscura."

# game/script.rpy:933
translate Spanish end_day_ultimate_reject_b0a5c0d0:

    # "You want to retort; you want to tell him that everything that he's saying is not true."
    "Quieres replicar; quieres decirle que todo lo que dice no es verdad."

# game/script.rpy:934
translate Spanish end_day_ultimate_reject_f39b8b56:

    # "...Are they?"
    "...¿Lo es?"

# game/script.rpy:935
translate Spanish end_day_ultimate_reject_a32fca36:

    # "{color=#ff0090}Besides, when did this become so dark all of a sudden? This is supposed to be a gag game!{/color}"
    "{color=#ff0090}Además, ¿cuándo se puso todo tan oscuro de repente? ¡Se supone que esto es un juego de comedia!{/color}"

# game/script.rpy:937
translate Spanish end_day_ultimate_reject_e688728c:

    # g "You hear something?"
    g "¿Oyes algo?"

# game/script.rpy:938
translate Spanish end_day_ultimate_reject_fca52711:

    # mc "No."
    mc "No."

# game/script.rpy:940
translate Spanish end_day_ultimate_reject_018c1b24:

    # "Just then, a large black car came, and one of the car's windows rolled down, revealing a man with an eyepatch. He looks dangerous, but his appearance did not faze Geo."
    "En ese momento llegó un gran auto negro, y una de sus ventanillas bajó, revelando a un hombre con un parche en el ojo. Se ve peligroso, pero su aspecto no inmutó a Geo."

# game/script.rpy:941
translate Spanish end_day_ultimate_reject_50d541b7:

    # "Geo lets out a tired sigh."
    "Geo suelta un suspiro cansado."

# game/script.rpy:942
translate Spanish end_day_ultimate_reject_178b4561:

    # "Wait! You refuse to let him go just yet!"
    "¡Espera! ¡Te niegas a dejarlo ir todavía!"

# game/script.rpy:944
translate Spanish end_day_ultimate_reject_8ad2c795:

    # g "Didn't my words get in your stupid brain?"
    g "¿Mis palabras no entraron en tu estúpido cerebro?"

# game/script.rpy:945
translate Spanish end_day_ultimate_reject_5453b918:

    # g "I hate you."
    g "Te odio."

# game/script.rpy:946
translate Spanish end_day_ultimate_reject_b859e9e1:

    # g "I despise people like you."
    g "Desprecio a la gente como tú."

# game/script.rpy:947
translate Spanish end_day_ultimate_reject_f6ec7588:

    # g "I don't want to be your Valentine."
    g "No quiero ser tu San Valentín."

# game/script.rpy:948
translate Spanish end_day_ultimate_reject_06911fc9:

    # g p2m1 "Now leave."
    g p2m1 "Ahora lárgate."

# game/script.rpy:950
translate Spanish end_day_ultimate_reject_f760e436:

    # "And with that, he slams the door to the car closed, the black vehicle disappearing from your sight."
    "Y con eso, cierra de un portazo la puerta del auto, y el vehículo negro desaparece de tu vista."

# game/script.rpy:951
translate Spanish end_day_ultimate_reject_5c090e89:

    # mc "...."
    mc "...."

# game/script.rpy:952
translate Spanish end_day_ultimate_reject_402c9808:

    # "You weren't sure if you wanted to cry or throw up."
    "No sabías si querías llorar o vomitar."

# game/script.rpy:953
translate Spanish end_day_ultimate_reject_5570116b:

    # "Probably both."
    "Probablemente ambas cosas."

# game/script.rpy:954
translate Spanish end_day_ultimate_reject_525556d6:

    # "But one thing's for sure."
    "Pero de algo no hay duda."

# game/script.rpy:955
translate Spanish end_day_ultimate_reject_84851405:

    # "You lost."
    "Perdiste."

# game/script.rpy:956
translate Spanish end_day_ultimate_reject_0de22082:

    # "And your heart's forever broken."
    "Y tu corazón queda roto para siempre."

# game/script.rpy:960
translate Spanish end_day_ultimate_reject_c5fb9a13:

    # centered "{size=65}END: ULTIMATE REJECTION{/size}\n{size=25}\n(Ouch, better luck next time.){/size}"
    centered "{size=65}FINAL: RECHAZO DEFINITIVO{/size}\n{size=25}\n(Auch, mejor suerte la próxima vez.){/size}"

# game/script.rpy:972
translate Spanish end_day_thirdwheel_ccb29c17:

    # "You feel your feet turning cold. Your heart is beating fast, not from nervousness but from dread."
    "Sientes que se te enfrían los pies. Tu corazón late rápido, no de nervios sino de pavor."

# game/script.rpy:973
translate Spanish end_day_thirdwheel_fdc1563f:

    # "For once, you understood how other people felt when they say Geo scares them."
    "Por una vez, entendiste cómo se sienten los demás cuando dicen que Geo les da miedo."

# game/script.rpy:974
translate Spanish end_day_thirdwheel_735a6383:

    # "Just as you were about to take one step closer to Geo, another figure came behind him. It was Ichabod."
    "Justo cuando ibas a dar un paso más hacia Geo, otra figura apareció detrás de él. Era Ichabod."

# game/script.rpy:975
translate Spanish end_day_thirdwheel_7e977753:

    # "This stopped you in your tracks."
    "Esto te detuvo en seco."

# game/script.rpy:976
translate Spanish end_day_thirdwheel_8cd6b1c4:

    # "Snapping out of your thoughts, you quickly hid behind the nearest wall, taking a small peek to watch the scene unfold."
    "Saliendo de tus pensamientos, te escondiste rápidamente tras la pared más cercana, asomándote un poco para ver cómo se desarrollaba la escena."

# game/script.rpy:977
translate Spanish end_day_thirdwheel_6f0f93b9:

    # "You could hear nothing, but you can absolutely see the way Geo's face softened upon meeting with Ichabod. Within the other male's hands is Geo's backpack."
    "No podías oír nada, pero sí podías ver claramente cómo el rostro de Geo se suavizaba al encontrarse con Ichabod. En las manos del otro chico está la mochila de Geo."

# game/script.rpy:978
translate Spanish end_day_thirdwheel_24905622:

    # "You're assuming that he probably forgot about it, and Ichabod went to retrieve it for him."
    "Supones que probablemente la olvidó, y que Ichabod fue a buscársela."

# game/script.rpy:979
translate Spanish end_day_thirdwheel_ee805b79:

    # "That's enough."
    "Ya basta."

# game/script.rpy:980
translate Spanish end_day_thirdwheel_efd5589f:

    # "You've seen enough."
    "Has visto suficiente."

# game/script.rpy:981
translate Spanish end_day_thirdwheel_11769082:

    # "Ichabod is not some normal rival. He already won."
    "Ichabod no es un rival cualquiera. Él ya ganó."

# game/script.rpy:982
translate Spanish end_day_thirdwheel_68bbfe76:

    # "And now, you're stuck having this broken heart for the rest of the school year."
    "Y ahora te quedas con este corazón roto por el resto del año escolar."

# game/script.rpy:983
translate Spanish end_day_thirdwheel_b2932953:

    # "Heck, probably for the rest of your remaining college life!"
    "¡Diablos, probablemente por el resto de tu vida universitaria!"

# game/script.rpy:988
translate Spanish end_day_thirdwheel_55910b7d:

    # centered "{size=65}END: WINNER{/size}\n{size=25}\n(The prince charming wins again.){/size}"
    centered "{size=65}FINAL: GANADOR{/size}\n{size=25}\n(El príncipe azul gana otra vez.){/size}"

# game/script.rpy:991
translate Spanish end_day_thirdwheel_89bff0ff:

    # "You hastily make your way towards Geo, your shoulders shaking the closer you get to him."
    "Te diriges apresuradamente hacia Geo, con los hombros temblando a medida que te acercas a él."

# game/script.rpy:992
translate Spanish end_day_thirdwheel_3c4f755c:

    # "Without warning, you grabbed hold of his shoulder, and the next thing you knew, you were on the ground, your arm behind your back while the other was threatened to be bent."
    "Sin previo aviso, le agarraste el hombro, y lo siguiente que supiste fue que estabas en el suelo, con un brazo torcido a tu espalda y el otro a punto de doblarse."

# game/script.rpy:993
translate Spanish end_day_thirdwheel_fd0673cd:

    # mc "WAIT WAIT WAIT!"
    mc "¡ESPERA ESPERA ESPERA!"

# game/script.rpy:995
translate Spanish end_day_thirdwheel_f3b00228:

    # g p2e1 p2m2 p2b4 "State your business."
    g p2e1 p2m2 p2b4 "Di a qué vienes."

# game/script.rpy:996
translate Spanish end_day_thirdwheel_d832e7ec:

    # mc "PLEASE LET ME GO, AHHH."
    mc "POR FAVOR, SUÉLTAME, AHHH."

# game/script.rpy:998
translate Spanish end_day_thirdwheel_18e8e3ab:

    # "From your pathetic pleading, Geo lets go of your arm, not bothering to help you get up."
    "Ante tus patéticas súplicas, Geo te suelta el brazo, sin molestarse en ayudarte a levantarte."

# game/script.rpy:999
translate Spanish end_day_thirdwheel_99e68667:

    # "You've only heard of his fast reflexes but never experienced it first hand."
    "Solo habías oído hablar de sus rápidos reflejos, pero nunca los habías experimentado en carne propia."

# game/script.rpy:1000
translate Spanish end_day_thirdwheel_5864bd29:

    # "Not gonna lie, it was kind of hot."
    "No voy a mentir, estuvo medio sexy."

# game/script.rpy:1001
translate Spanish end_day_thirdwheel_b366bfc4:

    # "WAIT, YOU'RE NOT HERE TO OGLE AGAIN."
    "ESPERA, NO VIENES A COMERLO CON LOS OJOS OTRA VEZ."

# game/script.rpy:1002
translate Spanish end_day_thirdwheel_2043dbe8:

    # mc "Geo!"
    mc "¡Geo!"

# game/script.rpy:1003
translate Spanish end_day_thirdwheel_59e61635:

    # g p2m2 "God, pipe down."
    g p2m2 "Dios, baja la voz."

# game/script.rpy:1004
translate Spanish end_day_thirdwheel_6795d1fb:

    # mc "Are you in a relationship?!"
    mc "¡¿Tienes pareja?!"

# game/script.rpy:1007
translate Spanish end_day_thirdwheel_db8348d7:

    # "Once those words came out of your mouth, you felt like crying. The thought alone was enough to break your heart into a million pieces."
    "En cuanto esas palabras salieron de tu boca, sentiste ganas de llorar. Solo pensarlo bastaba para romperte el corazón en un millón de pedazos."

# game/script.rpy:1008
translate Spanish end_day_thirdwheel_63b2c698:

    # "Geo's expression went from a confused look to an embarrassed one; his cheeks tinted red as it slowly seeps through his ears."
    "La expresión de Geo pasó de la confusión a la vergüenza; sus mejillas se tiñen de rojo, que poco a poco se extiende hasta sus orejas."

# game/script.rpy:1010
translate Spanish end_day_thirdwheel_cc059af6:

    # g "HUH?"
    g "¿EH?"

# game/script.rpy:1011
translate Spanish end_day_thirdwheel_fa98cf3b:

    # mc "Deryl, was it?!"
    mc "¡¿Era Deryl, verdad?!"

# game/script.rpy:1012
translate Spanish end_day_thirdwheel_0794b58f:

    # g pose3_blush p3e2 p3m3 "HUH????" with vpunch
    g pose3_blush p3e2 p3m3 "¿¿¿¿EH????" with vpunch

# game/script.rpy:1013
translate Spanish end_day_thirdwheel_4f523a81:

    # "His face turns even redder."
    "Su cara se pone aún más roja."

# game/script.rpy:1014
translate Spanish end_day_thirdwheel_9951897e:

    # "[mc], you're so cooked. He never blushed this wildly."
    "[mc], se acabó para ti. Nunca se había sonrojado tan fuerte."

# game/script.rpy:1015
translate Spanish end_day_thirdwheel_f92ef99c:

    # mc "I KNEW IT!"
    mc "¡LO SABÍA!"

# game/script.rpy:1016
translate Spanish end_day_thirdwheel_e379aa53:

    # mc "Are you into jocks?! Do you like athletic people?! I can be athletic!"
    mc "¡¿Te gustan los deportistas?! ¡¿Te gusta la gente atlética?! ¡Puedo ponerme en forma!"

# game/script.rpy:1017
translate Spanish end_day_thirdwheel_047740fb:

    # mc "OR DO YOU LIKE HOW LOUD HE IS?! I CAN BE LOUD!"
    mc "¡¿O TE GUSTA LO ESCANDALOSO QUE ES?! ¡PUEDO ARMAR ESCÁNDALO!"

# game/script.rpy:1019
translate Spanish end_day_thirdwheel_98b50859:

    # "You were too lost in your little breakdown. Geo was so stunned that he couldn't tell which emotion was stronger: irritation or embarrassment."
    "Te sumergiste tanto en tu pequeño colapso que Geo, aturdido, no sabía cuál emoción era más fuerte: la irritación o la vergüenza."

# game/script.rpy:1021
translate Spanish end_day_thirdwheel_3120cdc1:

    # "Should he slap you across your face and explain that this is all a misunderstanding?"
    "¿Debería darte una bofetada y explicarte que todo esto es un malentendido?"

# game/script.rpy:1022
translate Spanish end_day_thirdwheel_5f9b772e:

    # "...."
    "...."

# game/script.rpy:1023
translate Spanish end_day_thirdwheel_0e617ee1:

    # "It may be a good idea to leave the scene slowly."
    "Quizá sea buena idea salir de la escena despacio."

# game/script.rpy:1024
translate Spanish end_day_thirdwheel_403efc46:

    # "Yeah, while you're still whining..."
    "Sí, mientras sigues lloriqueando..."

# game/script.rpy:1025
translate Spanish end_day_thirdwheel_49b42f23:

    # "A familiar voice cut through him before Geo could even step back. He felt his heart race; he noticed that you also stopped breaking down."
    "Una voz conocida lo interrumpió antes de que Geo siquiera pudiera retroceder. Sintió su corazón acelerarse; notó que tú también habías dejado de lamentarte."

# game/script.rpy:1026
translate Spanish end_day_thirdwheel_ac9aadbf:

    # "Geo knows he is about to have a massive headache next."
    "Geo sabe que está a punto de tener un dolor de cabeza enorme."

# game/script.rpy:1027
translate Spanish end_day_thirdwheel_a4a9da84:

    # deryl "Hey, Geo! You forgot your backpack! Jeez, If Brittney didn't tell me to get you, you'd probably have a hard time finishing your homework with all of your notes."
    deryl "¡Oye, Geo! ¡Olvidaste tu mochila! Por Dios, si Brittney no me hubiera dicho que te la trajera, probablemente te costaría terminar la tarea sin todos tus apuntes."

# game/script.rpy:1028
translate Spanish end_day_thirdwheel_1eff30da:

    # mc "YOU."
    mc "TÚ."

# game/script.rpy:1030
translate Spanish end_day_thirdwheel_ae45fa9d:

    # g e1 b2 m6 "Crap."
    g e1 b2 m6 "Mierda."

# game/script.rpy:1032
translate Spanish end_day_thirdwheel_dd390048:

    # deryl "M-me????"
    deryl "¿¿¿¿Y-yo????"

# game/script.rpy:1033
translate Spanish end_day_thirdwheel_4f376760:

    # mc "HOW DO YOU DO IT?!"
    mc "¡¿CÓMO LO HACES?!"

# game/script.rpy:1034
translate Spanish end_day_thirdwheel_9b36540c:

    # deryl "Do....do what?"
    deryl "¿Qu...qué hago?"

# game/script.rpy:1035
translate Spanish end_day_thirdwheel_6dff479e:

    # mc "Stop playing dumb with me!!!"
    mc "¡¡¡Deja de hacerte el tonto conmigo!!!"

# game/script.rpy:1036
translate Spanish end_day_thirdwheel_01fbf0d8:

    # mc "Or is that your way of actually wooing!?"
    mc "¡¿O es esa tu forma de cortejar de verdad?!"

# game/script.rpy:1037
translate Spanish end_day_thirdwheel_c23b763a:

    # deryl "HUH??"
    deryl "¿¿EH??"

# game/script.rpy:1039
translate Spanish end_day_thirdwheel_319cfada:

    # g e1 b2 m7 "Let's go."
    g e1 b2 m7 "Vámonos."

# game/script.rpy:1041
translate Spanish end_day_thirdwheel_900d2425:

    # "Without warning, Geo took Deryl's elbow and dragged him out of the scene, their figures quickly disappearing into the sidewalk, leaving you in shock."
    "Sin previo aviso, Geo tomó a Deryl del codo y lo arrastró fuera de la escena, sus figuras desapareciendo rápidamente por la acera y dejándote en shock."

# game/script.rpy:1042
translate Spanish end_day_thirdwheel_2a390395:

    # "You can hardly believe what just happened..."
    "Apenas puedes creer lo que acaba de pasar..."

# game/script.rpy:1043
translate Spanish end_day_thirdwheel_51f6d6fb:

    # "Geo didn't even hesitate to grab hold of the jock before running off! Like forbidden lovers!"
    "¡Geo ni siquiera dudó en agarrar al deportista antes de salir corriendo! ¡Como amantes prohibidos!"

# game/script.rpy:1044
translate Spanish end_day_thirdwheel_e02e98b6:

    # "You're so cooked... You'll be third-wheeling them for the rest of the school year..."
    "Se acabó para ti... Serás el mal tercio de ellos el resto del año escolar..."

# game/script.rpy:1045
translate Spanish end_day_thirdwheel_b7fc932f:

    # "Maybe for the rest of your soon-to-be single college life..."
    "Quizá por el resto de tu futura vida universitaria sin pareja..."

# game/script.rpy:1049
translate Spanish end_day_thirdwheel_fdc00299:

    # centered "{size=65}END: THIRDWHEEL{/size}"
    centered "{size=65}FINAL: MAL TERCIO{/size}"

# game/script.rpy:1060
translate Spanish end_day_isekai_cat_9c6b0545:

    # "You make your way towards him. Your presence has yet to be known as he crosses the street where a black vehicle waits for him."
    "Te diriges hacia él. Aún no se ha percatado de tu presencia mientras cruza la calle, donde lo espera un vehículo negro."

# game/script.rpy:1061
translate Spanish end_day_isekai_cat_5873f343:

    # mc "Wait! Stop!"
    mc "¡Espera! ¡Detente!"

# game/script.rpy:1062
translate Spanish end_day_isekai_cat_a4544b21:

    # "You reached out to him, hoping to make it towards him on time."
    "Extendiste la mano hacia él, esperando alcanzarlo a tiempo."

# game/script.rpy:1067
translate Spanish end_day_isekai_cat_7007858e:

    # "At first, you only felt numbness, almost as if you were losing hold of your physical form."
    "Al principio solo sentiste entumecimiento, casi como si perdieras el control de tu forma física."

# game/script.rpy:1068
translate Spanish end_day_isekai_cat_406f5a86:

    # "Then came in pain. Undescribable pain coursing through your body."
    "Luego vino el dolor. Un dolor indescriptible recorriendo tu cuerpo."

# game/script.rpy:1069
translate Spanish end_day_isekai_cat_322ea5b1:

    # "It almost felt like you got hit by a truck!"
    "¡Casi sentiste que te atropelló un camión!"

# game/script.rpy:1070
translate Spanish end_day_isekai_cat_c42ac428:

    # "Then your vision went black."
    "Entonces tu visión se volvió negra."

# game/script.rpy:1072
translate Spanish end_day_isekai_cat_e772ff80:

    # "You feel warm hands wrapped around you; the pain that blasted throughout just a moment ago was now replaced with gentle pats."
    "Sientes unas manos cálidas rodeándote; el dolor que estalló por todo tu cuerpo hace un momento ahora se reemplaza por suaves palmaditas."

# game/script.rpy:1073
translate Spanish end_day_isekai_cat_18a401e0:

    # "You hear sirens."
    "Oyes sirenas."

# game/script.rpy:1076
translate Spanish end_day_isekai_cat_a3b3c6df:

    # "Slowly opening your eyes, you are now within someone's arms."
    "Abriendo lentamente los ojos, te encuentras en los brazos de alguien."

# game/script.rpy:1077
translate Spanish end_day_isekai_cat_dbf42920:

    # "You look up, and you swear you thought you were dreaming because right before your eyes was none other than Geo himself."
    "Levantas la vista y juras que estás soñando, porque ante tus ojos está nada menos que el mismísimo Geo."

# game/script.rpy:1078
translate Spanish end_day_isekai_cat_2e6ec1fc:

    # "But something seems off."
    "Pero algo parece raro."

# game/script.rpy:1079
translate Spanish end_day_isekai_cat_6a59a72e:

    # "He looks bigger. He kept petting you like you're some sort of cat."
    "Se ve más grande. No deja de acariciarte como si fueras una especie de gato."

# game/script.rpy:1080
translate Spanish end_day_isekai_cat_adecdc06:

    # "You reach out only to be met with a black paw."
    "Extiendes la mano solo para encontrarte con una pata negra."

# game/script.rpy:1081
translate Spanish end_day_isekai_cat_8f323e22:

    # mc "... Huh?"
    mc "... ¿Eh?"

# game/script.rpy:1082
translate Spanish end_day_isekai_cat_b1448f81:

    # mc "HUH?!"
    mc "¡¿EH?!"

# game/script.rpy:1083
translate Spanish end_day_isekai_cat_2f47fa6c:

    # g "Hm? What's wrong? Do you feel any pain?"
    g "¿Hm? ¿Qué pasa? ¿Sientes algún dolor?"

# game/script.rpy:1084
translate Spanish end_day_isekai_cat_86a74198:

    # "WHAT IS THAT TONE?!" with vpunch
    "¡¿QUÉ ES ESE TONO?!" with vpunch

# game/script.rpy:1085
translate Spanish end_day_isekai_cat_7ecda0c3:

    # "Oh... oh, why does he sound so sweet? It feels so surreal; is he actually concerned about you?"
    "Oh... oh, ¿por qué suena tan dulce? Se siente tan irreal; ¿de verdad está preocupado por ti?"

# game/script.rpy:1087
translate Spanish end_day_isekai_cat_6662ca95:

    # "His focus switched to the scene before him."
    "Su atención se desvió hacia la escena ante él."

# game/script.rpy:1088
translate Spanish end_day_isekai_cat_6e18fee6:

    # "Now that you realize it, didn't you just get hit by a truck?"
    "Ahora que lo piensas, ¿no te acaba de atropellar un camión?"

# game/script.rpy:1089
translate Spanish end_day_isekai_cat_2959b4ea:

    # "Moving around in his arms, you turn around."
    "Moviéndote entre sus brazos, te giras."

# game/script.rpy:1090
translate Spanish end_day_isekai_cat_7c111877:

    # "You kind of wished you didn't because what lies before you is your own lifeless body, blood pooling around your corpse, half of your head crushed."
    "Casi desearías no haberlo hecho, porque lo que yace ante ti es tu propio cuerpo sin vida, con sangre acumulándose alrededor de tu cadáver y la mitad de tu cabeza aplastada."

# game/script.rpy:1091
translate Spanish end_day_isekai_cat_bd9e50a0:

    # "An ambulance right next to you as paramedics came in to retrieve your body while a man, you're assuming is Geo's driver, explains the situation."
    "Una ambulancia justo a tu lado mientras los paramédicos llegan para recoger tu cuerpo y un hombre, que supones que es el chofer de Geo, explica la situación."

# game/script.rpy:1092
translate Spanish end_day_isekai_cat_954bfec5:

    # "If you could throw up right now, you would, but that's probably hard as a cat, and you clearly didn't want to throw up on Geo."
    "Si pudieras vomitar ahora mismo, lo harías, pero probablemente es difícil siendo gato, y claramente no querías vomitar sobre Geo."

# game/script.rpy:1093
translate Spanish end_day_isekai_cat_09583702:

    # g "Well, it's a good thing I managed to catch you, little guy. Otherwise, you would've ended up like this poor sap."
    g "Menos mal que logré atraparte, bolita de pelos. Si no, habrías acabado como esa pobre persona."

# game/script.rpy:1094
translate Spanish end_day_isekai_cat_6fd436a5:

    # "Does this imply that he would rather save a random ass cat rather than a human being, let alone you???"
    "¿¿¿Eso implica que prefiere salvar a un gato cualquiera antes que a un ser humano, y más aún a ti???"

# game/script.rpy:1095
translate Spanish end_day_isekai_cat_0aa26805:

    # "You have no idea."
    "No tienes ni idea."

# game/script.rpy:1097
translate Spanish end_day_isekai_cat_cef7af3a:

    # g "Well, I've got to go now."
    g "Bueno, ya me tengo que ir."

# game/script.rpy:1098
translate Spanish end_day_isekai_cat_37d45d07:

    # "WAIT{w=1}, HE'S PUTTING YOU DOWN.{w=1} AIN'T THIS A GOOD OPPORTUNITY FOR YOU?"
    "¡ESPERA{w=1}, TE ESTÁ DEJANDO EN EL SUELO.{w=1} ¿NO ES ESTA UNA BUENA OPORTUNIDAD PARA TI?"

# game/script.rpy:1099
translate Spanish end_day_isekai_cat_61304fb5:

    # "TAKE YOUR GODDAMN CHANCE."
    "APROVECHA TU MALDITA OPORTUNIDAD."

# game/script.rpy:1100
translate Spanish end_day_isekai_cat_05620b8f:

    # "You cling onto his hoodie, your claws not letting go of the fabric no matter how much he pulled."
    "Te aferras a su sudadera, tus garras sin soltar la tela por mucho que él tire."

# game/script.rpy:1102
translate Spanish end_day_isekai_cat_9dc67bfd:

    # g "No, I can't bring you with me; my father's going to murder me."
    g "No, no puedo llevarte conmigo; mi padre me va a matar."

# game/script.rpy:1103
translate Spanish end_day_isekai_cat_564cfde7:

    # "You whined--well, more like meowed so loud Geo started shushing you like a parent to their noisy kid."
    "Lloriqueaste... bueno, más bien maullaste tan fuerte que Geo empezó a callarte como un padre a su hijo escandaloso."

# game/script.rpy:1105
translate Spanish end_day_isekai_cat_9215d786:

    # "A moment passed, and then he let out a sigh."
    "Pasó un momento y entonces soltó un suspiro."

# game/script.rpy:1106
translate Spanish end_day_isekai_cat_6906844b:

    # "With you still in his arms, he picks you up and then takes you in with him in the limousine."
    "Contigo aún en sus brazos, te levanta y te lleva consigo a la limusina."

# game/script.rpy:1108
translate Spanish end_day_isekai_cat_2015d2d8:

    # eye "Another one?"
    eye "¿Otro más?"

# game/script.rpy:1110
translate Spanish end_day_isekai_cat_e040e4cd:

    # g e1 m1 b1 "Shut it."
    g e1 m1 b1 "Cállate."

# game/script.rpy:1112
translate Spanish end_day_isekai_cat_dd122ba8:

    # "The eyepatched man rolls his eye, used to the wolf's harsh attitude."
    "El hombre del parche pone los ojos en blanco, acostumbrado a la actitud áspera del lobo."

# game/script.rpy:1113
translate Spanish end_day_isekai_cat_109739f6:

    # "This may be it..."
    "Esto podría ser todo..."

# game/script.rpy:1114
translate Spanish end_day_isekai_cat_ebae5937:

    # "Yeah, you died back there, but turning into a cat right after and Geo adopting you isn't a bad idea either."
    "Sí, moriste allá atrás, pero convertirte en gato justo después y que Geo te adopte tampoco es mala idea."

# game/script.rpy:1115
translate Spanish end_day_isekai_cat_d79252d4:

    # "Who knew? He actually has a soft spot for cats!"
    "¿Quién lo diría? ¡Tiene debilidad por los gatos!"

# game/script.rpy:1116
translate Spanish end_day_isekai_cat_c08eab95:

    # "You can finally feel loved by him!"
    "¡Por fin puedes sentir su cariño!"

# game/script.rpy:1117
translate Spanish end_day_isekai_cat_0840ed8e:

    # "This is a mission success!"
    "¡Misión cumplida!"

# game/script.rpy:1121
translate Spanish end_day_isekai_cat_45fe8dab:

    # centered "{size=65}END: PET{/size}\n{size=25}\n(And all it took was to be a cat.){/size}"
    centered "{size=65}FINAL: MASCOTA{/size}\n{size=25}\n(Y todo lo que hizo falta fue ser un gato.){/size}"

# game/script.rpy:1125
translate Spanish end_day_isekai_ea26e82c:

    # "You watch Geo cross the street towards a black limousine. That's probably his driver here to pick him up!"
    "Ves a Geo cruzar la calle hacia una limusina negra. ¡Seguro es su chofer que viene a recogerlo!"

# game/script.rpy:1126
translate Spanish end_day_isekai_830bf679:

    # mc "Wait! Wait, please!"
    mc "¡Espera! ¡Espera, por favor!"

# game/script.rpy:1127
translate Spanish end_day_isekai_8b587e2d:

    # "Geo unfortunately did not hear your pleas as he opened one of the car's doors. You're about to lose him! You have to hurry!"
    "Geo lamentablemente no oyó tus súplicas mientras abría una de las puertas del auto. ¡Estás a punto de perderlo! ¡Tienes que darte prisa!"

# game/script.rpy:1128
translate Spanish end_day_isekai_2043dbe8:

    # mc "Geo!"
    mc "¡Geo!"

# game/script.rpy:1139
translate Spanish end_day_isekai_39ad1a23:

    # "You wake up with an abrupt start. With a hand over your chest, you can hear and feel the rapid beats of your heart, the adrenaline still kicking in."
    "Despiertas con un sobresalto. Con una mano sobre el pecho, oyes y sientes los rápidos latidos de tu corazón, con la adrenalina todavía a tope."

# game/script.rpy:1140
translate Spanish end_day_isekai_fddc2e10:

    # "Taking slow breaths, you finally calmed down to the point where you can check your surroundings."
    "Respirando despacio, por fin te calmaste lo suficiente como para revisar tus alrededores."

# game/script.rpy:1141
translate Spanish end_day_isekai_5ddea8c8:

    # "Something feels off...."
    "Algo se siente raro...."

# game/script.rpy:1142
translate Spanish end_day_isekai_0ad857f7:

    # "You know this is your classroom, your uniform, your whole belongings."
    "Sabes que este es tu salón, tu uniforme, todas tus pertenencias."

# game/script.rpy:1143
translate Spanish end_day_isekai_49dfc851:

    # "But something about the whole classroom's vibe feels off."
    "Pero algo en el ambiente del salón se siente raro."

# game/script.rpy:1144
translate Spanish end_day_isekai_2e5638ce:

    # "Actually, how did you end up back in the classroom anyway? Weren't you just outside the school?"
    "En realidad, ¿cómo terminaste de vuelta en el salón? ¿No estabas hace un momento afuera de la escuela?"

# game/script.rpy:1145
translate Spanish end_day_isekai_01987c07:

    # "Did time turn back?"
    "¿El tiempo retrocedió?"

# game/script.rpy:1146
translate Spanish end_day_isekai_bba0c0e7:

    # "{cps=5}...{/cps}{w}No, that's impossible."
    "{cps=5}...{/cps}{w}No, eso es imposible."

# game/script.rpy:1147
translate Spanish end_day_isekai_7f777b50:

    # "Taking out your phone, you were about to message [fren] only to be met with the face of someone so familiar yet unfamiliar simultaneously."
    "Sacando tu teléfono, ibas a escribirle a [fren] solo para encontrarte con el rostro de alguien tan familiar y a la vez desconocido."

# game/script.rpy:1148
translate Spanish end_day_isekai_25a56b3d:

    # "Wha..."
    "Qué..."

# game/script.rpy:1149
translate Spanish end_day_isekai_2c9d4a2e:

    # "You know you're kind of a crackhead, that you're much aware of."
    "Sabes que tienes tus rarezas, y de eso eres muy consciente."

# game/script.rpy:1150
translate Spanish end_day_isekai_218bf9bc:

    # "Taking a few sneak pictures of Geo then and there."
    "Tomando unas cuantas fotos a escondidas de Geo ahí mismo."

# game/script.rpy:1151
translate Spanish end_day_isekai_b970b79a:

    # "But this person in your wallpaper...{w} Is Geo."
    "Pero esta persona en tu fondo de pantalla...{w} es Geo."

# game/script.rpy:1152
translate Spanish end_day_isekai_1d281048:

    # g "[mc]! You're not coming with us?"
    g "¡[mc]! ¿No vienes con nosotros?"

# game/script.rpy:1153
translate Spanish end_day_isekai_4cbe89e4:

    # "Huh?"
    "¿Eh?"

# game/script.rpy:1156
translate Spanish end_day_isekai_3b7de02c:

    # "You hear Geo's familiar voice, but a certain tone made you think you were hearing someone else."
    "Oyes la voz familiar de Geo, pero cierto tono te hizo pensar que oías a otra persona."

# game/script.rpy:1157
translate Spanish end_day_isekai_c4531963:

    # "You looked up, and you swore you felt your heart shooting out of your chest, your stomach doing twists and knots."
    "Levantaste la vista y juraste que sentiste el corazón saliéndose de tu pecho, el estómago dando vueltas y nudos."

# game/script.rpy:1158
translate Spanish end_day_isekai_413ac826:

    # "Before you is Geo."
    "Ante ti está Geo."

# game/script.rpy:1159
translate Spanish end_day_isekai_cfc1aee2:

    # "Well, you weren't sure if the person before you was the actual Geo."
    "Bueno, no sabías si la persona ante ti era el verdadero Geo."

# game/script.rpy:1160
translate Spanish end_day_isekai_c234b0bc:

    # "Instead of his everyday garment and hairstyle, he has his hair up, his usual scowl nowhere to be seen but rather a soft and innocent look on his face. His usual hoodie is now replaced with a white inner and a loose sweater."
    "En lugar de su atuendo y peinado de siempre, tiene el cabello recogido, su ceño fruncido habitual no se ve por ninguna parte, sino una mirada suave e inocente en su rostro. Su sudadera de siempre ha sido reemplazada por una camiseta blanca interior y un suéter holgado."

# game/script.rpy:1162
translate Spanish end_day_isekai_6d6efd26:

    # g "[mc]? Are you alright?"
    g "¿[mc]? ¿Estás bien?"

# game/script.rpy:1163
translate Spanish end_day_isekai_3fae666a:

    # mc "Ah! S-sorry... Spaced out there."
    mc "¡Ah! P-perdón... Me quedé en las nubes."

# game/script.rpy:1165
translate Spanish end_day_isekai_44be978e:

    # g "Do you have a fever? I can help you get to the clinic."
    g "¿Tienes fiebre? Puedo ayudarte a llegar a la enfermería."

# game/script.rpy:1166
translate Spanish end_day_isekai_1faf4030:

    # "New outfit, bright eyes, concerned about another person's well-being?"
    "¿Ropa nueva, ojos brillantes, preocupado por el bienestar de otra persona?"

# game/script.rpy:1167
translate Spanish end_day_isekai_606b75ed:

    # "WHO IS THIS PERSON?!"
    "¡¿QUIÉN ES ESTA PERSONA?!"

# game/script.rpy:1168
translate Spanish end_day_isekai_ad00353c:

    # "If it's Geo, then why is he so nice?!"
    "¡¿Si es Geo, entonces por qué es tan amable?!"

# game/script.rpy:1169
translate Spanish end_day_isekai_ae8af1b4:

    # "Actually{w}, why are you complaining that he's nice to you?{w} This should feel like a dream!"
    "En realidad{w}, ¿por qué te quejas de que sea amable contigo?{w} ¡Esto debería sentirse como un sueño!"

# game/script.rpy:1170
translate Spanish end_day_isekai_c412c0e0:

    # "Maybe it is a dream?"
    "¿Quizá sea un sueño?"

# game/script.rpy:1171
translate Spanish end_day_isekai_24aca9da:

    # "You weren't so sure either."
    "Tampoco lo tenías claro."

# game/script.rpy:1172
translate Spanish end_day_isekai_9702058c:

    # "Maybe you got hit by a truck and got transported to this new world?"
    "¿Quizá te atropelló un camión y te transportaron a este nuevo mundo?"

# game/script.rpy:1174
translate Spanish end_day_isekai_164b451c:

    # g "You sure have been spacing a lot lately, [mc]."
    g "Últimamente sí que te quedas en las nubes, [mc]."

# game/script.rpy:1175
translate Spanish end_day_isekai_83a0438a:

    # g "Well, we better get going. The rest are waiting for us."
    g "Bueno, mejor vámonos. Los demás nos esperan."

# game/script.rpy:1179
translate Spanish end_day_isekai_0a314823:

    # centered "{size=65}END: NEW WORLD{/size}\n{size=25}\n(This is {b}NAWT{/b} your Geo, but hey, who are you to complain?){/size}"
    centered "{size=65}FINAL: NUEVO MUNDO{/size}\n{size=25}\n(Este {b}NOOO{/b} es tu Geo, pero oye, ¿quién eres tú para quejarte?){/size}"

# game/script.rpy:1189
translate Spanish end_day_mugged_5b4cd1b2:

    # "You reach out to Geo, calling out his name and hoping he could hear you from across the street."
    "Extiendes la mano hacia Geo, llamándolo por su nombre con la esperanza de que te oiga desde el otro lado de la calle."

# game/script.rpy:1190
translate Spanish end_day_mugged_40012403:

    # "Unfortunately, he did not hear you as he got inside the car. The vehicle ran as soon as he got in."
    "Lamentablemente, no te oyó mientras se subía al auto. El vehículo arrancó en cuanto él entró."

# game/script.rpy:1191
translate Spanish end_day_mugged_d8b34970:

    # "You slumped your shoulders, cursing yourself for not being at least a second early."
    "Dejaste caer los hombros, maldiciéndote por no haber llegado al menos un segundo antes."

# game/script.rpy:1193
translate Spanish end_day_mugged_c18c13c8:

    # gabriel "Oh?"
    gabriel "¿Oh?"

# game/script.rpy:1194
translate Spanish end_day_mugged_bdfb6192:

    # gabriel "Well, well, well... Another stray ignored by their master."
    gabriel "Vaya, vaya, vaya... Un perro callejero más al que su amo ignora."

# game/script.rpy:1195
translate Spanish end_day_mugged_05ec381f:

    # "Who the fuck was this motherfucker? Coming out of nowhere too."
    "¿Quién carajos era este hijo de puta? Y apareciendo de la nada."

# game/script.rpy:1196
translate Spanish end_day_mugged_d0bd60be:

    # gabriel "How pitiful, another poor sap left in the dumpster."
    gabriel "Qué lástima, una pobre alma más tirada en el basurero."

# game/script.rpy:1197
translate Spanish end_day_mugged_0cf8131b:

    # "This man, you're assuming probably a high class, mocks you with his other two companions."
    "Este hombre, que supones que probablemente es de clase alta, se burla de ti junto con sus otros dos acompañantes."

# game/script.rpy:1198
translate Spanish end_day_mugged_a9dcb095:

    # "They're probably there to mock you. It's better to just ignore them."
    "Probablemente están ahí para burlarse de ti. Es mejor ignorarlos."

# game/script.rpy:1199
translate Spanish end_day_mugged_5048483c:

    # "However, the student in the middle didn't seem to appreciate your ignorance."
    "Sin embargo, al estudiante del medio no pareció gustarle tu indiferencia."

# game/script.rpy:1201
translate Spanish end_day_mugged_8a5b296a:

    # gabriel "Hey! We're talking here, so you better listen up, peasant."
    gabriel "¡Oye! Estamos hablando aquí, así que más te vale escuchar, plebe."

# game/script.rpy:1202
translate Spanish end_day_mugged_2d873ef9:

    # "He says with so much malice, grabbing your elbow and forcefully tugging you back, the force nearly making you trip."
    "Lo dice con tanta malicia, agarrándote del codo y jalándote hacia atrás con fuerza, tanto que casi te hace tropezar."

# game/script.rpy:1203
translate Spanish end_day_mugged_239dc51f:

    # gabriel "Why don't we teach this peasant a little lesson. Shall we, boys?"
    gabriel "¿Por qué no le damos una pequeña lección a esta escoria? ¿Les parece, chicos?"

# game/script.rpy:1204
translate Spanish end_day_mugged_2ee1dba0:

    # "Hearing this, the two of the blonde's friends agreed in unison, the three sharing the same malicious intent within their smiles before man-handling you."
    "Al oír esto, los dos amigos del rubio estuvieron de acuerdo al unísono, los tres compartiendo la misma intención maliciosa en sus sonrisas antes de agarrarte a la fuerza."

# game/script.rpy:1206
translate Spanish end_day_mugged_64eac7ff:

    # "You struggle in their hold as they take you away, dragging you towards the nearest dark alleyway where no one can see you."
    "Forcejeas en su agarre mientras se te llevan, arrastrándote hacia el callejón oscuro más cercano donde nadie puede verte."

# game/script.rpy:1207
translate Spanish end_day_mugged_b2b73f6c:

    # mc "Hey! Let go of me, you fucks!"
    mc "¡Oigan! ¡Suéltenme, malditos!"

# game/script.rpy:1208
translate Spanish end_day_mugged_4b71c8bd:

    # gabriel "Search their pockets; there's gonna be at least some value out of this punk."
    gabriel "Revísenle los bolsillos; seguro algo de valor le sacamos."

# game/script.rpy:1209
translate Spanish end_day_mugged_f84a0694:

    # mc "HEY{w}, DON'T YOU DARE TOUCH ME YOU FREAKS!"
    mc "¡OIGAN{w}, NO SE ATREVAN A TOCARME, FENÓMENOS!"

# game/script.rpy:1210
translate Spanish end_day_mugged_93b36740:

    # gabriel "Shut the fuck u--"
    gabriel "¡Cállate la pu--"

# game/script.rpy:1212
translate Spanish end_day_mugged_73d0a159:

    # "Before one of the high-class students could even start digging through your pockets, you hear another voice coming from the alleyway's opening."
    "Antes de que uno de los estudiantes de clase alta siquiera empezara a hurgar en tus bolsillos, oyes otra voz proveniente de la entrada del callejón."

# game/script.rpy:1213
translate Spanish end_day_mugged_0b229c18:

    # "You can hear the blonde swear under his breath, scratching the back of his neck."
    "Oyes al rubio maldecir en voz baja, rascándose la nuca."

# game/script.rpy:1214
translate Spanish end_day_mugged_b8473237:

    # gabriel "What a drag."
    gabriel "Qué fastidio."

# game/script.rpy:1215
translate Spanish end_day_mugged_81439768:

    # gabriel "Consider yourself lucky, peasant."
    gabriel "Agradece tu suerte, plebe."

# game/script.rpy:1216
translate Spanish end_day_mugged_224d39eb:

    # "With a snap of his fingers, the two students who were holding your arms forcefully let you go, pushing you down on the ground and hitting a few empty stray cans."
    "Con un chasquido de sus dedos, los dos estudiantes que te sujetaban los brazos te soltaron a la fuerza, empujándote al suelo y golpeando unas cuantas latas vacías tiradas."

# game/script.rpy:1217
translate Spanish end_day_mugged_b8cac5e3:

    # "The ringleader gave you one last look, not hiding the visible scowl on his face before leaving the scene. His steps were less in a frenzy than those of his companions."
    "El cabecilla te dedicó una última mirada, sin ocultar el ceño fruncido visible en su rostro, antes de abandonar la escena. Sus pasos eran menos frenéticos que los de sus acompañantes."

# game/script.rpy:1218
translate Spanish end_day_mugged_3f59271e:

    # hyugo "Hey! Are you alright?"
    hyugo "¡Oye! ¿Estás bien?"

# game/script.rpy:1219
translate Spanish end_day_mugged_3b5b8f74:

    # "A new and unfamiliar figure made himself known to you. You can barely see his appearance due to the light against his figure."
    "Una figura nueva y desconocida se dio a conocer ante ti. Apenas puedes ver su apariencia por la luz a contraluz."

# game/script.rpy:1220
translate Spanish end_day_mugged_ad33f7ce:

    # "But you're guessing he is also a student."
    "Pero supones que también es estudiante."

# game/script.rpy:1221
translate Spanish end_day_mugged_313ab711:

    # "Rubbing your backside and trying to soothe out the painful collision between the concrete floor and your buttocks."
    "Frotándote la parte trasera y tratando de aliviar el doloroso choque entre el suelo de concreto y tus nalgas."

# game/script.rpy:1226
translate Spanish end_day_mugged_1b392d68:

    # "The guy who saved you, Hyugo, took you to a nearby cafe after helping you from the alleyway."
    "El chico que te salvó, Hyugo, te llevó a una cafetería cercana después de ayudarte a salir del callejón."

# game/script.rpy:1227
translate Spanish end_day_mugged_7263c9ed:

    # hyugo "Good thing I was able to get to you. Who knows what those guys would do to you."
    hyugo "Menos mal que pude llegar a ti. Quién sabe qué te habrían hecho esos tipos."

# game/script.rpy:1229
translate Spanish end_day_mugged_5796b0da:

    # hyugo "Do you usually go home alone?"
    hyugo "¿Sueles volver a casa sin compañía?"

# game/script.rpy:1231
translate Spanish end_day_mugged_f2362362:

    # hyugo "It's safer to be with a friend, especially with the rumored cases of missing people."
    hyugo "Es más seguro ir con un amigo, sobre todo con los rumores de casos de personas desaparecidas."

# game/script.rpy:1232
translate Spanish end_day_mugged_def3beb4:

    # "You want to hit yourself in the head after just realizing this. You could've asked for [fren] to accompany you, but you probably forgot about that bit."
    "Quieres darte un golpe en la cabeza al darte cuenta de esto. Podrías haberle pedido a [fren] que te acompañara, pero probablemente se te olvidó ese detalle."

# game/script.rpy:1233
translate Spanish end_day_mugged_65effc35:

    # "Your entire day was occupied by Geo."
    "Tu día entero estuvo ocupado por Geo."

# game/script.rpy:1234
translate Spanish end_day_mugged_b31cf269:

    # "You slump on the cafe's table, causing it to rattle, the silver spoon making noise upon colliding with the coffee mug."
    "Te desplomas sobre la mesa de la cafetería, haciéndola temblar, la cucharita de plata haciendo ruido al chocar con la taza de café."

# game/script.rpy:1235
translate Spanish end_day_mugged_a79644b5:

    # "And with the reminder of Geo, you recalled what happened before your assault."
    "Y con el recuerdo de Geo, recordaste lo que pasó antes de tu agresión."

# game/script.rpy:1236
translate Spanish end_day_mugged_c451e4bc:

    # "Hyugo was a bit surprised at your reaction but did not question you."
    "Hyugo se sorprendió un poco con tu reacción, pero no te preguntó nada."

# game/script.rpy:1238
translate Spanish end_day_mugged_f279aa63:

    # hyugo "Well, whatever happened during your day, I'm not going to pry about it."
    hyugo "Bueno, lo que sea que haya pasado en tu día, no voy a meterme en eso."

# game/script.rpy:1239
translate Spanish end_day_mugged_e8e75b18:

    # hyugo "I know a broken-hearted look when I see one."
    hyugo "Reconozco una mirada de corazón roto cuando la veo."

# game/script.rpy:1241
translate Spanish end_day_mugged_c1698168:

    # "You didn't really pay any attention to him throughout your time in the cafe with him."
    "No le prestaste mucha atención durante todo el tiempo que estuviste con él en la cafetería."

# game/script.rpy:1242
translate Spanish end_day_mugged_20ab4bc3:

    # "He keeps talking about the cafe to himself more than to you."
    "Sigue hablando de la cafetería más para sí mismo que para ti."

# game/script.rpy:1244
translate Spanish end_day_mugged_38f44f5f:

    # "For the rest of the night, you spent it with Hyugo as he talked your ear off until curfew."
    "Por el resto de la noche, la pasaste con Hyugo mientras te hablaba hasta por los codos hasta el toque de queda."

# game/script.rpy:1245
translate Spanish end_day_mugged_b858d074:

    # "He was at least kind enough to book you a car home."
    "Al menos fue lo bastante amable como para pedirte un auto a casa."

# game/script.rpy:1246
translate Spanish end_day_mugged_eac2d68c:

    # "Your Valentines Day for this year is absolutely shit. You never got to confess how you feel, your plans have gone to absolute trash, and you'll probably get scolded by your parents and best friend."
    "Tu San Valentín de este año es una absoluta mierda. Nunca pudiste confesar lo que sientes, tus planes se fueron a la basura, y probablemente te regañen tus padres y tu mejor amistad."

# game/script.rpy:1247
translate Spanish end_day_mugged_f376d2eb:

    # "Well, at least your schoolmate Hyugo improved your day slightly."
    "Bueno, al menos tu compañero de escuela Hyugo mejoró un poco tu día."

# game/script.rpy:1248
translate Spanish end_day_mugged_f8655383:

    # "You let out a long sigh."
    "Sueltas un largo suspiro."

# game/script.rpy:1249
translate Spanish end_day_mugged_f687a85a:

    # "Time for you to go home."
    "Es hora de que vuelvas a casa."

# game/script.rpy:1254
translate Spanish end_day_mugged_77b4b527:

    # centered "{size=65}END: KNIGHT{/size}\n{size=25}\n(At least there's someone who cares, right?){/size}"
    centered "{size=65}FINAL: CABALLERO{/size}\n{size=25}\n(Al menos hay alguien a quien le importas, ¿no?){/size}"

# game/script.rpy:1264
translate Spanish end_day_fantasia_7df3b045:

    # "You reach out towards him, refusing to give him a chance to take one step further."
    "Extiendes la mano hacia él, negándote a darle la oportunidad de dar un paso más."

# game/script.rpy:1265
translate Spanish end_day_fantasia_e81ae6b4:

    # mc "STOP!"
    mc "¡ALTO!"

# game/script.rpy:1267
translate Spanish end_day_fantasia_8c50784a:

    # g p3e1 p3m1 p3b1 "Wha-"
    g p3e1 p3m1 p3b1 "¿Qué-"

# game/script.rpy:1269
translate Spanish end_day_fantasia_b4e98dfe:

    # "You mayhaps went a bit too far with how forceful your tug was, for the next moment, you and him were on the ground, your body lying on top of his."
    "Quizá te pasaste un poco con la fuerza con que tiraste de él, pues al instante siguiente tú y él estaban en el suelo, con tu cuerpo encima del suyo."

# game/script.rpy:1270
translate Spanish end_day_fantasia_22057e09:

    # "Geo lets out a pained groan, the collision making his body ache."
    "Geo suelta un gemido de dolor; el choque le hace doler el cuerpo."

# game/script.rpy:1272
translate Spanish end_day_fantasia_bd165c79:

    # g e3 m6 b2 "What the hell do you want now?"
    g e3 m6 b2 "¿Qué demonios quieres ahora?"

# game/script.rpy:1273
translate Spanish end_day_fantasia_cc5f2e6b:

    # "He remembers you? Oh, you were expecting him to not recognize you or feign ignorance of your entire existence."
    "¿Te recuerda? Oh, esperabas que no te reconociera o que fingiera ignorar tu existencia entera."

# game/script.rpy:1274
translate Spanish end_day_fantasia_f11ccf7a:

    # "He just loves surprising you, doesn't he?"
    "Le encanta sorprenderte, ¿no?"

# game/script.rpy:1275
translate Spanish end_day_fantasia_967b2e08:

    # mc "Geo! Please... Give me one last chance..."
    mc "¡Geo! Por favor... Dame una última oportunidad..."

# game/script.rpy:1276
translate Spanish end_day_fantasia_321c88a6:

    # g "Get off me first, then I'll let you talk."
    g "Primero bájate de encima, luego te dejaré hablar."

# game/script.rpy:1278
translate Spanish end_day_fantasia_18410729:

    # "Realizing this, you quickly got off him, fixing yourself as Geo stands up."
    "Al darte cuenta, te bajaste rápidamente de él, arreglándote mientras Geo se pone de pie."

# game/script.rpy:1279
translate Spanish end_day_fantasia_a314335b:

    # "Hands in his pockets, he waits for you to continue."
    "Con las manos en los bolsillos, espera a que continúes."

# game/script.rpy:1280
translate Spanish end_day_fantasia_ab3201fb:

    # mc "Geo, please be my Valentine!"
    mc "¡Geo, por favor, sé mi San Valentín!"

# game/script.rpy:1281
translate Spanish end_day_fantasia_2b2ef7b2:

    # mc "I've gone through high and low for you. I admire you a lot, and I want to let you know that you're an amazing person, to the point I fell for you!"
    mc "¡Hice de todo por ti. Te admiro mucho, y quiero que sepas que eres una persona increíble, hasta el punto de que me enamoré de ti!"

# game/script.rpy:1282
translate Spanish end_day_fantasia_53229ea8:

    # mc "I know I am probably not your type. Heck, I don't even know your type anyway."
    mc "Sé que probablemente no soy tu tipo. Diablos, ni siquiera sé cuál es tu tipo."

# game/script.rpy:1283
translate Spanish end_day_fantasia_62c5e603:

    # mc "But I hope that maybe I could be the one for you!"
    mc "¡Pero espero que quizá yo pueda ser la persona indicada para ti!"

# game/script.rpy:1284
translate Spanish end_day_fantasia_c799b8e2:

    # mc "So, please! Please consider! Consider me as a person and a potential lover!"
    mc "¡Así que, por favor! ¡Por favor, considérame! ¡Considérame como persona y como posible pareja!"

# game/script.rpy:1286
translate Spanish end_day_fantasia_77629884:

    # g "{cps=5}.....{/cps}"
    g "{cps=5}.....{/cps}"

# game/script.rpy:1287
translate Spanish end_day_fantasia_981da6d6:

    # "Geo merely stared at you for a few seconds. But every second felt like an hour. Can he be faster with his decisions? You feel like throwing up!"
    "Geo solo te miró fijamente durante unos segundos. Pero cada segundo se sintió como una hora. ¿Puede ser más rápido para decidir? ¡Tienes ganas de vomitar!"

# game/script.rpy:1288
translate Spanish end_day_fantasia_c4961d0c:

    # g p2e1 p2m3 p2b2 "Sure."
    g p2e1 p2m3 p2b2 "Claro."

# game/script.rpy:1289
translate Spanish end_day_fantasia_78c392bf:

    # "...What?"
    "...¿Qué?"

# game/script.rpy:1291
translate Spanish end_day_fantasia_be88e298:

    # g "You've gone all this way to get to me, the efforts you've put just to make it this far, correct?"
    g "Has hecho todo este camino para llegar a mí, los esfuerzos que has puesto solo para llegar hasta aquí, ¿correcto?"

# game/script.rpy:1292
translate Spanish end_day_fantasia_d15ce3fc:

    # g "So yes."
    g "Así que sí."

# game/script.rpy:1293
translate Spanish end_day_fantasia_77cffcc0:

    # "Geo takes a step further towards you, taking your hands in his own."
    "Geo da un paso hacia ti, tomando tus manos entre las suyas."

# game/script.rpy:1294
translate Spanish end_day_fantasia_f6e0a81f:

    # g "I will be your Valenti---{nw=0.9}"
    g "Seré tu San Valen---{nw=0.9}"

# game/script.rpy:1297
translate Spanish end_day_fantasia_27728f0e:

    # "Just then, a sudden flash of light came out of nowhere, the blinding rays illuminating both you and Geo."
    "En ese momento, un destello de luz repentino surgió de la nada, los rayos cegadores iluminándote a ti y a Geo."

# game/script.rpy:1298
translate Spanish end_day_fantasia_fece8ef7:

    # mc "What the fuck--"
    mc "¿Qué carajos--"

# game/script.rpy:1301
translate Spanish end_day_fantasia_7aa376cd:

    # fantasia "OOGAMI PROTOTYPE, YOU ARE NOT MEANT TO BE HERE."
    fantasia "PROTOTIPO OOGAMI, NO DEBES ESTAR AQUÍ."

# game/script.rpy:1302
translate Spanish end_day_fantasia_95186d8a:

    # g "Fuck, she found me."
    g "Mierda, me encontró."

# game/script.rpy:1305
translate Spanish end_day_fantasia_d20ba6ed:

    # "A loud booming voice came from the source of the blinding lights. Geo's hold on you hardens."
    "Una voz fuerte y retumbante vino de la fuente de las luces cegadoras. El agarre de Geo sobre ti se endurece."

# game/script.rpy:1306
translate Spanish end_day_fantasia_79688128:

    # "A figure of what seems to be a round cat-like creature emerged from the light."
    "Una figura de lo que parece una criatura redonda similar a un gato emergió de la luz."

# game/script.rpy:1308
translate Spanish end_day_fantasia_d2e7fec6:

    # "The light turned from a blinding white to green, and suddenly, you feel your feet slowly getting off the ground."
    "La luz pasó de un blanco cegador a verde, y de pronto sientes que tus pies se van despegando lentamente del suelo."

# game/script.rpy:1309
translate Spanish end_day_fantasia_b888be6a:

    # "Were you floating?!"
    "¡¿Estabas flotando?!"

# game/script.rpy:1310
translate Spanish end_day_fantasia_39165ebf:

    # mc "WAIT, WHY AM I GETTING DRAGGED INTO THIS?!"
    mc "¡ESPERA, ¿POR QUÉ ME ARRASTRAN A ESTO?!"

# game/script.rpy:1312
translate Spanish end_day_fantasia_b4ff0520:

    # g "YOU'LL NEVER TAKE ME ALIVE FIEND."
    g "NUNCA ME LLEVARÁS VIVO, DEMONIO."

# game/script.rpy:1314
translate Spanish end_day_fantasia_0bcfc62a:

    # fantasia "OH NO, YOU WON'T!"
    fantasia "¡OH NO, ESO SÍ QUE NO!"

# game/script.rpy:1316
translate Spanish end_day_fantasia_f494cd2b:

    # "Geo (?) struggles as he waves his arms and legs around, swimming in the air while his whole body is floating up in the sky."
    "Geo (?) forcejea agitando brazos y piernas, nadando en el aire mientras todo su cuerpo flota hacia el cielo."

# game/script.rpy:1317
translate Spanish end_day_fantasia_2fb2715c:

    # "The light now not carrying your body, but you watch as Geo was slowly getting dragged into what seems to be..."
    "La luz ya no sostiene tu cuerpo, pero ves cómo Geo es arrastrado lentamente hacia lo que parece ser..."

# game/script.rpy:1318
translate Spanish end_day_fantasia_6a2ab3f3:

    # "An alien spaceship????"
    "¿¿¿¿Una nave espacial alienígena????"

# game/script.rpy:1319
translate Spanish end_day_fantasia_a66cb3a0:

    # "What the fuck????"
    "¿¿¿¿Qué carajos????"

# game/script.rpy:1320
translate Spanish end_day_fantasia_d54162e8:

    # "Should you call the authorities???"
    "¿¿¿Deberías llamar a las autoridades???"

# game/script.rpy:1321
translate Spanish end_day_fantasia_b4a90234:

    # fantasia "No need, they're used to this."
    fantasia "No hace falta, ya están acostumbrados."

# game/script.rpy:1322
translate Spanish end_day_fantasia_38737588:

    # mc "AM NOT?? WHAT'S GOING ON."
    mc "¡¿YO NO?! ¿QUÉ ESTÁ PASANDO?"

# game/script.rpy:1323
translate Spanish end_day_fantasia_e2b81faa:

    # fantasia "You won't understand what's going on either way."
    fantasia "De todos modos no vas a entender lo que está pasando."

# game/script.rpy:1324
translate Spanish end_day_fantasia_61fb2005:

    # g "Putangina mo babae ka, e bui-e ko yodepota!"
    g "Putangina mo babae ka, e bui-e ko yodepota!"

# game/script.rpy:1325
translate Spanish end_day_fantasia_f81ed42b:

    # "Geo(?) sudden change of tone and language caught you off guard. You aren't familiar with much malice in his tone, his arms now behind his back as you watch him enter the large spaceship."
    "El repentino cambio de tono y de idioma de Geo(?) te tomó por sorpresa. No estás familiarizado con tanta malicia en su tono, con los brazos ahora detrás de la espalda mientras lo ves entrar en la enorme nave espacial."

# game/script.rpy:1328
translate Spanish end_day_fantasia_261f6267:

    # fantasia "Gago chak-to gid ko, ambot paano na sya naka gwa."
    fantasia "Gago chak-to gid ko, ambot paano na sya naka gwa."

# game/script.rpy:1329
translate Spanish end_day_fantasia_2626a7ca:

    # fantasia "Kung kinsa lng maka sabot unsa gina ingon ko, bahala kayu diha, ayaw ko mag translate."
    fantasia "Kung kinsa lng maka sabot unsa gina ingon ko, bahala kayu diha, ayaw ko mag translate."

# game/script.rpy:1330
translate Spanish end_day_fantasia_6d8b992b:

    # fantasia "Also if you notice me not changin expression, gi kapoy na ko pre, kamo naman drawing bi."
    fantasia "Also if you notice me not changin expression, gi kapoy na ko pre, kamo naman drawing bi."

# game/script.rpy:1331
translate Spanish end_day_fantasia_4bacfaab:

    # "You have no idea why she stared at a wall as if she were talking to an audience member. Maybe it's an alien thing."
    "No tienes idea de por qué ella miraba una pared como si hablara con un miembro de la audiencia. Quizá sea cosa de alienígenas."

# game/script.rpy:1332
translate Spanish end_day_fantasia_a8251de6:

    # "Finally noticing your dumbfounded look, she gives you a sweet smile."
    "Al notar por fin tu cara de desconcierto, te regala una dulce sonrisa."

# game/script.rpy:1333
translate Spanish end_day_fantasia_63583ad9:

    # fantasia "Congratulations [mc]! You've unlocked all the endings for this game!"
    fantasia "¡Felicidades, [mc]! ¡Has desbloqueado todos los finales de este juego!"

# game/script.rpy:1334
translate Spanish end_day_fantasia_7877d686:

    # fantasia "Sorry you have to see that. What you witnessed just now was an OOC Geo."
    fantasia "Perdona que hayas tenido que ver eso. Lo que acabas de presenciar fue un Geo OOC."

# game/script.rpy:1335
translate Spanish end_day_fantasia_df41e7a4:

    # fantasia "He would never in his life say yes, let alone confess, to someone."
    fantasia "Él jamás en su vida diría que sí, y mucho menos se confesaría, a alguien."

# game/script.rpy:1336
translate Spanish end_day_fantasia_e59dfc21:

    # fantasia "But worry not! The real one actually went home already!"
    fantasia "¡Pero no te preocupes! ¡El verdadero ya se fue a casa!"

# game/script.rpy:1337
translate Spanish end_day_fantasia_9759c637:

    # fantasia "That is to say, you failed this year's Valentine's{w}, again!"
    fantasia "Es decir, ¡fallaste este San Valentín{w}, otra vez!"

# game/script.rpy:1338
translate Spanish end_day_fantasia_9e33ff06:

    # "Wow, did she really need to remind you of that?"
    "Guau, ¿de verdad tenía que recordártelo?"

# game/script.rpy:1339
translate Spanish end_day_fantasia_cc296bcd:

    # fantasia "You should go home before mobs will come and bully you."
    fantasia "Deberías irte a casa antes de que vengan turbas a acosarte."

# game/script.rpy:1340
translate Spanish end_day_fantasia_9c621f10:

    # mc "Huh???"
    mc "¿¿¿Eh???"

# game/script.rpy:1341
translate Spanish end_day_fantasia_bd5294e6:

    # fantasia "Jeez, if you've been keeping up with my last game, this world is filled with bad people. Also, there's a curfew, so get your ass home."
    fantasia "Por Dios, si has seguido mi último juego, sabrás que este mundo está lleno de gente mala. Además, hay toque de queda, así que mueve el trasero a casa."

# game/script.rpy:1343
translate Spanish end_day_fantasia_ebf0f34a:

    # "Without wasting any more of her breath, the alien woman steps into the light, her form floating up and getting in the strange flying saucer before the ship flies away at the speed of light."
    "Sin malgastar más aliento, la mujer alienígena entra en la luz, su figura flotando hasta subir al extraño platillo volador antes de que la nave se aleje a la velocidad de la luz."

# game/script.rpy:1344
translate Spanish end_day_fantasia_8f455437:

    # fren "[mc]! There you are! Why didn't you send me a message?"
    fren "¡[mc]! ¡Aquí estás! ¿Por qué no me mandaste un mensaje?"

# game/script.rpy:1345
translate Spanish end_day_fantasia_89b89553:

    # "You hear the familiar voice of [fren] approaching your still figure, your eyes still on where the flying saucer was."
    "Oyes la voz conocida de [fren] acercándose a tu figura inmóvil, con los ojos aún en el lugar donde estaba el platillo volador."

# game/script.rpy:1346
translate Spanish end_day_fantasia_6825964a:

    # fren "Hellooooo, earth to [mc], are you there?"
    fren "Holaaaa, la Tierra llamando a [mc], ¿estás ahí?"

# game/script.rpy:1347
translate Spanish end_day_fantasia_05500ff6:

    # mc "Huh?"
    mc "¿Eh?"

# game/script.rpy:1348
translate Spanish end_day_fantasia_b8de06d3:

    # mc "Oh."
    mc "Oh."

# game/script.rpy:1349
translate Spanish end_day_fantasia_ad72c12d:

    # mc "[fren], can you do me a favor?"
    mc "[fren], ¿me haces un favor?"

# game/script.rpy:1350
translate Spanish end_day_fantasia_4b4b37df:

    # fren "Huh? Umm... sure?"
    fren "¿Eh? Ehh... ¿claro?"

# game/script.rpy:1351
translate Spanish end_day_fantasia_9bba802a:

    # mc "Slap me."
    mc "Dame una cachetada."

# game/script.rpy:1352
translate Spanish end_day_fantasia_693e5371:

    # fren "Well, why didn't you say so?"
    fren "Bueno, ¿por qué no lo dijiste antes?"

# game/script.rpy:1353
translate Spanish end_day_fantasia_161e3298:

    # "Without warning, [fren] threw you the most painful slap you've ever felt across your face."
    "Sin previo aviso, [fren] te dio la cachetada más dolorosa que has sentido en la cara."

# game/script.rpy:1354
translate Spanish end_day_fantasia_4a6c1e0d:

    # mc "OW YOU MOTHERFUCKER, THAT HURTS."
    mc "¡AUCH, HIJO DE PUTA, ESO DUELE!"

# game/script.rpy:1355
translate Spanish end_day_fantasia_9424a232:

    # "Well... At least that's enough proof that you're not dreaming nor hallucinating."
    "Bueno... Al menos eso es prueba suficiente de que no estás soñando ni alucinando."

# game/script.rpy:1356
translate Spanish end_day_fantasia_d174f209:

    # fren "Heh. Let's go home?"
    fren "Je. ¿Nos vamos a casa?"

# game/script.rpy:1357
translate Spanish end_day_fantasia_c32985d5:

    # mc "... Yeah."
    mc "... Sí."

# game/script.rpy:1358
translate Spanish end_day_fantasia_07241d9d:

    # "Whatever just happened just now, you don't want to question it anymore. You practically gave up trying to chase down Geo at this point."
    "Sea lo que sea lo que acaba de pasar, ya no quieres cuestionarlo. Prácticamente desististe de perseguir a Geo a estas alturas."

# game/script.rpy:1359
translate Spanish end_day_fantasia_458a80c6:

    # "The idea of being unable to confess your feelings to the lone wolf put you down a bit, but maybe you'll have a better chance next year."
    "La idea de no poder confesar tus sentimientos al lobo solitario te desanimó un poco, pero quizá tengas mejor oportunidad el año que viene."

# game/script.rpy:1360
translate Spanish end_day_fantasia_bdc131e0:

    # "Yeah... Just keep your chin up, [mc]."
    "Sí... Mantén la frente en alto, [mc]."

# game/script.rpy:1365
translate Spanish end_day_fantasia_9e37188e:

    # centered "{size=65}END: CREATOR'S ORDERS{/size}\n{size=25}\n(This isn't supposed to be part of the script!){/size}"
    centered "{size=65}FINAL: ÓRDENES DEL CREADOR{/size}\n{size=25}\n(¡Esto no debería ser parte del guion!){/size}"

translate Spanish strings:

    # game/script.rpy:134
    old "Think of something else"
    new "Pensar en otra cosa"

    # game/script.rpy:152
    old "Stick to the original plan"
    new "Seguir el plan original"

    # game/script.rpy:154
    old "Give up"
    new "Rendirse"

    # game/script.rpy:225
    old "Stop ogling"
    new "Dejar de mirarlo"

    # game/script.rpy:252
    old "Yes"
    new "Sí"

    # game/script.rpy:255
    old "No"
    new "No"

    # game/script.rpy:302
    old "Keep ogling"
    new "Seguir mirándolo"

    # game/script.rpy:394
    old "Confess to him immediately."
    new "Confesarte de inmediato."

    # game/script.rpy:443
    old "I like you! Please be my Valentine!"
    new "¡Me gustas! ¡Por favor, sé mi San Valentín!"

    # game/script.rpy:512
    old "Quickly Apologize"
    new "Disculparte rápidamente"

    # game/script.rpy:541
    old "Run away"
    new "Huir"

    # game/script.rpy:548
    old "Buy a bouquet"
    new "Comprar un ramo"

    # game/script.rpy:559
    old "Buy him chocolates"
    new "Comprarle chocolates"

    # game/script.rpy:568
    old "Join him for lunch"
    new "Almorzar con él"

    # game/script.rpy:816
    old "Forget it"
    new "Olvidarlo"

    # game/script.rpy:828
    old "Take your chance."
    new "Aprovechar tu oportunidad."

    # game/script.rpy:843
    old "Confront him"
    new "Enfrentarlo"
    
    old "What's your name?"
    new "¿Cómo te llamas?"
    
    old "Input friend's name..."
    new "Escribe el nombre de tu amiguis..."
    
    old "bouquet"
    new "ramo"
    
    old "chocolates"
    new "chocolates"
    
    old "You"
    new "Tu"

    old "Fangirl"
    new "Fanática"

    old "Fanboy"
    new "Fanático"

    old "Student"
    new "Estudiante"

    old "Teacher"
    new "Profesor"

    old "High Class Bully"
    new "Matón de Élite"

    old "Friend"
    new "Amiguis"

    old "Eyepatched man"
    new "Hombre del parche"

