﻿# TODO: Translation updated at 2026-10-12 12:45

translate Spanish strings:

    # game/options.rpy:17
    old "Rizz the Wolf v1.0"
    new "Rizz the Wolf v1.0"

